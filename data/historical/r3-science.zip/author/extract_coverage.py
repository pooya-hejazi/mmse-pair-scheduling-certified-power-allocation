"""Saved diagnostics only; standard library; no solver imports or new trials.

Example: python -X utf8 -B extract_coverage.py --archive Supplementary_Materials.zip --output coverage-replay
Or: --study path/to/CR033/study (mutually exclusive with --archive).
"""
import time
START=time.perf_counter()
import argparse,csv,gzip,hashlib,io,json,statistics,zipfile
from pathlib import Path

ARMS=('T','W','S','FU_SCA','THU_IDE')
DEFINITIONS={
 'starts_started':'Saved wrapper starts_started: incremented before the initial call; not a completed optimization.',
 'starts_completed':'Saved wrapper starts_completed: full outer start cycle returns, including its exchange search where applicable. W delays exchanges until its initial ten starts have been visited.',
 'exchange_candidates':'Saved exchange_candidates: attempted changed assignments, incremented before power refinement; includes a possibly interrupted attempt.',
 'exchange_completed_records':'Number of phase_records with phase=exchange, appended after power refinement and caller checking/retention return. Not distinct assignments or converged solves.',
 'exchange_accepted':'Saved exchange_accepted: locally accepted schedule changes; not necessarily global incumbent improvements.',
 'power_bearing_completed_records':'Number of saved phase_records with phase=start, exchange, or matching_start. W matching_start combines matching and power. Counts completed record publication in the wrapper, not total initiated calls, inner iterations or converged solutions. A deadline can omit the final call even after it publishes candidates.',
 'missing_rule':'Missing counters/phase_records are null, never zero-imputed. Summaries report available n and missing n. Total initiated power calls and unfinished-call generations are unavailable; no reconstruction from candidates or counter sums.',
}

def main():
 ap=argparse.ArgumentParser();g=ap.add_mutually_exclusive_group(required=True)
 g.add_argument('--study',type=Path);g.add_argument('--archive',type=Path)
 ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 args.output.mkdir(parents=True,exist_ok=False)
 inputs=[];archive=zipfile.ZipFile(args.archive) if args.archive else None
 def read(rel):
  data=archive.read('CR033/study/'+rel) if archive else (args.study/rel).read_bytes()
  inputs.append({'path':'CR033/study/'+rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  return data
 cells=list(csv.DictReader(io.StringIO(read('analysis/holdout/all-cells.csv').decode())))
 assert len(cells)==220 and len({c['case_id'] for c in cells})==44
 assert all(c['phase']=='holdout' and c['valid']=='True' for c in cells)
 assert len({(c['case_id'],c['arm']) for c in cells})==220
 out=[]
 for c in cells:
  rel=f"cells/{c['case_id']}-{c['arm']}/"
  r=json.loads(read(rel+'result.json'));w=r.get('worker_status') or {};d=w.get('diagnostics') or {}
  assert r['case_id']==c['case_id'] and r['method']==c['arm'] and r['valid'] is True
  side=w.get('diagnostics_sidecar');records=None
  if side:
   assert side['file']=='worker-diagnostics.json.gz'
   compressed=read(rel+side['file']);raw=gzip.decompress(compressed)
   assert hashlib.sha256(compressed).hexdigest()==side['sha256']
   assert hashlib.sha256(raw).hexdigest()==side['uncompressed_sha256']
   full=json.loads(raw)
   assert {k:v for k,v in full.items() if k!='phase_records'}==d
   records=full.get('phase_records')
   if records is not None:
    assert all(p.get('phase') in ['start','exchange','matching_start'] for p in records)
  row={'case_id':c['case_id'],'arm':c['arm']}
  for k in ('starts_started','starts_completed','exchange_candidates','exchange_accepted','neighborhoods_completed'):
   row[k]=d.get(k)
   assert row[k] is None or (type(row[k]) is int and row[k]>=0)
  row['exchange_completed_records']=None if records is None else sum(p['phase']=='exchange' for p in records)
  row['power_bearing_completed_records']=None if records is None else len(records)
  row['stopped_phase']=d.get('stopped_phase');row['total_initiated_power_calls']=None
  out.append(row)
 summary={}
 for arm in ARMS:
  rows=[r for r in out if r['arm']==arm];assert len(rows)==44
  summary[arm]={}
  for key in ('starts_started','starts_completed','exchange_candidates','exchange_completed_records','exchange_accepted','power_bearing_completed_records'):
   values=[r[key] for r in rows if r[key] is not None]
   summary[arm][key]={'n':len(values),'missing':44-len(values),'min':min(values) if values else None,'median':statistics.median(values) if values else None,'max':max(values) if values else None,'sum':sum(values) if values else None,'zero':values.count(0)}
 contrasts=json.loads(read('analysis/holdout/CONTRASTS.json'))
 assert len(contrasts)==44 and {c['case_id'] for c in contrasts}=={c['case_id'] for c in cells}
 dump=lambda name,obj:(args.output/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
 dump('COVERAGE_SUMMARY.json',{'population_cases':44,'arms':list(ARMS),'definitions':DEFINITIONS,'summary':summary})
 dump('INPUT_HASHES.json',inputs)
 with (args.output/'COVERAGE_CELLS.csv').open('w',newline='',encoding='utf-8') as f:
  writer=csv.DictWriter(f,fieldnames=list(out[0]));writer.writeheader();writer.writerows(out)
 # Display-only contrasts: preserve the exact saved floats in JSON; scientific notation in TeX.
 dump('DISPLAY_CONTRASTS.json',[{'case_id':c['case_id'],'absolute_modern':c['absolute_modern'],'display':f"{c['absolute_modern']:.2e}"} for c in contrasts])
 print(json.dumps(summary,indent=2));print('wall_seconds',time.perf_counter()-START)
 if archive:archive.close()

if __name__=='__main__':main()
