import gzip,json,time
from pathlib import Path
t=time.perf_counter()
p=Path('research/dual-track-revision-20261103/study/cells')
for arm in ['T','W','S','FU_SCA','THU_IDE']:
 d=json.loads(gzip.decompress((p/f'2026113401-snr0_narrow-{arm}'/'worker-diagnostics.json.gz').read_bytes()))
 print(arm, {k:v for k,v in d.items() if k not in ['phase_records','common_anchor']})
 print('records',len(d['phase_records']),d['phase_records'][:1],d['phase_records'][-1:])
print('wall_seconds',time.perf_counter()-t)
