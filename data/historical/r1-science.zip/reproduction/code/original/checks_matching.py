"""Analytic/development fixtures only; no prospective channel/data access.

Run: python checks_matching.py --output PATH
Writes optional evidence JSON only at the explicitly supplied path.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
import math
from fractions import Fraction as F
from pathlib import Path
import time
from types import SimpleNamespace

import numpy as np
from scipy.optimize import minimize

import matching_baseline as mb


def fixture(channels, pmin="1/20", pmax="3/2", budget="2"):
    """Exact rational gains/correlations from HAND-DECLARED binary64 channels."""
    h = np.asarray(channels, complex)
    k, m, s_count = h.shape
    real = [[[F.from_float(float(z.real)) for z in h[i, :, s]] for s in range(s_count)] for i in range(k)]
    imag = [[[F.from_float(float(z.imag)) for z in h[i, :, s]] for s in range(s_count)] for i in range(k)]
    rows = []
    for s in range(s_count):
        for i, j in itertools.combinations(range(k), 2):
            gi = sum((x*x+y*y for x, y in zip(real[i][s], imag[i][s])), F(0))
            gj = sum((x*x+y*y for x, y in zip(real[j][s], imag[j][s])), F(0))
            real_inner = sum((a*b+c*d for a,c,b,d in zip(real[i][s], imag[i][s], real[j][s], imag[j][s])), F(0))
            imag_inner = sum((a*d-c*b for a,c,b,d in zip(real[i][s], imag[i][s], real[j][s], imag[j][s])), F(0))
            r = (real_inner**2+imag_inner**2)/gi/gj if gi*gj else F(0)
            rows.append(dict(users=[i,j], resource=s, gain1=str(gi), gain2=str(gj), r=str(r)))
    return {"name":"ANALYTIC-FIXTURE-ONLY", "K":k, "M":m, "S":s_count,
            "pmin":pmin, "pmax":pmax, "budget":budget, "pairs":rows,
            "channels_re":h.real.tolist(), "channels_im":h.imag.tolist()}


def dense_fixture():
    # K4, M3, S2; fixed hand-written binary rational values, no random channels.
    return fixture(np.array([
        [[1, .5], [.25j, 1j], [.5, -.25]],
        [[.5+.5j, 1], [1, -.5j], [-.25j, .25]],
        [[-.5, .25j], [.75, 1], [.5j, -.5]],
        [[1j, -.75], [-.5, .5], [.25, .5j]],
    ], dtype=complex))


def independent_schedule_check(case, result):
    """Separate rational feasibility and scalar q formula; imports no solver helper."""
    schedule = result["schedule"]
    assert len(schedule) == case["S"]
    users, resources, power_sum, rates = [], [], F(0), []
    rows = {(tuple(sorted(x["users"])),x["resource"]):x for x in case["pairs"]}
    for row in schedule:
        assert len(row["users"]) == 2 and len(row["powers"]) == 2
        i,j = row["users"]
        users.extend([i,j]); resources.append(row["resource"])
        p,q = map(F,row["powers"])
        assert F(case["pmin"]) <= p <= F(case["pmax"])
        assert F(case["pmin"]) <= q <= F(case["pmax"])
        power_sum += p+q
        coefficients = rows[(tuple(sorted([i,j])),row["resource"])]
        # Fixture rows and exported schedule are both ordered by user.
        assert i<j
        x,y = F(coefficients["gain1"])*p,F(coefficients["gain2"])*q
        d=1+x+y+(1-F(coefficients["r"]))*x*y
        rates.append(2*math.log(float(d))-math.log1p(float(x))-math.log1p(float(y)))
    assert sorted(users) == list(range(case["K"]))
    assert sorted(resources) == list(range(case["S"]))
    assert power_sum <= F(case["budget"])
    if result["rate_nats"] is not None:
        assert math.isclose(math.fsum(rates), result["rate_nats"], rel_tol=1e-11, abs_tol=1e-11)
    return str(F(case["budget"])-power_sum)


def full_frozen_surrogate(h, assignment, powers, u, w):
    """Direct MSE expansion, not implemented via matching scores."""
    total=0.0
    for s in range(h.shape[2]):
        ids=assignment[2*s:2*s+2]
        for slot,user in enumerate(ids,2*s):
            mse=1+np.vdot(u[slot],u[slot]).real
            for interferer in ids:
                mse += powers[interferer]*abs(np.vdot(u[slot],h[interferer,:,s]))**2
            mse-=2*math.sqrt(powers[user])*np.vdot(u[slot],h[user,:,s]).real
            total += math.log(w[slot])-w[slot]*mse+1
    return float(total)


def check_dense_assignment():
    case=dense_fixture(); problem=mb._Problem(case); problem.validate_channels()
    h=problem.h; assignment=np.arange(4); p=np.array([.125,.375,.625,.875])
    u,w=mb._mmse(h,assignment,p); scores=mb._assignment_scores(h,p,u,w)
    const=sum(math.log(w[a])-w[a]+1-w[a]*np.vdot(u[a],u[a]).real for a in range(4))
    values=[]; max_representation_error=0.0; max_rate_error=0.0
    for perm in itertools.permutations(range(4)):
        pi=np.array(perm)
        score=sum(scores[user,a] for a,user in enumerate(perm))
        direct=full_frozen_surrogate(h,pi,p,u,w)
        max_representation_error=max(max_representation_error,abs(direct-(score+const)))
        assert abs(direct-(score+const))<1e-11
        scalar=problem.scalar_rate(pi,p); matrix=mb._matrix_rate(h,pi,p)
        max_rate_error=max(max_rate_error,abs(scalar-matrix))
        assert abs(scalar-matrix)<1e-11
        assert direct <= scalar+1e-11
        values.append(score)
    chosen=mb._perfect_assignment(scores)
    hungarian=sum(scores[user,a] for a,user in enumerate(chosen))
    assert abs(hungarian-max(values))<1e-11
    assert abs(full_frozen_surrogate(h,assignment,p,u,w)-problem.scalar_rate(assignment,p))<1e-11
    assert problem.scalar_rate(chosen,p)>=problem.scalar_rate(assignment,p)-1e-11
    # Full service must hold even when every score is negative.
    negative=mb._perfect_assignment(-np.arange(1,17).reshape(4,4))
    assert sorted(negative)==list(range(4))
    return dict(permutations=24,max_surrogate_representation_error=max_representation_error,
                max_matrix_scalar_error=max_rate_error,chosen_assignment=chosen.tolist(),
                hungarian_score=hungarian,brute_best_score=max(values))


def check_amplitudes():
    a=np.array([.3,1.1,.7,2.0]);b=np.array([.9,.6,1.3,.2])
    lower,upper,cap=F(1,20),F(3,2),F(2)
    p,count=mb._amplitude_update(a,b,lower,upper,cap)
    v=np.sqrt(p)
    objective=lambda z:float(np.sum(a*z*z-2*b*z))
    opt=minimize(objective,np.full(4,.5),jac=lambda z:2*a*z-2*b,method="SLSQP",
                 bounds=[(math.sqrt(float(lower)),math.sqrt(float(upper)))]*4,
                 constraints=[{"type":"ineq","fun":lambda z:float(cap)-np.dot(z,z),"jac":lambda z:-2*z}],
                 options={"ftol":1e-11,"maxiter":100})
    assert opt.success,opt.message
    assert objective(v)<=opt.fun+1e-9
    exact=mb._rational_powers(p,lower,upper,cap)
    assert sum(exact,F(0))<=cap
    zeros,_=mb._amplitude_update(np.zeros(4),np.zeros(4),lower,upper,cap)
    assert np.all(zeros==float(lower))
    degenerate,_=mb._amplitude_update(a,b,F(1,10),F(2),F(2,5))
    assert np.all(degenerate==.1)
    return dict(bisection_iterations=count,convex_objective=objective(v),
                independent_slsqp_objective=float(opt.fun),budget_slack=str(cap-sum(exact,F(0))))


def check_nontrivial_matching_and_m8():
    h=np.zeros((4,8,2),complex)
    h[0,0,:]=[.25,2];h[1,1,:]=[.25,2]
    h[2,0,:]=[2,.25];h[3,1,:]=[2,.25]
    problem=mb._Problem(fixture(h));assignment=np.arange(4);p=np.full(4,.5)
    u,w=mb._mmse(h,assignment,p)
    scores=mb._assignment_scores(h,p,u,w);chosen=mb._perfect_assignment(scores)
    before=problem.scalar_rate(assignment,p);after=problem.scalar_rate(chosen,p)
    assert not np.array_equal(chosen,assignment)
    assert set(chosen[:2])=={2,3} and set(chosen[2:])=={0,1}
    assert after>before
    assert full_frozen_surrogate(h,chosen,p,u,w)>=before-1e-12
    # Dense complex analytic channels embedded in M8, with a wide scale change.
    base=mb._Problem(dense_fixture()).h
    discrepancies=[]
    for scale in (1,256):
        embedded=np.zeros((4,8,2),complex);embedded[:,:3,:]=scale*base
        extended=mb._Problem(fixture(embedded))
        extended.validate_channels()
        scalar=extended.scalar_rate(assignment,p);matrix=mb._matrix_rate(embedded,assignment,p)
        assert abs(scalar-matrix)<=mb.RATE_CHECK_ATOL+mb.RATE_CHECK_RTOL*abs(scalar)
        discrepancies.append(abs(scalar-matrix))
    result=mb.solve(fixture(h),seconds=10)
    assert result["status"]=="completed"
    independent_schedule_check(fixture(h),result)
    assert result["rate_nats"]>before
    return dict(chosen=chosen.tolist(),initial_rate_nats=before,matched_rate_nats=after,
                m8_scale_matrix_scalar_errors=discrepancies,solver_status=result["status"])


def check_solver():
    case=dense_fixture();snapshots=[]
    result=mb.solve(case,seconds=10,seed=1101,progress=lambda payload:snapshots.append(copy.deepcopy(payload)))
    assert result["status"]=="completed",result
    slack=independent_schedule_check(case,result)
    assert result["global_upper_bound"] is None
    assert result["metrics"]["starts_started"]==9
    assert result["metrics"]["starts_completed"]==9
    for record in result["metrics"]["start_records"]:
        assert all(b>=a for a,b in zip(record["trace"],record["trace"][1:]))
    history=[r["rate_nats"] for r in result["metrics"]["incumbent_history"]]
    assert all(b>a for a,b in zip(history,history[1:]))
    for snap in snapshots: independent_schedule_check(case,snap)
    second=mb.solve(case,seconds=10,seed=1101)
    assert second["status"]=="completed"
    assert second["schedule"]==result["schedule"]
    assert second["rate_nats"]==result["rate_nats"]
    assert result["metrics"]["matching_calls"]>0
    assert result["metrics"]["exchange_candidates"]>0
    assert result["rate_nats"]>=result["metrics"]["start_records"][0]["initial_rate_nats"]
    return dict(status=result["status"],rate_nats=result["rate_nats"],
                budget_slack=slack,snapshots=len(snapshots),metrics=result["metrics"])


def check_degeneracies_and_status():
    records=[]
    # Zero channels, positive exact decimal minimum, and degenerate total budget.
    zero=fixture(np.zeros((4,2,2)),pmin="1/10",pmax="2",budget="2/5")
    result=mb.solve(zero,seconds=5)
    assert result["status"]=="completed",result
    assert result["rate_nats"]==0
    independent_schedule_check(zero,result)
    assert all(F(p)==F(1,10) for row in result["schedule"] for p in row["powers"])
    records.append({"case":"zero_and_degenerate","status":result["status"]})
    # Orthogonal, parallel, a zero user, and fixed power box.
    geometries=[np.array([[[1],[0]],[[0],[2]]],complex),
                np.array([[[1],[.5j]],[[2],[1j]]],complex),
                np.array([[[0],[0]],[[1],[1j]]],complex)]
    for index,h in enumerate(geometries):
        case=fixture(h,pmin="1/3",pmax="1/3",budget="2/3")
        result=mb.solve(case,seconds=5)
        assert result["status"]=="completed",result
        independent_schedule_check(case,result)
        records.append({"case":f"geometry_{index}","status":result["status"],"rate_nats":result["rate_nats"]})
    # Immediate deadline: still provide a rational-feasible fallback; no upper claim.
    case=dense_fixture();timeout=mb.solve(case,seconds=0)
    assert timeout["status"]=="time_limit"
    independent_schedule_check(case,timeout)
    assert timeout["metrics"]["starts_started"]==0
    # Deterministic injected clock: callback work consumes the cooperative budget.
    now=[0.0]
    def slow_callback(payload):now[0]+=.1
    original_clock=mb.time
    try:
        mb.time=SimpleNamespace(perf_counter=lambda:now[0])
        timed=mb.solve(case,seconds=.05,progress=slow_callback)
    finally:mb.time=original_clock
    assert timed["status"]=="time_limit"
    independent_schedule_check(case,timed)
    assert timed["metrics"]["progress_calls"]==1
    def mutating_callback(payload):payload["schedule"][0]["powers"][0]="0"
    isolated=mb.solve(case,seconds=5,progress=mutating_callback)
    assert isolated["status"]=="completed"
    independent_schedule_check(case,isolated)
    # Persistence failures remain distinct, with a retained in-memory incumbent.
    def failing_callback(payload): raise OSError("injected persistence failure")
    failed=mb.solve(case,seconds=5,progress=failing_callback)
    assert failed["status"]=="progress_error"
    independent_schedule_check(case,failed)
    # Matrix/table inconsistency must be detected, not optimized silently.
    corrupt=copy.deepcopy(case);corrupt["pairs"][0]["gain1"]="99"
    mismatch=mb.solve(corrupt,seconds=5)
    assert mismatch["status"]=="invalid_input"
    assert "disagree" in mismatch["errors"][0]["message"]
    # Explicit numerical failure classification and preservation of fallback.
    original=mb._mmse
    def broken(*args):raise np.linalg.LinAlgError("injected solve failure")
    try:
        mb._mmse=broken
        failure=mb.solve(case,seconds=5)
        assert failure["status"]=="numerical_error"
        independent_schedule_check(case,failure)
    finally:mb._mmse=original
    return dict(cases=records,timeout_status=timeout["status"],callback_status=failed["status"],
                slow_callback_elapsed=timed["metrics"]["elapsed_seconds"],
                inconsistency_status=mismatch["status"],numerical_status=failure["status"])


def check_permutation_covariance():
    case=dense_fixture();problem=mb._Problem(case)
    p=np.array([.125,.375,.625,.875]);assignment=np.array([0,3,1,2])
    reference=problem.scalar_rate(assignment,p)
    order=np.array([2,0,3,1]);inverse=np.argsort(order)
    transformed=mb._Problem(fixture(problem.h[order,:,:]))
    assert abs(transformed.scalar_rate(inverse[assignment],p[order])-reference)<1e-12
    resource_swap=mb._Problem(fixture(problem.h[:,:,::-1]))
    swapped_assignment=np.r_[assignment[2:],assignment[:2]]
    assert abs(resource_swap.scalar_rate(swapped_assignment,p)-reference)<1e-12
    # Slot order has no physical effect, though assignment surrogate auxiliaries follow it.
    flipped=np.r_[assignment[:2][::-1],assignment[2:][::-1]]
    assert abs(problem.scalar_rate(flipped,p)-reference)<1e-12
    u,w=mb._mmse(problem.h,assignment,p)
    u2,w2=mb._mmse(transformed.h,inverse[assignment],p[order])
    assert np.allclose(u,u2,rtol=1e-12,atol=1e-12)
    assert np.allclose(w,w2,rtol=1e-12,atol=1e-12)
    scores=mb._assignment_scores(problem.h,p,u,w)
    scores2=mb._assignment_scores(transformed.h,p[order],u2,w2)
    assert np.allclose(scores[order],scores2,rtol=1e-12,atol=1e-12)
    return {"rate_nats":reference,"user_relabel":True,"resource_relabel":True,"slot_swap":True,
            "algorithm_output_permutation_invariance_claimed":False}


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    started=time.perf_counter()
    report={"scope":"hand-declared analytic fixtures; no prospective data", "checks":{},"status":"PASS"}
    for test in (check_dense_assignment,check_amplitudes,check_nontrivial_matching_and_m8,check_solver,
                 check_degeneracies_and_status,check_permutation_covariance):
        report["checks"][test.__name__]=test()
    report["elapsed_seconds"]=time.perf_counter()-started
    report["implementation_sha256"]=hashlib.sha256(Path(mb.__file__).read_bytes()).hexdigest()
    report["checks_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    encoded=json.dumps(report,indent=2,allow_nan=False)
    if args.output:args.output.write_text(encoded,encoding="utf-8")
    print(json.dumps({"status":report["status"],"checks":list(report["checks"]),
                      "elapsed_seconds":report["elapsed_seconds"]}))


if __name__=="__main__":main()
