"""Declared publication, corruption and interruption fixtures, not science trials."""
from pathlib import Path
import json,time,sys,subprocess,hashlib
from persistence import publish,read_receipt,digest
D=Path(__file__).resolve().parents[1]/'preflight/persistence'

def main():
    D.mkdir(parents=True,exist_ok=False);checks=[];t=time.monotonic()
    original=publish(D/'immutable.json',{'v':1})
    with (D/'immutable.json').open('rb') as reader:
        publish(D/'next.json',{'v':2});assert json.loads(reader.read())=={'v':1}
    assert digest(D/'immutable.json')==original['sha256'];checks.append('Reader-held old file does not block new-name publication')
    try:publish(D/'immutable.json',{'v':3});raise AssertionError('overwrite accepted')
    except FileExistsError:checks.append('Existing published file cannot be replaced')
    def interrupt(phase,path):raise RuntimeError('injected interruption')
    try:publish(D/'interrupted.json',{'v':4},hook=interrupt)
    except RuntimeError:pass
    assert not (D/'interrupted.json').exists() and list(D.glob('*.partial'));checks.append('Interrupted closed temp is not reader-visible')
    blocker=D/'blocked';blocker.write_text('not a directory')
    try:publish(blocker/'result.json',{'v':5});raise AssertionError('bad destination accepted')
    except (FileExistsError,NotADirectoryError):checks.append('Storage-path fault raises without recursive publisher')
    now=time.perf_counter();attempt={'started_at':now,'deadline':now+10,'case_sha256':'fixture'};publish(D/'attempt.json',attempt)
    publish(D/'candidate.json',{'x':1});rec={'attempt_sha256':digest(D/'attempt.json'),'case_sha256':'fixture','candidate_file':'candidate.json','candidate_sha256':digest(D/'candidate.json'),'validated_at':now+1}
    publish(D/'receipt.json',rec);assert read_receipt(D,'receipt.json',attempt)[0]=={'x':1};checks.append('Intact receipt validated')
    late=dict(rec,validated_at=now+11);publish(D/'late.json',late)
    try:read_receipt(D,'late.json',attempt);raise AssertionError('late accepted')
    except ValueError:checks.append('Late receipt rejected')
    (D/'candidate.json').write_text('{"x":99}')
    try:read_receipt(D,'receipt.json',attempt);raise AssertionError('tamper accepted')
    except ValueError:checks.append('Tampered candidate rejected')
    try:read_receipt(D,'absent.json',attempt);raise AssertionError('missing accepted')
    except FileNotFoundError:checks.append('Missing receipt not reconstructed as success')
    # Controlled child killed after a durable old publication: no optimizer involved.
    script=D/'kill_fixture.py';script.write_text('import time\nfrom pathlib import Path\nPath(__file__).with_suffix(".ready").write_text("ready")\ntime.sleep(30)\n')
    process=subprocess.Popen([sys.executable,str(script)],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    end=time.monotonic()+3
    while not script.with_suffix('.ready').exists() and time.monotonic()<end:time.sleep(.01)
    process.kill();process.wait(timeout=3);assert digest(D/'immutable.json')==original['sha256'];checks.append('Owned-child kill preserves prior immutable evidence')
    result={'checks':checks,'pass':True,'seconds':time.monotonic()-t,'limits':'No claim of proven historical Windows root cause; path fault simulates unavailable storage, not physical disk exhaustion.'}
    (D.parent/'PERSISTENCE_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
