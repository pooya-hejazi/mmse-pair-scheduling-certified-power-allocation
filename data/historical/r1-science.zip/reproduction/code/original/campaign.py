"""One fixed prospective campaign; all cases recorded, no reruns."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,sys,time,subprocess,argparse,hashlib
import numpy as np
import psutil
from persistence import publish
from generate_cases import check_gate
from controller import launch
W=Path(__file__).resolve().parents[1];D=Path(__file__).parent

def run_bounded(cmd,stream,seconds):
    """Owned subprocess tree, wall/RSS caps; no retry or inherited console."""
    began=time.perf_counter();proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    parent=psutil.Process(proc.pid)
    try:
        while proc.poll() is None:
            try:members=[parent]+parent.children(recursive=True)
            except psutil.Error:members=[]
            rss=0
            for member in members:
                try:rss+=member.memory_info().rss
                except psutil.Error:pass
            if rss>8*1024**3:raise MemoryError('worker tree exceeds registered 8GiB RSS')
            if time.perf_counter()-began>=seconds:raise subprocess.TimeoutExpired(cmd,seconds)
            time.sleep(.02)
        return subprocess.CompletedProcess(cmd,proc.returncode)
    finally:
        if proc.poll() is None:
            try:children=parent.children(recursive=True)
            except psutil.Error:children=[]
            for child in reversed(children):
                try:child.kill()
                except psutil.Error:pass
            proc.kill();proc.wait()

def validate_generation(target,scene):
    """An entire scene is eligible only with all registered, hash-matched cases."""
    report=json.loads((target/'generation.json').read_text())
    expected={f'{scene}-{panel}-{i:02d}' for panel,n in [('main',12),('scale',4)] for i in range(n)}
    rows=report['cases'];assert report['scene']==scene and len(rows)==16 and {r['name'] for r in rows}==expected
    assert hashlib.sha256((target/'pool.npz').read_bytes()).hexdigest()==report['source_pool_sha256']
    for row in rows:
        p=target/(row['name']+'.json');assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
        case=json.loads(p.read_text());assert case['name']==row['name'] and case['metadata']['scene']==scene
    return True

def account_diagnostics(folder):
    names=[f'c{c}-g{g}-s{s}' for c in [0.,.85] for g in [1.,100.] for s in [202611240,202611241]]
    ledger=folder/'diagnostic-ledger.json'
    existing={r['case']:r for r in json.loads(ledger.read_text())} if ledger.exists() else {}
    return [existing.get(n,{'case':n,'status':'INTERRUPTED_DIAGNOSTIC' if (folder/n/'case.json').exists() else 'NOT_RUN_DIAGNOSTIC_BLOCK','raw_files':[p.name for p in (folder/n).glob('*')]}) for n in names]

def dispatch_plan():
    rng=np.random.default_rng(202611230);blocks=[]
    for panel,n,methods,charged in [('main',12,['grid','curvature','full','joint'],18),('scale',4,['grid','pricing','joint'],28)]:
        for scene in ['o1','asu']:
            for i in range(n):
                case=f'{scene}-{panel}-{i:02d}'
                blocks.append([dict(panel=panel,scene=scene,index=i,case=case,method=str(m),charged=charged,seed=1101+i+(100 if scene=='asu' else 0)) for m in rng.permutation(methods)])
    reps=[dict(panel='reliability',scene='analytic',index=i,case='registered-reliability-fixture',method=m,charged=8,seed=1101) for i in range(2) for m in ['grid','curvature','full','joint']]
    np.random.default_rng(202611250).shuffle(reps);blocks.extend([[r] for r in reps]);return blocks

def main(a):
    check_gate(a.go);out=Path(a.output);out.mkdir(parents=True,exist_ok=False);began=time.perf_counter();stop=began+3600
    plan=dispatch_plan();publish(out/'LOCK.json',{'started_at':began,'deadline':stop,'go_sha256':hashlib.sha256(Path(a.go).read_bytes()).hexdigest(),'scope':'One prospective campaign. No scientific cell rerun.'})
    publish(out/'dispatch-plan.json',plan);generated={}
    fixture=W/'preflight/integration/case.json';fixture_dest=out/'inputs/reliability/registered-reliability-fixture.json'
    published=publish(fixture_dest,json.loads(fixture.read_text()))
    publish(out/'reliability-input.json',{'source_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'artifact_sha256':published['sha256'],'artifact_path':fixture_dest.relative_to(out).as_posix()})
    for scene in ['o1','asu']:
        target=out/'inputs'/scene
        with (out/(scene+'-generation.log')).open('xb') as stream:
            try:
                cp=run_bounded(['C:/ProgramData/anaconda3/envs/6g_project/python.exe','-B',str(D/'generate_cases.py'),'--go',str(Path(a.go).resolve()),'--scene',scene,'--output',str(target.resolve())],stream,min(200,max(1,stop-time.perf_counter()-3200)))
                generated[scene]={'returncode':cp.returncode,'complete':cp.returncode==0 and validate_generation(target,scene)}
            except subprocess.TimeoutExpired:generated[scene]={'complete':False,'status':'GENERATION_TIME_LIMIT'}
            except Exception as e:generated[scene]={'complete':False,'status':'GENERATION_ERROR','error':repr(e)}
    publish(out/'generation-status.json',generated);rows=[]
    for bi,block in enumerate(plan):
        reserve=sum(r['charged']+2 for r in block)+120
        enough=time.perf_counter()+reserve<stop
        for row in block:
            name=f"{row['case']}-{row['method']}"+(f"-repeat{row['index']}" if row['panel']=='reliability' else '')
            case=fixture_dest if row['panel']=='reliability' else out/'inputs'/row['scene']/(row['case']+'.json')
            eligible=row['panel']=='reliability' or generated.get(row['scene'],{}).get('complete',False)
            reason='NOT_RUN_RESOURCE_LIMIT' if not enough else ('NOT_RUN_GENERATION_FAILURE' if not eligible or not case.exists() else None)
            if reason:
                record=dict(row,status=reason,operational_success=None,mathematical_success=None)
                target=out/'cells'/name;target.mkdir(parents=True,exist_ok=False);publish(target/'result.json',record)
            else:
                try:record=launch(case,row,out/'cells'/name)
                except Exception as e:
                    record=dict(row,status='CONTROLLER_UNCAUGHT',error=repr(e),operational_success=False,mathematical_success=False)
                    # Preserve partial cell; separate accounting name, never overwrite.
                    publish(out/'cells'/name/'outer-error.json',record)
            rows.append(record)
        print(json.dumps({'block':bi+1,'blocks':len(plan),'elapsed':time.perf_counter()-began}),flush=True)
    with (out/'diagnostics.log').open('xb') as stream:
        try:
            remaining=min(180,max(1,stop-time.perf_counter()-120))
            cp=run_bounded([sys.executable,'-B',str(D/'diagnostics.py'),'--go',str(Path(a.go).resolve()),'--output',str((out/'diagnostics').resolve())],stream,remaining)
            diag={'returncode':cp.returncode}
        except subprocess.TimeoutExpired:diag={'status':'DIAGNOSTIC_TIME_LIMIT'}
        except Exception as e:diag={'status':'DIAGNOSTIC_ERROR','error':repr(e)}
    publish(out/'diagnostic-accounting.json',account_diagnostics(out/'diagnostics'))
    publish(out/'campaign-ledger.json',{'rows':rows,'planned_cells':128,'diagnostics':diag,'elapsed_seconds':time.perf_counter()-began,'status':'PLANNED_DISPATCH_ACCOUNTED'})
    assert len(rows)==128
    # The registered 120-second postprocessing block is part of this same cap.
    post_stop=min(stop,time.perf_counter()+120);post={}
    for script,cap in [('analyze.py',20),('replay_certificates.py',120)]:
        available=min(cap,max(0,post_stop-time.perf_counter()))
        if available<=0:post[script]={'status':'NOT_RUN_RESOURCE_LIMIT'};continue
        with (out/(script+'.log')).open('xb') as stream:
            try:
                cmd=[sys.executable,'-B',str(D/script),str(out.resolve())]
                if script=='replay_certificates.py':cmd+=['--seconds',str(max(0,available-1))]
                cp=run_bounded(cmd,stream,available);post[script]={'returncode':cp.returncode}
            except Exception as e:post[script]={'status':'POSTPROCESSING_ERROR','error':repr(e)}
    publish(out/'POSTPROCESSING.json',{'steps':post,'total_campaign_seconds':time.perf_counter()-began,'within_3600_seconds':time.perf_counter()<=stop})
    print(json.dumps({'cells':len(rows),'elapsed':time.perf_counter()-began,'diagnostics':diag}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--go',required=True);p.add_argument('--output',required=True);main(p.parse_args())
