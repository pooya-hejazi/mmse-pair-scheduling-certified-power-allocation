"""Generate preregistered channels only after the CP-S07 GO/hash gate."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json,hashlib,argparse,sys,time
import numpy as np
W=Path(__file__).resolve().parents[1];R=W.parents[1]

def convert(h,name,metadata):
    K,M,S=h.shape;h=np.asarray(h,dtype=np.complex128);g={};vectors={};pairs=[]
    for u in range(K):
        for s in range(S):
            a=[(F(float(z.real)),F(float(z.imag))) for z in h[u,:,s]]
            vectors[u,s]=a;g[u,s]=sum(x*x+y*y for x,y in a)
    for u,v in combinations(range(K),2):
        for s in range(S):
            re=sum(x*a+y*b for (x,y),(a,b) in zip(vectors[u,s],vectors[v,s]))
            im=sum(x*b-y*a for (x,y),(a,b) in zip(vectors[u,s],vectors[v,s]))
            r=(re*re+im*im)/(g[u,s]*g[v,s]) if g[u,s]*g[v,s] else F(0)
            pairs.append(dict(users=[u,v],resource=s,gain1=str(g[u,s]),gain2=str(g[v,s]),r=str(r)))
    return dict(name=name,K=K,M=M,S=S,pmin='1/20',pmax='1/5',budget=str(F(K,10)),pairs=pairs,
                channels_re=h.real.tolist(),channels_im=h.imag.tolist(),metadata=metadata)

def check_gate(go):
    marker=json.loads(Path(go).read_text())
    assert marker['checkpoint']=='CP-S07' and marker['verdict']=='PASS'
    for row in marker['source_files']:
        assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
    for row in marker.get('external_readonly_inputs',[]):
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']

def main():
    a=argparse.ArgumentParser();a.add_argument('--go',required=True);a.add_argument('--scene',choices=['o1','asu'],required=True);a.add_argument('--output',required=True);args=a.parse_args()
    check_gate(args.go);out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    import DeepMIMOv3 as dm
    scene=args.scene;folder=R/'DeepMIMO_sena' if scene=='o1' else W/'downloads/scene';name='O1_60' if scene=='o1' else 'asu_campus1'
    p=dm.default_params();p['dataset_folder']=str(folder);p['scenario']=name;p['active_BS']=np.array([1]);p['num_paths']=10
    p['user_rows']=np.arange(301,321) if scene=='o1' else np.arange(1,21);p['enable_BS2BS']=0
    p['bs_antenna']['shape']=np.array([1,8,1]);p['ue_antenna']['shape']=np.array([1,1,1])
    p['OFDM']['bandwidth']=.05;p['OFDM']['subcarriers']=32;p['OFDM']['selected_subcarriers']=np.arange(32)
    t=time.monotonic();data=dm.generate_data(p);H=data[0]['user']['channel'][:,0,:,:];loc=data[0]['user']['location']
    assert H.shape[1:]==(8,32) and np.isfinite(H).all()
    if scene=='o1':
        now=set(map(tuple,loc.tolist()))
        for old in [R/'research/reproduction/channels.npz',R/'research/completion-20261031/csi-forward/run-01/channels.npz',R/'research/completion-20261031/confirmation/run-01-inputs/channels32.npz']:
            with np.load(old) as z:assert not now.intersection(map(tuple,z['location'].tolist())),str(old)
    np.savez_compressed(out/'pool.npz',H=H,location=loc)
    noise=10**((-174+7-30)/10)*(50e6/32);rows=[];source_hash=hashlib.sha256((out/'pool.npz').read_bytes()).hexdigest()
    for panel,N,K,seed,resources in [('main',12,8,202611210 if scene=='o1' else 202611211,[0,8,16,24]),('scale',4,16,202611220 if scene=='o1' else 202611221,list(range(0,32,4)))]:
        rng=np.random.default_rng(seed)
        for i in range(N):
            ids=rng.choice(len(H),K,replace=False)
            h=(np.sqrt(32)*H[ids]).astype(np.complex128)[:,:,resources]/np.sqrt(noise)
            case_name=f'{scene}-{panel}-{i:02d}'
            meta=dict(scene=scene,scene_name=name,frequency_Hz=60e9 if scene=='o1' else 3.5e9,noise_W=noise,indices=ids.tolist(),resources=resources,seed=seed,pool_sha256=source_hash,
                      scope='Conditional IID network draws within this fixed scene; users may repeat across networks; M8 single AP differs from historical M32 four-AP experiment')
            case=convert(h,case_name,meta);path=out/(case_name+'.json');path.write_text(json.dumps(case,indent=2),encoding='utf-8')
            rows.append(dict(name=case_name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),indices=ids.tolist()))
    report=dict(scene=scene,cases=rows,source_pool_sha256=source_hash,shape=list(H.shape),seconds=time.monotonic()-t,params=p,
                all_weak_zero_channels_retained=True,coordinate_disjointness=(scene=='o1'),frequency_is_scene_specific=True)
    (out/'generation.json').write_text(json.dumps(report,indent=2,default=lambda z:z.tolist() if hasattr(z,'tolist') else str(z)),encoding='utf-8')
    print(json.dumps({'scene':scene,'cases':len(rows),'seconds':report['seconds']}))

if __name__=='__main__':main()
