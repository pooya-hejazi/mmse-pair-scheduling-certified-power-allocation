from pathlib import Path
import json,time,sys
from fractions import Fraction as F
from checks_math import fixture
import controller
from persistence import digest,read_receipt

def main():
    W=Path(__file__).resolve().parents[1];D=W/'preflight/integration';D.mkdir(parents=True,exist_ok=False)
    case,_=fixture();case.update(name='registered-reliability-fixture',pmin='1/20',pmax='1/5',budget='2/5')
    path=D/'case.json';path.write_text(json.dumps(case,indent=2));t=time.monotonic();rows=[]
    for method in ['grid','curvature','full','joint']:
        row=dict(panel='development_fixture',case=case['name'],method=method,charged=8,seed=1101)
        out=D/method;r=controller.launch(path,row,out);assert r['normal'],r
        assert r['lower_nats'] is not None and F(r['lower_nats'])<=F(r['upper_nats'])
        for rr in r['receipts']:
            assert digest(out/rr['file'])==rr['sha256']
            candidate,receipt=read_receipt(out,rr['file'],json.loads((out/'attempt.json').read_text()))
            if rr['timely']:assert rr['completed_at']<=json.loads((out/'attempt.json').read_text())['deadline']
        rows.append({k:r[k] for k in ['method','normal','elapsed','gap_nats','operational_success','verification_timeouts']})
    # Exercise controller watchdog and missing worker status with a harmless sleeping fixture.
    fake=D/'fake-worker';fake.mkdir();(fake/'worker.py').write_text('import time\ntime.sleep(30)\n')
    original=controller.D;controller.D=fake
    r=controller.launch(path,dict(panel='fault',case=case['name'],method='grid',charged=.25,seed=1101),D/'watchdog')
    controller.D=original;assert r['status']=='EXTERNAL_WATCHDOG' and not r['normal'] and not r['operational_success']
    assert r['lower_nats'] is not None;rows.append({'fault':'owned worker hung','status':r['status'],'fallback_retained':True})
    report={'pass':True,'seconds':time.monotonic()-t,'rows':rows,'fixture_sha256':digest(path),'scope':'Five development/fault cells only; no prospective outcomes'}
    (W/'preflight/INTEGRATION_CHECKS.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
