"""Prespecified synthetic mechanism controls; only called after campaign GO."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,time,subprocess,sys
import numpy as np
from generate_cases import convert,check_gate
from persistence import publish

def oracle_child(a):
    p=Path(__file__).resolve().parents[3]/'research/completion-20261031/confirmation'
    sys.path.insert(0,str(p));from nominal_worker import price
    inp=json.loads(Path(a.input).read_text());t=time.perf_counter()
    result=price(*map(F,[inp[k] for k in ['g1','g2','r','lam','lo','hi']]))
    publish(a.output,{'result':json.loads(json.dumps(result,default=str)),'seconds':time.perf_counter()-t})

def main(a):
    check_gate(a.go);out=Path(a.output);out.mkdir(parents=True,exist_ok=False);stop=time.perf_counter()+180;records=[]
    import grid_core as grid,certificates,verify_upper
    for c in [0.,.85]:
        for gain in [1.,100.]:
            for seed in [202611240,202611241]:
                name=f'c{c}-g{gain}-s{seed}';d=out/name;d.mkdir()
                if time.perf_counter()+15>stop:
                    records.append({'case':name,'status':'NOT_RUN_RESOURCE_LIMIT'});continue
                rng=np.random.default_rng(seed)
                zc=(rng.standard_normal((1,4,2))+1j*rng.standard_normal((1,4,2)))/np.sqrt(2)
                zu=(rng.standard_normal((4,4,2))+1j*rng.standard_normal((4,4,2)))/np.sqrt(2)
                h=np.sqrt(gain/4)*(np.sqrt(c)*zc+np.sqrt(1-c)*zu)
                case=convert(h,name,{'synthetic':True,'mixture':c,'mean_gain':gain,'seed':seed,'scope':'Mechanism control; not ray tracing'})
                publish(d/'case.json',case);grid.NATIVE_CAP=.5;grid.GRID_LEVELS=[F(1,20),F(1,10),F(1,5)];grid.PROGRESS=lambda x:None
                began=time.perf_counter();initial=grid.solve(case,'grid',1.);setup=time.perf_counter()-began;publish(d/'common-grid.json',initial)
                rows=[]
                for mode in ['reference','curvature','full']:
                    certificates.clear_caches();verify_upper.clear_caches();t=time.perf_counter()
                    result=certificates.run(case,mode,initial['schedule'],initial if 'alpha' in initial else None,seconds=2)
                    search_seconds=time.perf_counter()-t;publish(d/(mode+'-proof.json'),result)
                    try:v=verify_upper.verify(case,result,seconds=2);status='VERIFIED'
                    except Exception as e:v={'error':repr(e)};status='VERIFICATION_ERROR'
                    row=dict(method=mode,status=status,search_seconds=search_seconds,total_seconds=time.perf_counter()-t,verification=v)
                    publish(d/(mode+'-result.json'),row);rows.append(row)
                # Fixed first pair: exact polynomial oracle diagnostic, no network certificate.
                first=case['pairs'][0];params=dict(g1=first['gain1'],g2=first['gain2'],r=first['r'],lam=initial.get('lambda','0'),lo=case['pmin'],hi=case['pmax'])
                publish(d/'oracle-input.json',params)
                with (d/'oracle.log').open('xb') as f:
                    try:
                        cp=subprocess.run([sys.executable,'-B',str(Path(__file__)),'--oracle','--input',str(d/'oracle-input.json'),'--output',str(d/'oracle-result.json')],stdout=f,stderr=subprocess.STDOUT,timeout=2)
                        oracle_status='RETURNED' if cp.returncode==0 else 'ERROR'
                    except subprocess.TimeoutExpired:oracle_status='TIME_LIMIT'
                t=time.perf_counter()
                pair=certificates.price_pair(*map(F,[params[k] for k in ['g1','g2','r','lam','lo','hi']]),seconds=.25)
                publish(d/'generic-price.json',pair)
                try:pair_verified=verify_upper.verify_pair(pair,seconds=2)
                except Exception as e:pair_verified={'valid':False,'error':repr(e)}
                publish(d/'generic-price-verification.json',pair_verified)
                records.append(dict(case=name,status='COMPLETE',common_setup_seconds=setup,rows=rows,oracle_status=oracle_status,generic_price_seconds=time.perf_counter()-t,pair_verification=pair_verified))
    publish(out/'diagnostic-ledger.json',records);print(json.dumps({'records':len(records),'completed':sum(r['status']=='COMPLETE' for r in records)}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--oracle',action='store_true');p.add_argument('--go');p.add_argument('--input');p.add_argument('--output',required=True);a=p.parse_args()
    if a.oracle:oracle_child(a)
    else:main(a)
