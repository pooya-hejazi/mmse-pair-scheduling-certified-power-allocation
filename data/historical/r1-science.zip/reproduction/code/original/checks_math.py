"""Deterministic analytic fixtures only; never loads/generates prospective data."""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import combinations, product
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import time
import certificates as producer
import verify_upper as checker


def fixture(kind=0):
    # Four explicitly fixed rational 2D channels; not a statistical sample.
    channels = [[(1, 0), (1, 1)], [(0, 1), (1, -1)],
                [(1, 1), (2, 0)], [(1, -1), (0, 2)]]
    if kind == 1:
        channels = [[(0, 0), (0, 0)], *channels[1:]]
    if kind == 2:
        channels = [[(0, 0), (0, 0)] for _ in range(4)]
    rows = []
    for u, v in combinations(range(4), 2):
        for s in range(2):
            x, y = channels[u][s], channels[v][s]
            g, h = sum(F(t)**2 for t in x), sum(F(t)**2 for t in y)
            dot = sum(F(a)*b for a, b in zip(x, y))
            r = dot*dot/(g*h) if g*h else F(0)
            rows.append(dict(users=[u, v], resource=s, gain1=str(g), gain2=str(h), r=str(r)))
    pmin, pmax, budget = ('1/10', '1/2', '6/5') if kind != 3 else ('1/4', '1/4', '1')
    return dict(name='analytic-fixture-'+str(kind), K=4, S=2, M=2,
                pmin=pmin, pmax=pmax, budget=budget, pairs=rows,
                channels_re=[[[channels[i][t][j] for t in range(2)] for j in range(2)] for i in range(4)],
                channels_im=[[[0,0],[0,0]] for _ in range(4)]), channels


def must_reject(fn):
    try:
        fn()
    except (ValueError, KeyError, TypeError, TimeoutError):
        return
    raise AssertionError('invalid evidence accepted')


def symbolic_checks():
    import sympy as s
    x, y, a, l1, l2, t = s.symbols('x y a l1 l2 t')
    r = 1-a; A = 1+x; E = 1+y; d = 1+x+y+a*x*y
    q = 2*s.log(d)-s.log(A)-s.log(E)
    hxx, hyy, hxy = s.diff(q, x, 2), s.diff(q, y, 2), s.diff(q, x, y)
    assert s.cancel(hxx-(A**-2-2*(1+a*y)**2/d**2)) == 0
    assert s.cancel(hyy-(E**-2-2*(1+a*x)**2/d**2)) == 0
    assert s.cancel(hxy+2*r/d**2) == 0
    N = (2*A**2*(1+a*y)**2-d**2)*(2*E**2*(1+a*x)**2-d**2)-4*r*r*A*A*E*E
    assert s.cancel((hxx*hyy-hxy*hxy)*A*A*E*E*d**4-N) == 0
    coefficients = {(4,4):a**4, (4,3):4*a**4, (4,2):2*a*a*(a*a+4*a-2),
        (4,1):4*a*(a*a+a-1), (4,0):2*a*a-1, (3,3):4*a*a*(4*a*a-a+1),
        (3,2):4*a*(2*a**3+6*a*a-3*a+1), (3,1):4*a*(3*a*a+3*a-2),
        (3,0):4*(a*a+a-1), (2,2):2*(2*a**4+16*a**3-a*a+1),
        (2,1):4*(a+1)*(2*a*a+2*a-1), (2,0):2*(-a*a+8*a-4),
        (1,1):4*(7*a-3), (1,0):4*(2-a)*(2*a-1), (0,0):(3-2*a)*(2*a-1)}
    expected = sum(c*x**i*y**j+(c*x**j*y**i if i != j else 0)
                   for (i,j), c in coefficients.items())
    assert s.expand(N-expected) == 0
    assert hxx.subs({a:s.Rational(1,2),x:0,y:10}) == s.Rational(49,121)
    C = A*(1-l1*A); k = 1+a*x; B = 2*a*A-k*(1+l1*A)
    assert s.cancel((s.diff(q,x)-l1)*A*d-(C+B*y)) == 0
    P = (2*k-(1+l2)*A)*B**2-(k-l2*(A+k))*C*B-l2*k*C**2
    assert s.Poly(P,x).degree() <= 5
    assert s.expand(P.subs(x,-1)-2*r**3) == 0
    stationarity2 = 2*k*(1+y)-(A+k*y)-l2*(A+k*y)*(1+y)
    assert s.cancel(stationarity2.subs(y,-C/B)*B**2-P) == 0
    # C=0 implies l1*A=1; B=-2r, so no common feasible C=B=0 for r>0.
    assert s.cancel(B.subs(l1,1/A)+2*r) == 0
    edge = 2*(1+a*t)*(1+x)-(1+t+(1+a*t)*x)-l1*(1+x)*(1+t+(1+a*t)*x)
    assert s.cancel((s.diff(q,x).subs(y,t)-l1)*(1+x)*(1+t+(1+a*t)*x)-edge) == 0
    return dict(hessian_identities=True, all_15_coefficient_formulas=True,
                nonconcavity_witness='a=1/2,x=0,y=10:qxx=49/121',
                finite_candidate_elimination=True, degree_at_most_five=True,
                polynomial_minus_one_identity=True, edge_quadratic_identity=True,
                qualification='Algebraic identity checks, not a new proof of the entire theorem.')


def bounded_size_checks():
    """Deterministic repeated rational vectors; timing smoke check, not a trial."""
    reports=[]
    for k,mode in [(8,'curvature'),(16,'pricing')]:
        s=k//2
        vectors={(i,t):(F((i%4)+1,t+2),F((-1)**i*(t+1),i+2)) for i in range(k) for t in range(s)}
        gains={key:sum(x*x for x in vec) for key,vec in vectors.items()}
        pairs=[]
        for u,v in combinations(range(k),2):
            for t in range(s):
                g,h=gains[u,t],gains[v,t]
                dot=sum(a*b for a,b in zip(vectors[u,t],vectors[v,t]))
                pairs.append(dict(users=[u,v],resource=t,gain1=str(g),gain2=str(h),r=str(dot*dot/(g*h))))
        case=dict(name='analytic-size-'+str(k),K=k,S=s,M=2,pmin='1/20',pmax='1/5',budget=str(F(k,10)),pairs=pairs)
        producer.clear_caches();checker.clear_caches()
        start=time.perf_counter()
        result=producer.run(case,mode,grid_duals={'alpha':['0']*k,'lambda':'1/3'},seconds=.8)
        produce_seconds=time.perf_counter()-start
        verified=checker.verify(case,result,seconds=5.)
        reports.append(dict(K=k,mode=mode,producer_seconds=produce_seconds,verify_seconds=verified['seconds'],
                            proof_bytes=len(json.dumps(result['proof']).encode()),metrics=result['metrics'],
                            verified_metrics=verified['metrics']))
    return reports


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output', required=True); args=ap.parse_args()
    started=time.perf_counter(); results={}
    # Independent integer-log bounds checked against high precision diagnostics.
    for z in [F(1),F(2),F(3,2),F(1,1000),F(1000000),F(2)**1000,F(2)**-1000]:
        low,high=checker.log_enclosure(z)
        with localcontext() as ctx:
            ctx.prec=120; value=(Decimal(z.numerator)/Decimal(z.denominator)).ln()
            assert Decimal(low.numerator)/Decimal(low.denominator)<=value<=Decimal(high.numerator)/Decimal(high.denominator)
    results['log_diagnostics']=7
    cases=[]
    for kind in range(4):
        case, channels=fixture(kind)
        producer.clear_caches();checker.clear_caches()
        out=producer.run(case,'full',grid_duals={'alpha':['0']*4,'lambda':'1/5'},seconds=.18)
        checked=checker.verify(case,out,seconds=3)
        lo,up=F(checked['lower_nats']),F(checked['upper_nats'])
        assert lo<=up
        pmin,pmax,budget=map(F,(case['pmin'],case['pmax'],case['budget']))
        # Exhaust all fixed-grid feasible points for all six labelled assignments.
        assignments=list(producer.assignments(4));assert len(assignments)==6
        maximum=None
        for sched in assignments:
            for powers in product(sorted(set((pmin,(pmin+pmax)/2,pmax))),repeat=4):
                if sum(powers)>budget:continue
                rows=[dict(users=list(pair),resource=s,powers=[str(powers[i]) for i in pair]) for s,pair in enumerate(sched)]
                candidate=checker.verify(case,producer.universal_proof(case),rows,seconds=1)
                val=F(candidate['lower_nats']);maximum=val if maximum is None else max(maximum,val)
        assert maximum<=up
        if kind==2:assert checked['certificate_mathematical'] and up==lo==0
        cases.append(dict(kind=kind,verified=checked,producer_metrics=out['metrics'],
                          sampled_grid_max=str(maximum),sample_scope='lower-bound sanity check; full-domain proof separately verified'))
        # Direct exact 2x2 inverse identity for the linear-MMSE SINR.
        for row in case['pairs']:
            u,v=row['users'];s=row['resource'];hu,hv=channels[u][s],channels[v][s]
            p,q=pmin,pmax
            aa,bb,cc=1+q*hv[0]**2,q*hv[0]*hv[1],1+q*hv[1]**2
            direct=p*(cc*hu[0]**2-2*bb*hu[0]*hu[1]+aa*hu[1]**2)/(aa*cc-bb*bb)
            g,h,r=map(F,(row['gain1'],row['gain2'],row['r']))
            scalar=g*p*(1+(1-r)*h*q)/(1+h*q)
            assert direct==scalar
    results['analytic_cases']=cases
    case,_=fixture(); good=producer.run(case,'curvature',seconds=.12)
    # Invalid evidence must fail, never trust the claimed bounds.
    bad=copy.deepcopy(good);bad['proof']['case_sha256']='0'*64;must_reject(lambda:checker.verify(case,bad))
    badcase=copy.deepcopy(case);badcase['channels_re'][0][0][0]=2
    must_reject(lambda:checker.verify(badcase,producer.universal_proof(badcase),good['schedule']))
    bad=copy.deepcopy(good);bad['schedule'][0]['powers'][0]='999';must_reject(lambda:checker.verify(case,bad))
    bad=copy.deepcopy(good);bad['proof']['spatial']['roots'].append(copy.deepcopy(bad['proof']['spatial']['roots'][0]));must_reject(lambda:checker.verify(case,bad))
    bad=copy.deepcopy(good);bad['proof']['spatial']['roots'][0]['splits']=[['absent',0,'1/5']];must_reject(lambda:checker.verify(case,bad))
    bad=copy.deepcopy(good);bad['proof']['spatial']['roots'][0]['splits']=[['',0,'999']];must_reject(lambda:checker.verify(case,bad))
    bad=copy.deepcopy(good);del bad['proof']['spatial']['unlisted'];must_reject(lambda:checker.verify(case,bad))
    # Deleting a root WITH explicit fallback remains sound but loses tightened coverage.
    partial=copy.deepcopy(good);partial['proof']['spatial']['roots'].pop()
    partial_result=checker.verify(case,partial)
    baseline=checker.verify(case,producer.universal_proof(case),good['schedule'])
    assert partial_result['upper_nats']==baseline['upper_nats']
    dual=producer.run(case,'pricing',grid_duals={'alpha':['0']*4,'lambda':'1/5'},seconds=.08)
    assert dual['proof']['dual'] is not None
    bad=copy.deepcopy(dual);bad['proof']['dual']['rows'].pop();must_reject(lambda:checker.verify(case,bad))
    bad=copy.deepcopy(dual);bad['proof']['dual']['lambda_value']='-1';must_reject(lambda:checker.verify(case,bad))
    bad=copy.deepcopy(dual);bad['proof']['dual']['rows'][0]['upper']='0';must_reject(lambda:checker.verify(case,bad))
    # Arbitrary alpha is legal; altering it must trigger recomputation, not blind trust.
    changed=copy.deepcopy(dual);changed['proof']['dual']['alpha']=['1/7','-2/3','1','0']
    assert checker.verify(case,changed)['valid']
    must_reject(lambda:checker.verify(case,good,seconds=0))
    results['tamper_checks']=dict(rejections=11,partial_root_uses_ceiling=True,arbitrary_dual_recomputed=True)
    tests=[('0','0','0'),('1','1/2','1/3'),('1/2','0','0'),('1/4','1/3','1/2')]
    # Original finite-candidate routine is diagnostic only; not imported by verifier.
    path=Path(__file__).resolve().parents[2]/'completion-20261031/confirmation/rational_oracle.py'
    spec=importlib.util.spec_from_file_location('historical_oracle_diagnostic',path)
    oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
    comparisons=[]
    for r,l1,l2 in tests:
        rr,ll1,ll2=map(F,(r,l1,l2))
        # Generic pair API has common lambda: use g=h=1 for equal-price cases only.
        exact=oracle.maximize(rr,ll1,ll2,(F(1,10),F(1,2),F(1,10),F(1,2)))
        assert exact['lower']<=exact['upper']
        # Complete grid check of the exact candidate interval's upper.
        for x,y in product([F(1,10),F(1,4),F(1,2)],repeat=2):
            lb=checker._rate(F(1),F(1),rr,x,y)[0]-ll1*x-ll2*y
            assert lb<=exact['upper']
        if ll1==ll2:
            rect=producer.price_pair(1,1,rr,ll1,F(1,10),F(1,2),seconds=.03,max_splits=16)
            verified=checker.verify_pair(rect)
            assert F(verified['lower_nats'])<=exact['upper'] and exact['lower']<=F(verified['upper_nats'])
        comparisons.append(dict(r=r,lambda1=l1,lambda2=l2,candidates=exact['candidate_boxes']))
    for rr in (F(0),F(1,2),F(1)):
        degenerate=oracle.maximize(rr,F(0),F(1,3),(F(1,4),F(1,4),F(1,10),F(1,2)))
        assert degenerate['lower']<=degenerate['upper'] and degenerate['candidate_boxes']<=17
    for args_pair in [(0,1,0,0,F(1,4),F(1,4)),(1,1,1,0,0,0),(1,1,0,0,F(1,10),F(1,2))]:
        assert checker.verify_pair(producer.price_pair(*args_pair,seconds=.01))['valid']
    results['finite_candidate_diagnostics']=comparisons
    results['finite_candidate_degenerate_rectangles']=3
    results['symbolic']=symbolic_checks()
    results['bounded_size_smoke_checks']=bounded_size_checks()
    results['elapsed_seconds']=time.perf_counter()-started
    results['scope']='Fixed analytic fixtures only; no prospective cases, no empirical method comparison.'
    results['source_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                             [Path(__file__),Path(producer.__file__),Path(checker.__file__)]}
    destination=Path(args.output);destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'pass':True,'elapsed_seconds':results['elapsed_seconds'],'output':str(destination)}))


if __name__=='__main__':
    main()
