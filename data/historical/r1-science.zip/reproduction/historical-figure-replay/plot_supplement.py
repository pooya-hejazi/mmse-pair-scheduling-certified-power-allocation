"""Presentation-only replay of all eight original scale intervals; no solver."""
from pathlib import Path
import csv,hashlib,json,argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).parent
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=R/'generated-supplement');args=ap.parse_args();D=args.output;D.mkdir(parents=True,exist_ok=True)
src=R/'data/all-cells.csv';rows=list(csv.DictReader(src.open(encoding='utf-8',newline='')))
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial'],'font.size':10,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(6.4,3),layout='constrained');records=[]
for m,label,marker,color,style in [('grid_repair','Grid + pricing','o','#0072B2','-'),('slsqp','SLSQP','s','#E69F00','--'),('iwmmse','Adapted I-WMMSE','^','#D55E00','-.')]:
 rr=sorted([r for r in rows if r['panel']=='scale' and r['method']==m],key=lambda r:int(r['index']));assert len(rr)==8
 vals=[100*float(r['relative_gap']) for r in rr]
 ax.scatter(range(1,9),vals,label=label,marker=marker,color=color)
 records.append({'method':m,'ids':[int(r['index']) for r in rr],'percent_gaps':vals})
ax.axhline(1,color='gray',ls='--',lw=1);ax.set(yscale='log',xlabel='Prespecified scale case (1 through 8)',ylabel='Valid relative gap (%)',xticks=range(1,9));ax.grid(True,alpha=.2)
fig.legend(*ax.get_legend_handles_labels(),loc='outside upper center',ncol=3)
fig.savefig(D/'scale-gaps.pdf');fig.savefig(D/'scale-gaps.png',dpi=220);plt.close(fig)
(D/'provenance.json').write_text(json.dumps({'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'formula':'100*(U-L)/L, L>0','case_mapping':'Plot1..8 maps to saved IDs00..07','change':'Remove false complete-pricing label; fonts/legend only; all original outcome values retained','records':records},indent=2),encoding='utf-8')
print('Supplement plot regenerated from all24 saved scale rows.')
