"""Deterministic vector model drawings for CR026/T-N13; no data or simulation.

Usage: python draw_system.py --output path/to/paper/figures
All geometry is illustrative, not a measured map or a ray-tracing input.
"""
from pathlib import Path
import argparse
import hashlib
import json
import time
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, Polygon, FancyBboxPatch

BLUE = "#0072B2"
ORANGE = "#D55E00"
INK = "#263746"
GRAY = "#8996A0"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7.5,
                     "mathtext.fontset": "dejavusans", "pdf.fonttype": 42,
                     "ps.fonttype": 42, "axes.linewidth": .7})


def setup():
    fig, ax = plt.subplots(figsize=(3.35, 2.15))
    fig.subplots_adjust(left=.015, right=.985, bottom=.015, top=.985)
    ax.set(xlim=(0, 1), ylim=(0, 1))
    ax.axis("off")
    return fig, ax


def text(ax, x, y, label, size=7.5, color=INK, **kwargs):
    return ax.text(x, y, label, fontsize=size, color=color, ha="center",
                   va="center", **kwargs)


def arrow(ax, points, color, dashed=False, width=.95):
    xs, ys = zip(*points)
    ax.plot(xs, ys, color=color, lw=width, ls=(0, (3, 2)) if dashed else "-",
            zorder=3, solid_capstyle="round")
    # Draw only the final arrowhead over the polyline; avoid two phase-shifted
    # dashed shafts making a reflected path appear solid.
    tip_base = tuple(.96*b+.04*a for a,b in zip(points[-2], points[-1]))
    ax.annotate("", xy=points[-1], xytext=tip_base, zorder=3,
                arrowprops=dict(arrowstyle="-|>", color=color, lw=width,
                                mutation_scale=6, shrinkA=0, shrinkB=0,
                                linestyle=(0, (3, 2)) if dashed else "-"))


def user(ax, x, y, color, label, label_y=None):
    # A single person and handset; one icon means one single-antenna user.
    ax.add_patch(Circle((x, y+.037), .012, fc=color, ec="white", lw=.4, zorder=6))
    ax.plot([x, x], [y+.021, y-.018], color=color, lw=2.1, zorder=6)
    ax.plot([x-.017, x, x+.018], [y-.045, y-.013, y-.045], color=color, lw=1.4, zorder=6)
    ax.plot([x-.019, x, x+.025], [y-.002, y+.01, y+.004], color=color, lw=1.1, zorder=6)
    ax.add_patch(Rectangle((x+.021, y+.002), .013, .032, fc="white", ec=color, lw=.75, zorder=6))
    text(ax, x, y-.077 if label_y is None else label_y, label, 8, color, zorder=7)


def building(ax, x, y, w, h):
    # Oblique roof / side makes the setting visibly physical, not a block chart.
    d=.025
    ax.add_patch(Rectangle((x, y), w, h, fc="#E3E8EB", ec=GRAY, lw=.7, zorder=1))
    ax.add_patch(Polygon([(x,y+h),(x+d,y+h+d),(x+w+d,y+h+d),(x+w,y+h)],
                         fc="#F7F8F9", ec=GRAY, lw=.65, zorder=1))
    ax.add_patch(Polygon([(x+w,y),(x+w+d,y+d),(x+w+d,y+h+d),(x+w,y+h)],
                         fc="#CDD6DB", ec=GRAY, lw=.65, zorder=1))
    for xx in [x+w*.25, x+w*.62]:
        for yy in [y+h*.25, y+h*.65]:
            ax.add_patch(Rectangle((xx, yy), .023, .025, fc="#FAFCFD", ec=GRAY, lw=.35, zorder=2))


def box(ax, x, y, w, h, label, color=INK, size=7.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=.006,rounding_size=.016",
                              fc="white", ec=color, lw=.85, zorder=4))
    text(ax, x+w/2, y+h/2, label, size, color, zorder=5)


def save(fig, output, name):
    fig.savefig(output/(name+".pdf"), metadata={"CreationDate": None, "ModDate": None,
                "Title": name, "Subject": "Illustrative nominal single-AP model; no measured geometry"})
    fig.savefig(output/(name+".png"), dpi=300)
    plt.close(fig)


def pairing(output):
    fig, ax = setup()
    text(ax, .5, .963, "Illustrative single-AP campus", 8.2)
    # Paths and muted vegetation delineate a small outdoor campus scene.
    ax.add_patch(Polygon([(.025,.24),(.10,.77),(.84,.79),(.98,.30),(.77,.16),(.23,.15)],
                         fc="#F6F8F5", ec="#CBD6C8", lw=.65, zorder=0))
    ax.plot([.11,.39,.54,.85], [.25,.40,.57,.35], color="#E3E4DD", lw=8, zorder=0)
    for x,y in [(.05,.34),(.29,.69),(.69,.73),(.96,.48)]:
        ax.plot([x,x],[y-.025,y+.004],color="#9DA993",lw=1,zorder=0)
        ax.add_patch(Circle((x,y+.014),.019,fc="#DFE9D8",ec="#A9B99F",lw=.5,zorder=0))
    building(ax,.05,.56,.15,.14)
    building(ax,.80,.56,.14,.14)
    # All paths terminate at the same AP. Dashed paths reflect once from a facade.
    for points,c in [([(.13,.31),(.50,.70)],BLUE),
                     ([(.36,.40),(.50,.70)],BLUE),
                     ([(.69,.28),(.50,.70)],ORANGE),
                     ([(.89,.40),(.50,.70)],ORANGE)]:
        arrow(ax,points,c)
    arrow(ax,[(.13,.31),(.20,.58),(.50,.70)],BLUE,True,.85)
    arrow(ax,[(.89,.40),(.80,.60),(.50,.70)],ORANGE,True,.85)
    # One horizontal eight-element antenna array on a single mast.
    ax.plot([.50,.50],[.61,.735],color=INK,lw=1.7,zorder=5)
    ax.plot([.405,.595],[.735,.735],color=INK,lw=1,zorder=5)
    for k in range(8):
        x=.409+.026*k
        ax.plot([x,x],[.735,.782],color=INK,lw=1,zorder=5)
        ax.add_patch(Circle((x,.785),.007,fc="white",ec=INK,lw=.8,zorder=6))
    text(ax,.50,.845,"One AP: 8 antennas",7.8)
    for x,y,c,lab in [(.13,.30,BLUE,r"$u_1$"),(.36,.39,BLUE,r"$u_2$"),
                       (.69,.27,ORANGE,r"$u_3$"),(.89,.39,ORANGE,r"$u_4$")]:
        user(ax,x,y,c,lab)
    # Compact physical-path key and resource key stay outside propagation links.
    ax.plot([.06,.12],[.135,.135],color=INK,lw=.85)
    text(ax,.205,.135,"direct",7)
    ax.plot([.36,.42],[.135,.135],color=INK,lw=.85,ls=(0,(3,2)))
    text(ax,.545,.135,"reflected",7)
    text(ax,.83,.135,"illustrative paths",6.8)
    text(ax,.255,.071,r"$s=1$: pair $\{u_1,u_2\}$",7.5,BLUE)
    text(ax,.745,.071,r"$s=2$: pair $\{u_3,u_4\}$",7.5,ORANGE)
    text(ax,.5,.013,r"Shown subset; $K=2S$; orthogonal resources",7.1)
    save(fig,output,"system-pairing")


def mmse(output):
    fig, ax = setup()
    text(ax,.5,.962,"One pair on resource $s$",8.2)
    # Physical path: two simultaneous users to one eight-element AP.
    user(ax,.085,.81,BLUE,r"$u,\ p_u$",.728)
    user(ax,.085,.59,BLUE,r"$v,\ p_v$",.508)
    arrow(ax,[(.135,.817),(.465,.765)],BLUE)
    arrow(ax,[(.135,.597),(.465,.630)],BLUE)
    text(ax,.285,.852,r"$\mathbf{h}_{us}$",8,BLUE)
    text(ax,.285,.576,r"$\mathbf{h}_{vs}$",8,BLUE)
    ax.plot([.49,.49],[.57,.85],color=INK,lw=.9,zorder=5)
    for k in range(8):
        y=.583+.036*k
        ax.plot([.477,.513],[y,y],color=INK,lw=.7,zorder=5)
        ax.add_patch(Circle((.473,y),.007,fc="white",ec=INK,lw=.6,zorder=6))
    text(ax,.73,.866,"One AP, $M=8$",7.6)
    arrow(ax,[(.52,.71),(.62,.71)],INK)
    box(ax,.63,.612,.32,.19,"Linear MMSE\n(no SIC)",INK,7.7)
    text(ax,.73,.544,"channel vectors + powers",6.9)
    ax.plot([.025,.975],[.475,.475],color="#CBD3D9",lw=.65)
    text(ax,.5,.433,"Scalar rate evaluation (whitened channels)",7.4)
    box(ax,.035,.292,.44,.104,r"Gains / correlation: $g_u,g_v,r$",BLUE,7)
    box(ax,.57,.292,.39,.104,r"Candidate powers: $p_u,p_v$",INK,7)
    arrow(ax,[(.255,.284),(.365,.225)],BLUE)
    arrow(ax,[(.765,.284),(.65,.225)],INK)
    box(ax,.055,.058,.89,.163,
        r"Recomputed-MMSE SINRs $\gamma_u,\gamma_v$"+"\n"+
        r"$q_r=\ln(1+\gamma_u)+\ln(1+\gamma_v)$",INK,7.6)
    text(ax,.5,.014,"Filter vectors require channel vectors.",6.9)
    save(fig,output,"system-mmse")


def main():
    start=time.perf_counter()
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=Path(__file__).parent/"generated-system")
    args=parser.parse_args()
    output=args.output.resolve()
    output.mkdir(parents=True,exist_ok=True)
    pairing(output)
    mmse(output)
    record={"scope":"CR026 T-N13 physical-world model figures; illustrative, not measured map",
            "figure_size_inches":[3.35,2.15],"raster_dpi":300,
            "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "files":{name:hashlib.sha256((output/name).read_bytes()).hexdigest()
                     for name in ["system-pairing.pdf","system-pairing.png","system-mmse.pdf","system-mmse.png"]},
            "generation_seconds":round(time.perf_counter()-start,3),
            "assumptions":["One eight-antenna AP; no cooperative APs or mobility",
                           "Four depicted users are an illustrative subset of general K=2S",
                           "Blue/orange indicate distinct orthogonal resources in pairing figure",
                           "Both receiver-figure users use blue to indicate sharing ONE resource",
                           "Physical propagation paths illustrative; no data or experiments generated",
                           "Scalar summaries evaluate recomputed-MMSE rates; channel vectors construct filters"]}
    # All generated files stay under --output; replay never mutates source inputs.
    (output/"SYSTEM_FIGURES.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(record,indent=2))


if __name__=="__main__":
    main()
