"""Deadline-aware nominal campaign worker. No generation and no implicit input paths."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[key]='1'
import argparse,json,time,hashlib,heapq,math,traceback
from pathlib import Path
from fractions import Fraction as F
from global_core import Problem,assignments,ln_point
from rational_oracle import maximize

def ceiling(problem):
    gains={}
    for (u,v,s),(a,b,r) in problem.data.items():
        for i,g in ((u,a),(v,b)):
            if (i,s) in gains and gains[i,s]!=g: raise ValueError('inconsistent user gain')
            gains[i,s]=g
        if (a==0 or b==0) and r!=0: raise ValueError('zero gain requires r=0')
    return sum(max(ln_point(1+gains[i,s]*problem.high)[1] for s in range(problem.S)) for i in range(problem.K))

def price(g1,g2,r,lam,lo,hi):
    if min(g1,g2)<0 or lam<0: raise ValueError('pricing domain')
    if g1 and g2:
        return maximize(r,lam/g1,lam/g2,(g1*lo,g1*hi,g2*lo,g2*hi),tolerance=F(1,10**7))
    if r!=0: raise ValueError('zero gain r convention')
    lower=upper=F(0);powers=[]
    for g in (g1,g2):
        p=lo if g==0 else (hi if lam==0 else max(lo,min(hi,1/lam-1/g)))
        l,h=ln_point(1+g*p);lower+=l-lam*p;upper+=h-lam*p;powers.append(p)
    return dict(lower=lower,upper=upper,point=powers,root_digits=0,method='analytic zero-gain separable pricing')

class Snapshot:
    def __init__(self,case,dest,start,deadline,method):
        self.problem=Problem(case);self.dest=Path(dest);self.start=start;self.deadline=deadline
        self.method=method;self.last=0.;self.sequence=0;self.ceiling=ceiling(self.problem)
        s=next(assignments(self.problem.K));p=[min(self.problem.high,self.problem.budget/self.problem.K)]*self.problem.K
        self.best=self.problem.encode(s,p);self.lower=self.problem.value(s,p)[0];self.upper=self.ceiling
        self.metadata={};self.commit({'status':'VALID_UNIFORM_FALLBACK','complete_assignment_coverage':False},force=True)
    def commit(self,result,force=False):
        now=time.perf_counter()
        if now>=self.deadline: return False
        if not force and now-self.last<.5: return False
        if result.get('schedule'):
            s,p=self.problem.parse_schedule(result['schedule']);lower=self.problem.value(s,p)[0]
            if lower>self.lower: self.lower=lower;self.best=self.problem.encode(s,p)
        if result.get('upper_nats') is not None:
            self.upper=min(self.upper,F(result['upper_nats']))
        if self.upper<self.lower: raise ArithmeticError('invalid global interval')
        self.metadata.update({k:v for k,v in result.items() if k not in ('schedule','lower_nats','upper_nats')})
        self.sequence+=1
        out=dict(self.metadata,method=self.method,schedule=self.best,lower_nats=str(self.lower),upper_nats=str(self.upper),
                 gap_nats=float(self.upper-self.lower),interval_valid=True,global_upper_scope='entire assignment and continuous power family',
                 snapshot_sequence=self.sequence,worker_elapsed=time.perf_counter()-self.start,
                 scientific_deadline=self.deadline,pricing_rows=self.metadata.get('pricing_rows',[]))
        out['certificate_mathematical']=self.upper-self.lower<=F(1,100)
        out['snapshot_started_monotonic']=now
        tmp=self.dest.with_suffix('.tmp');tmp.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
        # Never replace the last eligible snapshot with a late candidate.
        if time.perf_counter()>=self.deadline: tmp.unlink(missing_ok=True);return False
        os.replace(tmp,self.dest);self.last=time.perf_counter()
        return True

def repaired_dual(case,grid,snap,deadline):
    if 'alpha' not in grid: return None
    alpha=list(map(F,grid['alpha']));lam=F(grid['lambda']);beta=[None]*case['S'];rows=[]
    for row in case['pairs']:
        if time.perf_counter()>=deadline: break
        u,v=row['users'];s=row['resource'];a,b,r=map(F,(row['gain1'],row['gain2'],row['r']))
        z=price(a,b,r,lam,F(case['pmin']),F(case['pmax']))
        val=z['upper']-alpha[u]-alpha[v];beta[s]=val if beta[s] is None else max(beta[s],val)
        rows.append(dict(users=[u,v],resource=s,lower=str(z['lower']),upper=str(z['upper']),root_digits=z['root_digits']))
        snap.commit(dict(status='PRICING_IN_PROGRESS',pricing_rows=rows,priced_pairs=len(rows),total_pairs=len(case['pairs'])))
    out=dict(pricing_rows=rows,priced_pairs=len(rows),total_pairs=len(case['pairs']),pricing_complete=len(rows)==len(case['pairs']),
             alpha=list(map(str,alpha)),lambda_value=str(lam),beta=[None if b is None else str(b) for b in beta])
    upper=None
    if len(rows)==len(case['pairs']):
        upper=sum(alpha)+sum(beta)+lam*F(case['budget']);out.update(upper_nats=str(upper),status='COMPLETE_DUAL_REPAIR')
    else: out['status']='INCOMPLETE_PRICING_FALLBACK_RETAINED'
    snap.commit(out,force=True);return upper

def spatial(snap,accelerated,deadline):
    p=snap.problem;schedules=list(assignments(p.K));heap=[];serial=nodes=covered=iterations=0
    lo=(p.low,)*p.K;hi=(p.high,)*p.K
    def insert(index,l,h,observe):
        nonlocal serial,nodes
        z=p.bound(schedules[index],l,h,accelerated)
        if z is None:return
        upper,h,center=z;nodes+=1
        if observe:
            value=p.value(schedules[index],center)[0]
            if value>snap.lower:snap.lower=value;snap.best=p.encode(schedules[index],center)
        if upper>snap.lower:
            serial+=1;heapq.heappush(heap,(-upper,serial,index,l,h))
    def report(force=False):
        # Until complete initial coverage, retain universal ceiling for all unseen schedules.
        upper=max(snap.lower,-heap[0][0] if heap else snap.lower,
                  snap.ceiling if covered<len(schedules) else snap.lower)
        snap.commit(dict(status='SPATIAL_PROGRESS',upper_nats=str(upper),assignments_total=len(schedules),
                         assignments_bound=covered,complete_assignment_coverage=covered==len(schedules),nodes=nodes,iterations=iterations),force)
    for index in range(len(schedules)):
        if time.perf_counter()>=deadline: report(True);return
        insert(index,lo,hi,False);covered+=1;report()
    report(True)
    while heap and time.perf_counter()<deadline and snap.upper-snap.lower>F(1,100):
        neg,_,index,l,h=heapq.heappop(heap)
        if -neg<=snap.lower: continue
        dim=max(range(p.K),key=lambda i:h[i]-l[i])
        if h[dim]==l[dim]:
            heapq.heappush(heap,(neg,serial+1,index,l,h));report(True);return
        mid=(l[dim]+h[dim])/2;left=list(h);left[dim]=mid;right=list(l);right[dim]=mid
        # A split is transactional: no snapshot during the incomplete partition.
        insert(index,l,tuple(left),True);insert(index,tuple(right),h,True);iterations+=1;report()
    report(True)

def run(args):
    case=json.loads(Path(args.case).read_text(encoding='utf-8'))
    snap=Snapshot(case,args.output,args.started,args.deadline,args.method)
    reserve=.4;stop=args.deadline-reserve
    try:
        # Imported only after persisted fallback; import cost remains charged.
        import local_core as base
        base.PROGRESS=lambda row:snap.commit(row)
        base.GRID_LEVELS=[F(z) for z in args.levels.split(',')]
        if args.method in ('slsqp','iwmmse'):
            result=base.solve(case,args.method,max(0,stop-time.perf_counter()));snap.commit(result,True)
        else:
            cap=20. if args.method=='grid_repair' else 8.
            budget=min(cap,max(0,stop-time.perf_counter())) if args.method!='grid' else max(0,stop-time.perf_counter())
            base.NATIVE_CAP=budget/2
            result=base.solve(case,'grid',budget);snap.commit(dict(result,grid_result=result),True)
            if args.method in ('full','grid_repair') and time.perf_counter()<stop:
                repaired_dual(case,result,snap,stop)
            if args.method in ('full','reference','curvature') and time.perf_counter()<stop:
                spatial(snap,args.method!='reference',stop)
        snap.commit({'status':'COMPLETE' if snap.upper-snap.lower<=F(1,100) else 'BUDGET_OR_METHOD_RETURNED'},True)
    except Exception as exc:
        snap.commit(dict(status='ERROR_FALLBACK_RETAINED',error=repr(exc),traceback=traceback.format_exc()),True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--method',choices=['grid','reference','curvature','full','slsqp','iwmmse','grid_repair'],required=True)
    ap.add_argument('--started',type=float,required=True);ap.add_argument('--deadline',type=float,required=True)
    ap.add_argument('--levels',default='1/20,1/10,1/5');run(ap.parse_args())
