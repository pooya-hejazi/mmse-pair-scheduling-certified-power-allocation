"""Complete schedule and continuous-power enumeration with rational upper bounds.

Reference: mixed-monotone + tangent/secant affine majorants + budget tightening.
Accelerated: add verified whole-pair concavity tangents, plus optional external UB.
Finite logarithmic precision and deadlines are explicit, not optimality claims.
"""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from functools import lru_cache
import sys,time,heapq
# Local frozen oracle copy is preferred.
from rational_oracle import ln_point


def assignments(K):
    def rec(left, schedule):
        if not left:
            yield tuple(schedule)
            return
        for u,v in combinations(left,2):
            yield from rec(tuple(k for k in left if k not in (u,v)),schedule+[(u,v)])
    yield from rec(tuple(range(K)),[])


def rate_iv(g1,g2,r,p1,p2):
    x,y=g1*p1,g2*p2;d=1+x+y+(1-r)*x*y
    dl,du=ln_point(d);xl,xu=ln_point(1+x);yl,yu=ln_point(1+y)
    return 2*dl-xu-yu,2*du-xl-yl


def affine_max(coeff,constant,lo,hi,budget):
    """Exact continuous knapsack optimum of an affine function."""
    if sum(lo)>budget:raise ValueError('infeasible box')
    value=constant+sum(a*p for a,p in zip(coeff,lo));remaining=budget-sum(lo)
    for i in sorted(range(len(coeff)),key=lambda i:coeff[i],reverse=True):
        if coeff[i]<=0 or remaining<=0:break
        amount=min(hi[i]-lo[i],remaining);value+=coeff[i]*amount;remaining-=amount
    return value


class Problem:
    def __init__(self,case):
        self.K=case['K'];self.S=case['S'];assert self.K==2*self.S
        self.low=F(case['pmin']);self.high=F(case['pmax']);self.budget=F(case['budget'])
        if not(0<=self.low<=self.high and self.K*self.low<=self.budget):raise ValueError('power domain')
        self.data={}
        for p in case['pairs']:
            u,v=p['users'];s=p['resource'];g1,g2,r=map(F,(p['gain1'],p['gain2'],p['r']))
            if not(g1>=0 and g2>=0 and 0<=r<=1):raise ValueError('channel domain')
            self.data[u,v,s]=(g1,g2,r)
        assert len(self.data)==self.K*(self.K-1)//2*self.S
        # Cache lifetime is one case, bounded by visited boxes.
        self.majorant=lru_cache(maxsize=20000)(self._majorant)

    def value(self,schedule,powers):
        lower=F(0);upper=F(0)
        for s,(u,v) in enumerate(schedule):
            a,b=rate_iv(*self.data[u,v,s],powers[u],powers[v]);lower+=a;upper+=b
        return lower,upper

    def _majorant(self,u,v,s,pl,pu,ql,qu,pc,qc,accelerated):
        g1,g2,r=self.data[u,v,s];a=1-r
        xl,xu,yl,yu,cx,cy=g1*pl,g1*pu,g2*ql,g2*qu,g1*pc,g2*qc
        d=1+cx+cy+a*cx*cy
        tx=2*(1+a*cy)/d;ty=2*(1+a*cx)/d
        if accelerated and a*a>=F(1,2):
            # Globally concave q: its exact gradient is a supporting hyperplane.
            gx=tx-1/(1+cx);gy=ty-1/(1+cy)
            val=rate_iv(g1,g2,r,pc,qc)[1]
            constant=val-gx*cx-gy*cy;ax=gx*g1;ay=gy*g2
        else:
            # Upper endpoint secants for convex negative logs.
            def secant(l,h):
                fl=-ln_point(1+l)[0]
                if l==h:return F(0),fl
                fh=-ln_point(1+h)[0];slope=(fh-fl)/(h-l)
                return slope,fl-slope*l
            sx,bx=secant(xl,xu);sy,by=secant(yl,yu)
            constant=2*ln_point(d)[1]-tx*cx-ty*cy+bx+by
            ax=(tx+sx)*g1;ay=(ty+sy)*g2
        mixed=(ln_point(1+xu*(1+a*yl)/(1+yl))[1]
               +ln_point(1+yu*(1+a*xl)/(1+xl))[1])
        return ax,ay,constant,mixed

    def bound(self,schedule,lo,hi,accelerated):
        if sum(lo)>self.budget:return None
        # Budget-preserving tightening excludes no feasible power point.
        hi=tuple(min(hi[i],self.budget-sum(lo)+lo[i]) for i in range(self.K))
        width=sum(h-l for l,h in zip(lo,hi))
        theta=min(F(1,2), (self.budget-sum(lo))/width) if width else F(0)
        center=tuple(l+theta*(h-l) for l,h in zip(lo,hi))
        coeff=[F(0)]*self.K;constant=F(0);mixed=F(0)
        for s,(u,v) in enumerate(schedule):
            ax,ay,c,m=self.majorant(u,v,s,lo[u],hi[u],lo[v],hi[v],center[u],center[v],accelerated)
            coeff[u]=ax;coeff[v]=ay;constant+=c;mixed+=m
        upper=min(mixed,affine_max(coeff,constant,lo,hi,self.budget))
        return upper,hi,center

    def parse_schedule(self,rows):
        if len(rows)!=self.S:raise ValueError('schedule resource count')
        schedule=[None]*self.S;powers=[None]*self.K
        for row in rows:
            u,v=row['users'];s=row['resource'];p,q=map(F,row['powers'])
            if u>v:u,v,p,q=v,u,q,p
            if schedule[s] is not None or powers[u] is not None or powers[v] is not None:raise ValueError('duplicate incidence')
            schedule[s]=(u,v);powers[u]=p;powers[v]=q
        if any(p is None or not self.low<=p<=self.high for p in powers) or sum(powers)>self.budget:raise ValueError('invalid powers')
        return tuple(schedule),tuple(powers)

    def encode(self,schedule,powers):
        return [{'users':[u,v],'resource':s,'powers':[str(powers[u]),str(powers[v])]} for s,(u,v) in enumerate(schedule)]


def solve(case,accelerated=False,seconds=20,tolerance=F(1,100),initial=None,external_upper=None):
    start=time.perf_counter();problem=Problem(case);K=problem.K
    schedules=list(assignments(K));expected=__import__('math').factorial(K)//2**(K//2)
    assert len(schedules)==expected
    powers=tuple([min(problem.high,problem.budget/K)]*K)
    best_schedule=schedules[0];best_powers=powers;best=problem.value(best_schedule,powers)[0]
    if initial:
        s,p=problem.parse_schedule(initial);value=problem.value(s,p)[0]
        if value>best:best,best_schedule,best_powers=value,s,p
    if external_upper is not None:
        external_upper=F(external_upper)
        if external_upper<best:raise ArithmeticError('external upper below incumbent')
    heap=[];serial=0;nodes=0
    lo=tuple([problem.low]*K);hi=tuple([problem.high]*K)
    def insert(index,low,high,observe=True):
        nonlocal serial,nodes,best,best_schedule,best_powers
        result=problem.bound(schedules[index],low,high,accelerated)
        if result is None:return
        upper,high,center=result;nodes+=1
        if observe:
            value=problem.value(schedules[index],center)[0]
            if value>best:best,best_schedule,best_powers=value,schedules[index],center
        if upper<best:return
        serial+=1;heapq.heappush(heap,(-upper,serial,index,low,high))
    # Bound every assignment before refinement; no partial-coverage certificate.
    for index in range(len(schedules)):insert(index,lo,hi,False)
    setup_seconds=time.perf_counter()-start;status='TIME_LIMIT';iterations=0
    def upper_now():
        u=max(best,-heap[0][0] if heap else best)
        return min(u,external_upper) if external_upper is not None else u
    while heap:
        upper=upper_now()
        if upper-best<=tolerance:status='CERTIFIED';break
        if time.perf_counter()-start>=seconds:break
        neg,_,index,low,high=heapq.heappop(heap)
        if -neg<=best:continue
        dim=max(range(K),key=lambda i:high[i]-low[i])
        if high[dim]==low[dim]:
            serial+=1;heapq.heappush(heap,(neg,serial,index,low,high));status='ARITHMETIC_LIMIT';break
        middle=(low[dim]+high[dim])/2
        left=list(high);left[dim]=middle;right=list(low);right[dim]=middle
        insert(index,low,tuple(left));insert(index,tuple(right),high);iterations+=1
    upper=upper_now()
    if upper-best<=tolerance:status='CERTIFIED'
    assert best<=upper
    return dict(status=status,lower_nats=str(best),upper_nats=str(upper),gap_nats=float(upper-best),
                schedule=problem.encode(best_schedule,best_powers),power_W=str(sum(best_powers)),
                assignments=len(schedules),complete_assignment_coverage=True,nodes=nodes,iterations=iterations,
                queue_remaining=len(heap),setup_seconds=setup_seconds,seconds=time.perf_counter()-start,
                curvature_pairs=sum((1-r)**2>=F(1,2) for _,_,r in problem.data.values()),
                all_pairs=len(problem.data),accelerated=accelerated,external_upper_used=external_upper is not None,
                tolerance_nats=str(tolerance),scope='development complete global interval; finite arithmetic and time caps')
