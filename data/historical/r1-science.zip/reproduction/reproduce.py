"""Copy saved evidence to a fresh output, then run unchanged analysis/checking."""
from pathlib import Path
import argparse,shutil,subprocess,sys,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--study',choices=['original','corrected'],required=True);p.add_argument('--mode',choices=['statistics','certificates'],required=True);p.add_argument('--output',required=True);p.add_argument('--seconds',type=float,default=120);a=p.parse_args()
base=Path(__file__).resolve().parent
src=base/'studies'/a.study
code=base/'code'/a.study
dest=Path(a.output).resolve()
if dest.exists():raise SystemExit('Output must be a fresh directory; stored evidence is never overwritten.')
shutil.copytree(src,dest,ignore=shutil.ignore_patterns('analysis') if a.mode=='statistics' else None)
if a.mode=='certificates' and (dest/'CERTIFICATE_REPLAY.json').exists():(dest/'CERTIFICATE_REPLAY.json').rename(dest/'CERTIFICATE_REPLAY-distributed.json')
cmd=[sys.executable,str(code/('analyze.py' if a.mode=='statistics' else 'replay_certificates.py')),str(dest)]
if a.mode=='certificates':cmd+=['--seconds',str(a.seconds)]
cp=subprocess.run(cmd,capture_output=True,text=True,timeout=(60 if a.mode=='statistics' else a.seconds+10))
(dest/'PORTABLE_RUN.log').write_text(cp.stdout+cp.stderr,encoding='utf-8')
record={'study':a.study,'mode':a.mode,'returncode':cp.returncode,'code_sha256':hashlib.sha256(Path(cmd[1]).read_bytes()).hexdigest(),'scope':'Saved-data only, no generator or optimization call; stored evidence untouched'}
if a.mode=='statistics' and cp.returncode==0:
 record['summary_identical']=(dest/'analysis/summary.json').read_bytes()==(src/'analysis/summary.json').read_bytes()
 record['csv_identical']=(dest/'analysis/all-cells.csv').read_bytes()==(src/'analysis/all-cells.csv').read_bytes()
(dest/'PORTABLE_RUN.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
raise SystemExit(cp.returncode or (1 if record.get('summary_identical') is False or record.get('csv_identical') is False else 0))
