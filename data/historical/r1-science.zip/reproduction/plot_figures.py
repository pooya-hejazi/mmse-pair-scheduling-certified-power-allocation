"""Plots of saved studies only; no optimization, resampling or new inference."""
from pathlib import Path
from fractions import Fraction as F
import csv,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import argparse
p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
W=Path(__file__).parent;C=W/'studies/corrected';P=Path(a.output).resolve();P.mkdir(parents=True,exist_ok=False)
rows=list(csv.DictReader((C/'analysis/all-cells.csv').open()));diagnostics=json.loads((W/'studies/original/diagnostic-accounting.json').read_text())
plt.rcParams.update({'font.size':8,'axes.labelsize':8,'legend.fontsize':6.5,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
colors={'grid':'#777777','curvature':'#1b9e77','full':'#d95f02','joint':'#7570b3','pricing':'#d95f02','reference':'#777777'}
labels={'grid':'Grid','curvature':'Curvature','full':'Full','joint':'Matching–WMMSE','pricing':'Grid + pricing','reference':'Reference'}
markers={'grid':'o','curvature':'s','full':'^','joint':'x','pricing':'^','reference':'o'}
manifest=[]
def select(panel,scene,method):return sorted([r for r in rows if r['panel']==panel and r['scene']==scene and r['method']==method],key=lambda r:int(r['index']))
def val(r,k):return float(r[k]) if r.get(k) not in [None,'','None'] else np.nan
def panel():return plt.subplots(1,2,figsize=(3.4,2.45),layout='constrained',sharey=True)
def finish(fig,name,question,notes):
    fig.savefig(P/(name+'.pdf'));fig.savefig(P/(name+'.png'),dpi=220);plt.close(fig)
    manifest.append({'name':name,'question':question,'notes':notes,'pdf_sha256':hashlib.sha256((P/(name+'.pdf')).read_bytes()).hexdigest()})
fig,axs=panel();methods=['grid','curvature','full','joint']
for ax,scene in zip(axs,['o1','asu']):
    bottom=np.zeros(4)
    for kind,color,hatch in [('certified','#1b9e77',''),('uncertified','#c9c9c9','//'),('error','#d95f02','xx'),('missing','white','..')]:
        counts=[]
        for m in methods:
            rr=select('main',scene,m)
            if kind=='certified':n=sum(r['operational_success']=='True' for r in rr)
            elif kind=='uncertified':n=sum(r['normal']=='True' and r['operational_success']=='False' for r in rr)
            elif kind=='error':n=sum(r['normal']!='True' and r['operational_success']=='False' for r in rr)
            else:n=sum(r['operational_success'] not in ['True','False'] for r in rr)
            counts.append(n)
        ax.bar(range(4),counts,bottom=bottom,color=color,hatch=hatch,edgecolor='black',linewidth=.4,label={"certified":"target met","uncertified":"target not met"}.get(kind,kind));bottom+=counts
    ax.set_xticks(range(4),['Grid','Curv.','Full','Joint'],rotation=35);ax.set_title(scene.upper());ax.set_ylim(0,12.5);ax.set_yticks([0,4,8,12])
axs[0].set_ylabel('Registered cases (n = 12)');fig.legend(*axs[0].get_legend_handles_labels(),loc='outside upper center',ncol=2)
finish(fig,'fig01-certification','Which registered cells reach the target and return normally?','CR024 only; all12 cases/scene retained; target0.01nat; missing/error categories retained.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
    for m in methods:
        x=np.array([val(r,'gap_nats') for r in select('main',scene,m)]);x=np.sort(x[np.isfinite(x)]);ax.step(np.maximum(x,1e-10),np.arange(1,len(x)+1)/12,where='post',label=labels[m],color=colors[m],marker=markers[m],markersize=3,lw=.9)
    ax.axvline(.01,color='black',ls=':',lw=.7);ax.set_xscale('log');ax.set_title(scene.upper());ax.set_xlabel('Global gap (nat)');ax.set_ylim(0,1.05)
axs[0].set_ylabel('Fraction of 12 registered cases');fig.legend(*axs[0].get_legend_handles_labels(),loc='outside upper center',ncol=2)
finish(fig,'fig02-gap-ecdf','How tight are the independently verified intervals?','Denominator12 even ifmissing; gaps<=1e-10 shownatfloor; dotted0.01nat target, not observedregret.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
    sets={m:{r['index']:r for r in select('main',scene,m)} for m in methods};idx=list(sets['grid'])
    for left,right,color,mark in [('grid','joint',colors['joint'],'o'),('full','grid',colors['full'],'^')]:
        y=[val(sets[left][i],'SE')-val(sets[right][i],'SE') for i in idx]
        ax.plot(np.arange(1,13),y,marker=mark,ls='none',ms=3,color=color,label=labels[left]+' − '+labels[right])
    ax.axhline(0,color='black',lw=.6);ax.set_title(scene.upper());ax.set_xlabel('Registered case ID');ax.set_xticks([1,6,12])
axs[0].set_ylabel('Paired gross SE difference (bit/s/Hz)');fig.legend(*axs[0].get_legend_handles_labels(),loc='outside upper center',ncol=1)
finish(fig,'fig03-rate-differences','Does a rate difference come from grid search or added certification?','Within-case CR024 grossoccupied-toneSE; fixedcaseIDs not temporal trends; no primary test replacement.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
    for j,m in enumerate(methods):
        rr=select('main',scene,m);ys=[val(r,'elapsed') for r in rr];xs=j+np.linspace(-.15,.15,len(rr));ax.scatter(xs,ys,s=10,color=colors[m],marker=markers[m],label=labels[m]);finite=np.asarray(ys);finite=finite[np.isfinite(finite)]
        if len(finite):ax.plot([j-.2,j+.2],[np.median(finite)]*2,color='black',lw=1)
        for x,y,r in zip(xs,ys,rr):
            if r['normal']!='True':ax.plot(x,y,'rx',ms=5)
    ax.axhline(18,color='black',ls=':',lw=.7);ax.set_title(scene.upper());ax.set_xticks(range(4),['Grid','Curv.','Full','Joint'],rotation=35)
axs[0].set_ylabel('Parent process duration (s)')
finish(fig,'fig04-charged-duration','What computational time is actually charged?','Dots allrecordeddurations; blackmedian; redx abnormalreturns; dotted18schargedcap; finitecaps not convergence times.')
fig,ax=plt.subplots(figsize=(3.4,2.45),layout='constrained')
for method in ['reference','curvature','full']:
    values=[]
    for d in diagnostics:
        rr=next((x for x in d.get('rows',[]) if x['method']==method),None);v=rr.get('verification',{}) if rr else {};values.append(float(F(v['gap_nats'])) if 'gap_nats' in v else np.nan)
    ax.plot(np.arange(1,9),np.maximum(values,1e-10),marker=markers[method],color=colors[method],label=labels[method],lw=.8,ms=4)
ax.set_yscale('log');ax.set_xlabel('Prespecified synthetic case ID');ax.set_ylabel('Verified gap (nat; floor $10^{-10}$)');ax.set_xticks(range(1,9));ax.legend(ncol=3,loc='upper center',bbox_to_anchor=(.5,1.23))
finish(fig,'fig05-curvature-mechanism','Do bound ingredients help from the same incumbent and dual?','OriginalCR023 eightK4cases reusedonce; sameinitialgrid and2scontinuations; subfloor values are enclosures not zero; c/G/seedmapping insupplement.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
    for m in methods:
        rr=select('main',scene,m);x=np.sort([val(r,'jain_fairness') for r in rr]);x=x[np.isfinite(x)];ax.step(x,np.arange(1,len(x)+1)/12,where='post',color=colors[m],marker=markers[m],ms=3,lw=.8,label=labels[m])
    ax.set_title(scene.upper());ax.set_xlabel('Jain index');ax.set_ylim(0,1.05);ax.set_xlim(0,1.02)
axs[0].set_ylabel('Fraction of 12 registered cases');fig.legend(*axs[0].get_legend_handles_labels(),loc='outside upper center',ncol=2)
finish(fig,'fig06-fairness','How do the feasible solutions distribute user rates?','Fairness isdescriptive, nottheoptimizedobjective; undefinedallzero values aremissing, neverzero; denominator12.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
    for m in ['grid','pricing','joint']:
        rr=select('scale',scene,m);ax.plot(np.arange(1,5),[val(r,'SE') for r in rr],marker=markers[m],color=colors[m],label=labels[m],ls='none',ms=4)
    ax.set_title(scene.upper());ax.set_xlabel('Case ID (K = 16)');ax.set_xticks(range(1,5))
axs[0].set_ylabel('Gross occupied-tone SE (bit/s/Hz)');fig.legend(*axs[0].get_legend_handles_labels(),loc='outside upper center',ncol=2)
finish(fig,'fig07-scale-rates','Does pricing alter the achieved rate at K16?','All4registeredcases/scene; paired markers at fixed caseIDs; grossQ/(8ln2), not Q or50MHzthroughput.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
    for j,m in enumerate(['grid','pricing','joint']):
        rr=select('scale',scene,m);ax.bar(np.arange(1,5)+(j-1)*.23,[100*val(r,'relative_gap') for r in rr],width=.22,color=colors[m],label=labels[m],hatch=['//','','xx'][j],edgecolor='black',lw=.35)
    ax.set_title(scene.upper());ax.set_xlabel('Case ID (K = 16)');ax.set_xticks(range(1,5))
axs[0].set_ylabel('Relative global gap (%)');fig.legend(*axs[0].get_legend_handles_labels(),loc='outside upper center',ncol=2)
finish(fig,'fig08-scale-certificates','How much certified uncertainty remains at K16?','100(U−L)/L, undefinedifL0; upperboundonunknownregret, not measuredregret; not a0.01natcertificate.')
(P/'FIGURE_MANIFEST.json').write_text(json.dumps({'study':'CR024; mechanismfigure explicitlyCR023','source_sha256':{str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [C/'analysis/all-cells.csv',W/'studies/original/diagnostic-accounting.json']},'figures':manifest},indent=2))
print(json.dumps({'performance_figures':len(manifest),'scope':'Saved-output plotting only; no new inference or experiments'}))
