"""CR030 bounded analytic regression; no optimizer, channels, or training.

Checks identities plus the sharp-boundary cases, not independent proof acceptance.
"""
import hashlib
import json
from pathlib import Path
import time
import sympy as s

started = time.perf_counter()
x, y, a, l1, l2 = s.symbols('x y a l1 l2', real=True)
r = 1-a
A, B = 1+x, 1+y
d = 1+x+y+a*x*y
q = 2*s.log(d)-s.log(A)-s.log(B)
hxx = A**-2-2*(1+a*y)**2/d**2
hyy = B**-2-2*(1+a*x)**2/d**2
hxy = -2*r/d**2
for derivative, formula in [(s.diff(q,x,2),hxx), (s.diff(q,y,2),hyy),
                            (s.diff(q,x,y),hxy)]:
    assert s.cancel(derivative-formula) == 0
N = (2*A*A*(1+a*y)**2-d*d)*(2*B*B*(1+a*x)**2-d*d)-4*r*r*A*A*B*B
assert s.cancel((hxx*hyy-hxy*hxy)*A*A*B*B*d**4-N) == 0
coefficients = s.Poly(s.expand(N), x,y).coeffs()
cases = []
for name, av in [('below',s.Rational(3,4)), ('boundary',s.sqrt(2)/2)]:
    signs = [s.simplify(c.subs(a,av)) for c in coefficients]
    assert all(c.is_nonnegative is True for c in signs)
    assert s.simplify(N.subs({x:0,y:0,a:av})).is_positive is True
    # Finite numerical regression, supplementing the symbolic coefficient test.
    for xv,yv in [(0,0),(0,10),(1,2),(1000,1),(1000,1000)]:
        xx = s.N(hxx.subs({x:xv,y:yv,a:av}),50)
        det = s.N((hxx*hyy-hxy*hxy).subs({x:xv,y:yv,a:av}),50)
        assert xx < 0 and det > 0
    cases.append({'position_relative_to_r_threshold':name,
                  'r':str(1-av),'all_determinant_coefficients_nonnegative':True,
                  'finite_point_hessian_checks':5})
# A strictly interior positive q_xx is an actual failure of concavity.
witness = s.factor(hxx.subs({a:s.Rational(1,2),x:s.Rational(1,100),y:10}))
assert witness > 0
cases.append({'position_relative_to_r_threshold':'above','r':'1/2',
              'interior_point':['1/100','10'],'q_xx':str(witness)})
k = 1+a*x
C = A*(1-l1*A)
b = 2*a*A-k*(1+l1*A)
pi = (2*k-(1+l2)*A)*b*b-(k-l2*(A+k))*C*b-l2*k*C*C
assert s.cancel((s.diff(q,x)-l1)*A*d-(C+b*y)) == 0
assert s.Poly(pi,x).degree() <= 5
assert s.expand(pi.subs(x,-1)-2*r**3) == 0
second = 2*k*(1+y)-(A+k*y)-l2*(A+k*y)*(1+y)
assert s.cancel(second.subs(y,-C/b)*b*b-pi) == 0
assert s.cancel(b.subs(l1,1/A)+2*r) == 0
root = Path(__file__).resolve().parents[1]
paths = [Path(__file__), *(root/'source'/f for f in
         ['model-analysis.tex','full-proofs.tex','technical-supplement.tex'])]
report = {'result':'PASS','elapsed_seconds':time.perf_counter()-started,
          'sympy_version':s.__version__,'hessian_and_determinant_identities':True,
          'threshold_cases':cases,'pricing_elimination_and_nonzero_identity':True,
          'optimizer_training_channel_generation_runs':0,
          'scope':'Author regression; not independent theorem or novelty acceptance.',
          'sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in paths}}
(root/'checks'/'theory-regression.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
