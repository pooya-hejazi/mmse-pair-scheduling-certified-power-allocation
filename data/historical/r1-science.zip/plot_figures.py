"""CR030: plot unchanged saved scalars; no optimization or statistical resampling."""
from pathlib import Path
from fractions import Fraction
import csv,json,hashlib,time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
W=Path(__file__).parent;D=W/'revision';P=Path(args.output);P.mkdir(parents=True,exist_ok=False);start=time.perf_counter()
rows=list(csv.DictReader((D/'all-cells.csv').open()));diag=json.loads((D/'diagnostic-accounting.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'legend.fontsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'lines.linewidth':1.1})
names={'grid':'Grid','curvature':'Curvature','full':'Full','joint':'Matching–WMMSE','pricing':'Grid+pricing','reference':'Reference'}
colors={'grid':'#0072B2','curvature':'#009E73','full':'#D55E00','joint':'#7B3294','pricing':'#D55E00','reference':'#0072B2'}
markers={'grid':'o','curvature':'s','full':'^','joint':'D','pricing':'s','reference':'o'}
styles={'grid':'-','curvature':'--','full':'-.','joint':':','pricing':'--','reference':'-'}
methods=['grid','curvature','full','joint'];manifest=[]
def select(panel,scene,method):return sorted([r for r in rows if r['panel']==panel and r['scene']==scene and r['method']==method],key=lambda r:int(r['index']))
def val(r,k):return float(r[k]) if r.get(k) not in [None,'','None'] else np.nan
def panel(height=2.45,share=True):return plt.subplots(1,2,figsize=(3.25,height),layout='constrained',sharey=share)
def legend(fig,ax,ncol=2):fig.legend(*ax.get_legend_handles_labels(),loc='outside upper center',ncol=ncol,frameon=False,columnspacing=.8,handlelength=1.5,handletextpad=.4)
def finish(fig,name,notes):
 for ext in ['pdf','svg','png']:fig.savefig(P/(name+'.'+ext),**({'dpi':220} if ext=='png' else {}))
 plt.close(fig);manifest.append({'name':name,'notes':notes,'files':{e:hashlib.sha256((P/(name+'.'+e)).read_bytes()).hexdigest() for e in ['pdf','svg','png']}})
# All four categories are checked; only the nonzero category needs a legend.
fig,axs=panel(2.1)
for ax,scene in zip(axs,['o1','asu']):
 for j,m in enumerate(methods):
  rr=select('main',scene,m);assert len(rr)==12 and all(r['normal']=='True' and r['operational_success']=='False' for r in rr)
  ax.barh(j,12,color='#d4d4d4',edgecolor='black',hatch='///',height=.65);ax.text(11.5,j,'12',ha='right',va='center')
 ax.set_title(scene.upper());ax.set_xlim(0,13);ax.set_xticks([0,6,12]);ax.set_xlabel('Target not met');ax.set_yticks(range(4),[names[m] for m in methods]);ax.invert_yaxis()
finish(fig,'fig01-certification','All 12 cases per arm/scenario miss target; success/error/missing counts are zero, not suppressed observations.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
 for m in methods:
  x=np.sort([val(r,'gap_nats') for r in select('main',scene,m)]);ax.step(np.maximum(x,1e-10),np.arange(1,13)/12,where='post',label=names[m],color=colors[m],marker=markers[m],ms=3.5,ls=styles[m],mfc='none')
 ax.axvline(.01,color='black',ls=':',lw=.8);ax.text(.012,.08,'0.01-nat\ntarget',rotation=90,va='bottom',fontsize=8);ax.set_xscale('log');ax.set_title(scene.upper());ax.set_xlabel('Global gap (nat)');ax.set_ylim(0,1.05);ax.set_xlim(.007,50);ax.set_xticks([.01,1,10])
axs[0].set_ylabel('Fraction of 12 cases');legend(fig,axs[0]);finish(fig,'fig02-gap-ecdf','Labelled target; redundant marker/line styles; unchanged continuous upper enclosures.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
 sets={m:{r['index']:r for r in select('main',scene,m)} for m in methods};idx=list(sets['grid'])
 ax.axhline(0,color='#777777',lw=.7,zorder=1)
 for left,right,m,mark,openface in [('grid','joint','grid','o',False),('full','grid','full','^',True)]:
  y=[val(sets[left][i],'SE')-val(sets[right][i],'SE') for i in idx]
  ax.plot(np.arange(1,13),y,marker=mark,ls='none',ms=4.5,color=colors[m],mfc='white' if openface else colors[m],mew=1,zorder=3,label=names[left]+' − '+names[right])
 ax.set_title(scene.upper());ax.set_xlabel('Case ID');ax.set_xticks([1,6,12])
axs[0].set_ylabel('SE difference (bit/s/Hz)');legend(fig,axs[0],1);finish(fig,'fig03-rate-differences','Hollow Full-minus-Grid markers expose exact zeros without vertical displacement.')
fig,axs=panel(2.25)
for ax,scene in zip(axs,['o1','asu']):
 for j,m in enumerate(methods):
  ys=j+np.linspace(-.18,.18,12);xs=[val(r,'elapsed') for r in select('main',scene,m)]
  ax.scatter(xs,ys,s=16,edgecolors=colors[m],facecolors='none',marker=markers[m]);ax.plot([np.median(xs)]*2,[j-.25,j+.25],color='black',lw=1.2)
 ax.axvline(18,color='black',ls=':',lw=.7);ax.set_xlim(0,20);ax.set_xticks([0,10,18]);ax.set_title(scene.upper());ax.set_xlabel('Wall-clock time (s)');ax.set_yticks(range(4),[names[m] for m in methods]);ax.invert_yaxis()
finish(fig,'fig04-charged-duration','Parent-process wall-clock includes initialization/search/check/persistence; black marks median;18s cap; normal returns only.')
fig,ax=plt.subplots(figsize=(3.25,2.4),layout='constrained')
for j,m in enumerate(['reference','curvature','full']):
 values=[]
 for d in diag:
  row=next(x for x in d['rows'] if x['method']==m);values.append(float(Fraction(row['verification']['gap_nats'])))
 values=np.asarray(values);x=np.arange(1,9)+(j-1)*.075
 ax.plot(x,np.maximum(values,1e-10),ls=styles[m],color=colors[m],lw=1,label=names[m])
 visible=values>=1e-10;ax.plot(x[visible],values[visible],ls='none',marker=markers[m],mfc='none',color=colors[m],ms=4)
 ax.plot(x[~visible],np.full(sum(~visible),1e-10),ls='none',marker='v',mfc='white',mec=colors[m],ms=5)
ax.set_yscale('log');ax.set_xlabel('Synthetic case ID');ax.set_ylabel('Verified gap (nat)');ax.set_xticks(range(1,9));ax.set_ylim(4e-11,None)
handles,labels=ax.get_legend_handles_labels();handles.append(Line2D([],[],marker='v',mfc='white',mec='black',ls='none'));labels.append('Below display floor')
fig.legend(handles,labels,loc='outside upper center',ncol=2,frameon=False,columnspacing=.6,handlelength=1.3)
finish(fig,'fig05-curvature-mechanism','Open downward triangles indicate upper enclosures below1e-10 display floor; slight horizontal offsets only; original8cases reused.')
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
 for m in methods:
  x=np.sort([val(r,'jain_fairness') for r in select('main',scene,m)]);ax.step(x,np.arange(1,13)/12,where='post',color=colors[m],marker=markers[m],ms=3.5,ls=styles[m],label=names[m],mfc='none')
 ax.set_title(scene.upper()+(' (zoom)' if scene=='o1' else ''));ax.set_xlabel('Jain index');ax.set_ylim(0,1.05);ax.set_xlim((.98,1.001) if scene=='o1' else (0,1.02));ax.set_xticks([.98,.99,1] if scene=='o1' else [0,.5,1])
axs[0].set_ylabel('Fraction of 12 cases');legend(fig,axs[0]);finish(fig,'fig06-fairness','O1 zoom0.98–1 exposes near-one curves; all O1 observations checked inside view; complete numerical summaries supplement.')
assert min(val(r,'jain_fairness') for r in rows if r['panel']=='main' and r['scene']=='o1')>=.98
fig,axs=panel()
for ax,scene in zip(axs,['o1','asu']):
 for j,m in enumerate(['grid','pricing','joint']):
  rr=select('scale',scene,m);ax.plot(np.arange(1,5)+(j-1)*.065,[val(r,'SE') for r in rr],marker=markers[m],color=colors[m],label=names[m],ls='none',ms=5,mfc='white' if m=='grid' else colors[m],mew=.9)
 ax.set_title(scene.upper());ax.set_xlabel('Case ID (K = 16)');ax.set_xticks(range(1,5))
axs[0].set_ylabel('Gross SE (bit/s/Hz)');legend(fig,axs[0]);finish(fig,'fig07-scale-rates','Open/filled styles plus horizontal display offsets expose Grid=Grid+pricing; no y-values changed.')
fig,axs=panel(2.55)
for ax,scene in zip(axs,['o1','asu']):
 for j,m in enumerate(['grid','pricing','joint']):
  ys=[100*val(r,'relative_gap') for r in select('scale',scene,m)];bars=ax.bar(np.arange(1,5)+(j-1)*.24,ys,width=.23,color=colors[m],label=names[m],hatch=['//','','xx'][j],edgecolor='black',lw=.4)
  ax.bar_label(bars,labels=[f'{v:.1f}' for v in ys],rotation=90,padding=2,fontsize=8)
 ax.set_title(scene.upper());ax.set_xlabel('Case ID (K = 16)');ax.set_xticks(range(1,5));ax.margins(y=.28)
axs[0].set_ylabel('Relative global gap (%)');legend(fig,axs[0]);finish(fig,'fig08-scale-certificates','Exact displayed values rounded1decimal;hatches preserve grayscale readability;relative-regret upper bounds.')
(P/'FIGURE_MANIFEST.json').write_text(json.dumps({'source_sha256':{n:hashlib.sha256((D/n).read_bytes()).hexdigest() for n in ['all-cells.csv','diagnostic-accounting.json']},'figures':manifest,'generation_seconds':time.perf_counter()-start,'scientific_runs':0},indent=2))
print(json.dumps({'figures':len(manifest),'seconds':time.perf_counter()-start}))
