"""Light correctness tests; these do not run the 220-cell study."""
from __future__ import annotations

import copy
import json
import tempfile
import unittest
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from r4_analysis import CONTRAST_DEFINITIONS, analyze_directory
from matched_study import (
    ARMS,
    CELL_SCHEMA,
    DEFAULT_ARCHIVE,
    DEFAULT_LEGACY,
    SUMMARY_SCHEMA,
    load_frozen_cases,
    load_legacy,
    make_protocol,
    object_digest,
    run_cell,
    select_cases,
    validate_cell,
    write_json,
)


class MatchedStudyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.archive, cls.records = load_frozen_cases(DEFAULT_ARCHIVE)
        cls.Problem, cls.verify_upper, cls.refiners = load_legacy(DEFAULT_LEGACY)

    def test_frozen_inventory_and_deterministic_selection(self):
        self.assertEqual(len(self.records), 44)
        self.assertEqual(len({row["seed"] for row in self.records}), 11)
        self.assertTrue(all(row["case_sha256"] and row["anchor_result_sha256"] for row in self.records))
        selected, rule = select_cases(self.records, ["1"])
        self.assertEqual(selected[0]["case_id"], sorted(row["case_id"] for row in self.records)[0])
        self.assertFalse(rule["is_full_44_case_study"])
        explicit, _ = select_cases(self.records, [self.records[2]["case_id"], self.records[0]["case_id"]])
        self.assertEqual([row["case_id"] for row in explicit], sorted([self.records[2]["case_id"], self.records[0]["case_id"]]))

    def _noop_cells(self, protocol_hash="test-protocol"):
        record = self.records[0]
        observed = []
        cells = []
        for arm in ARMS:
            def noop(problem, assignment, p0, deadline, rng, publish, arm=arm):
                observed.append((arm, assignment, tuple(p0)))
                self.assertEqual(len(assignment), problem.s)
                self.assertEqual(len(p0), problem.k)
                return p0, {"method": arm, "stop_reason": "test_noop"}
            cells.append(run_cell(
                record, arm, 1.0, protocol_hash,
                self.Problem, self.verify_upper, noop,
            ))
        return cells, observed

    def test_identical_exact_starts_and_no_assignment_changes(self):
        cells, observed = self._noop_cells()
        self.assertEqual(len({cell["initial_start_sha256"] for cell in cells}), 1)
        self.assertEqual(len({object_digest(cell["fixed_assignment"]) for cell in cells}), 1)
        self.assertEqual(len({cell["initial"]["schedule_sha256"] for cell in cells}), 1)
        self.assertEqual(len({start[1] for start in observed}), 1)
        self.assertEqual(len({start[2] for start in observed}), 1)
        for cell in cells:
            validate_cell(cell)
            self.assertEqual(cell["initial"]["schedule"], cell["final"]["schedule"])
            self.assertTrue(cell["refinement"]["assignment_unchanged"])

    def test_assignment_changing_callback_is_rejected(self):
        record = self.records[0]
        def bad_refiner(problem, assignment, p0, deadline, rng, publish):
            changed = list(assignment)
            changed[0] = tuple(reversed(changed[0]))
            # A reversal alone normalizes to the same pair; swap users across resources.
            first = list(assignment[0])
            second = list(assignment[1])
            first[0], second[0] = second[0], first[0]
            publish([first, second] + list(assignment[2:]), p0, {})
            return p0, {"stop_reason": "bad_test"}
        with self.assertRaisesRegex(RuntimeError, "assignment change"):
            run_cell(record, "T", 1.0, "test-protocol", self.Problem, self.verify_upper, bad_refiner)

    def test_cell_and_summary_output_schemas(self):
        cells, _ = self._noop_cells(protocol_hash="placeholder")
        malformed = copy.deepcopy(cells[0])
        malformed["final"]["assignment"][0][0] = 99
        with self.assertRaises(ValueError):
            validate_cell(malformed)
        with tempfile.TemporaryDirectory(prefix="schema-test-", dir=Path(__file__).resolve().parent) as tmp:
            output = Path(tmp)
            selected = self.records[:1]
            protocol = make_protocol(self.archive, self.records, selected, {
                "kind": "unit_test_smoke", "selected_case_ids": [selected[0]["case_id"]],
                "is_full_44_case_study": False,
            }, DEFAULT_LEGACY, 1.0, 0)
            protocol_hash = write_json(output / "protocol.json", protocol)
            for cell in cells:
                cell["protocol_sha256"] = protocol_hash
                write_json(output / "cells" / cell["case_id"] / f"{cell['arm']}.json", cell)
            summary = analyze_directory(output, bootstrap_replicates=0)
            self.assertEqual(summary["schema"], SUMMARY_SCHEMA)
            self.assertEqual(summary["n_cases"], 1)
            self.assertEqual(len(summary["seed_summary"]), 6)
            self.assertEqual(len(summary["paired_contrasts"]), 2 * len(CONTRAST_DEFINITIONS))
            self.assertEqual(summary["bootstrap"]["status"], "disabled")
            for row in summary["paired_contrasts"]:
                self.assertEqual(row["mean_difference_nats"], 0.0)
                self.assertEqual(row["ties"], 1)
            for name in ("summary.json", "seed_summary.csv", "overall_summary.csv", "contrasts.csv", "bootstrap.csv"):
                self.assertTrue((output / name).is_file(), name)
            self.assertEqual(json.loads((output / "summary.json").read_text())["schema"], SUMMARY_SCHEMA)
            self.assertEqual(cells[0]["schema"], CELL_SCHEMA)


if __name__ == "__main__":
    unittest.main(verbosity=2)
