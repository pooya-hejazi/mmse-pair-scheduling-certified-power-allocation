"""Deterministic paired analysis for the matched fixed-assignment kernel study."""
from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path

import numpy as np

from matched_study import (
    ARMS,
    BOOTSTRAP_SEED,
    MODERN_ARMS,
    SCOPE,
    SUMMARY_SCHEMA,
    read_json,
    validate_cell,
    write_json,
)

CONTRAST_DEFINITIONS = tuple(
    [(arm, comparator) for arm in ("T", "W", "S") for comparator in ("FU_SCA", "THU_IDE", "MODERN_ENVELOPE")]
    + [("FU_SCA", "THU_IDE")]
)
DISPLAY_ARMS = ARMS + ("MODERN_ENVELOPE",)


def lower(cell: dict, label: str = "final") -> Fraction:
    return Fraction(cell[label]["independent_verification"]["lower_nats"])


def modern_cell(case_cells: dict[str, dict]) -> dict:
    modern = [case_cells[arm] for arm in MODERN_ARMS]
    winner = max(modern, key=lambda cell: (lower(cell), cell["arm"]))
    initial = case_cells[MODERN_ARMS[0]]["initial"]
    return {
        "arm": "MODERN_ENVELOPE",
        "case_id": winner["case_id"],
        "seed": winner["seed"],
        "initial": initial,
        "final": winner["final"],
        "envelope_winner": winner["arm"],
        # Constructing the envelope requires both modern cells, not just the winner.
        "refinement": {
            "elapsed_seconds": sum(float(cell["refinement"]["elapsed_seconds"]) for cell in modern),
            "wall_deadline_exceeded": any(cell["refinement"]["wall_deadline_exceeded"] for cell in modern),
        },
    }


def summarize_arm(case_cells: list[dict], arm: str, seed) -> dict:
    rows = [modern_cell(cells) if arm == "MODERN_ENVELOPE" else cells[arm] for cells in case_cells]
    initial_values = [float(lower(row, "initial")) for row in rows]
    final_values = [float(lower(row)) for row in rows]
    gains = [float(lower(row) - lower(row, "initial")) for row in rows]
    elapsed = [float(row.get("refinement", {}).get("elapsed_seconds", 0.0)) for row in rows]
    deadline_exceeded = [bool(row.get("refinement", {}).get("wall_deadline_exceeded", False)) for row in rows]
    result = {
        "seed": seed,
        "arm": arm,
        "n_cases": len(rows),
        "case_ids": [row["case_id"] for row in rows],
        "initial_lower_mean_nats": float(np.mean(initial_values)),
        "final_lower_mean_nats": float(np.mean(final_values)),
        "final_lower_median_nats": float(np.median(final_values)),
        "final_lower_min_nats": min(final_values),
        "final_lower_max_nats": max(final_values),
        "verified_lower_gain_mean_nats": float(np.mean(gains)),
        "refinement_elapsed_mean_seconds": float(np.mean(elapsed)),
        "wall_deadline_exceeded_cases": sum(deadline_exceeded),
    }
    if arm == "MODERN_ENVELOPE":
        result["envelope_winner_counts"] = dict(sorted(Counter(row["envelope_winner"] for row in rows).items()))
    return result


def contrast_row(case_cells: list[dict], arm: str, comparator: str, seed) -> dict:
    differences = []
    case_ids = []
    for cells in sorted(case_cells, key=lambda item: next(iter(item.values()))["case_id"]):
        left = modern_cell(cells) if arm == "MODERN_ENVELOPE" else cells[arm]
        right = modern_cell(cells) if comparator == "MODERN_ENVELOPE" else cells[comparator]
        differences.append(lower(left) - lower(right))
        case_ids.append(left["case_id"])
    values = np.asarray([float(value) for value in differences], dtype=float)
    return {
        "seed": seed,
        "arm": arm,
        "comparator": comparator,
        "contrast": f"{arm}_minus_{comparator}",
        "n_cases": len(values),
        "case_ids": case_ids,
        "mean_difference_nats": float(np.mean(values)),
        "median_difference_nats": float(np.median(values)),
        "min_difference_nats": float(np.min(values)),
        "max_difference_nats": float(np.max(values)),
        "wins": int(sum(value > 0 for value in differences)),
        "ties": int(sum(value == 0 for value in differences)),
        "losses": int(sum(value < 0 for value in differences)),
        "exact_differences_nats": [str(value) for value in differences],
    }


def leave_one_seed_out(grouped: dict, seeds: list[int]) -> list[dict]:
    rows = []
    for omitted in seeds:
        retained = [cell for seed, cells in grouped.items() if seed != omitted for cell in cells]
        for arm, comparator in CONTRAST_DEFINITIONS:
            contrast = contrast_row(retained, arm, comparator, "ALL_EXCEPT_OMITTED")
            rows.append({
                "omitted_seed": omitted,
                "arm": arm,
                "comparator": comparator,
                "n_cases": contrast["n_cases"],
                "mean_difference_nats": contrast["mean_difference_nats"],
                "median_difference_nats": contrast["median_difference_nats"],
            })
    return rows


def bootstrap_contrasts(grouped: dict, replicates: int) -> dict:
    seeds = sorted(grouped)
    base = {
        "seed": BOOTSTRAP_SEED,
        "requested_replicates": replicates,
        "resampling_unit": "whole seed group; all four cases retained whenever a group is drawn",
        "interval_percentiles": [2.5, 97.5],
    }
    if replicates == 0:
        return dict(base, status="disabled", rows=[])
    if len(seeds) < 2 or any(len(grouped[seed]) != 4 for seed in seeds):
        return dict(
            base,
            status="skipped_requires_at_least_two_complete_whole_seed_groups",
            completed_replicates=0,
            rows=[],
        )
    rng = np.random.default_rng(np.random.SeedSequence([BOOTSTRAP_SEED]))
    draws = rng.integers(0, len(seeds), size=(replicates, len(seeds)))
    rows = []
    for arm, comparator in CONTRAST_DEFINITIONS:
        by_seed = []
        for seed in seeds:
            contrast = contrast_row(grouped[seed], arm, comparator, seed)
            by_seed.append([float(Fraction(value)) for value in contrast["exact_differences_nats"]])
        values = np.asarray(by_seed, dtype=float)
        sampled = values[draws, :].reshape(replicates, -1)
        means = np.mean(sampled, axis=1)
        medians = np.median(sampled, axis=1)
        rows.append({
            "arm": arm,
            "comparator": comparator,
            "contrast": f"{arm}_minus_{comparator}",
            "completed_replicates": replicates,
            "seed_groups": len(seeds),
            "cases_per_replicate": sampled.shape[1],
            "mean_point_nats": float(np.mean(values)),
            "mean_percentile_ci_nats": [float(x) for x in np.percentile(means, [2.5, 97.5])],
            "median_point_nats": float(np.median(values)),
            "median_percentile_ci_nats": [float(x) for x in np.percentile(medians, [2.5, 97.5])],
            "bootstrap_probability_mean_gt_zero": float(np.mean(means > 0)),
            "bootstrap_probability_mean_lt_zero": float(np.mean(means < 0)),
        })
    return dict(base, status="completed", completed_replicates=replicates, rows=rows)


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def analyze_directory(output: Path, bootstrap_replicates: int | None = None) -> dict:
    output = Path(output)
    protocol = read_json(output / "protocol.json")
    cells = []
    for path in sorted((output / "cells").glob("*/*.json"), key=lambda p: p.as_posix()):
        cell = read_json(path)
        validate_cell(cell)
        cells.append(cell)
    selected_ids = protocol["selection"]["selected_case_ids"]
    expected = {(case_id, arm) for case_id in selected_ids for arm in ARMS}
    observed = {(cell["case_id"], cell["arm"]) for cell in cells}
    if len(cells) != len(expected) or observed != expected:
        raise ValueError("analysis requires exactly one valid copy of every planned cell; no silent pairwise deletion")
    by_case = defaultdict(dict)
    for cell in cells:
        by_case[cell["case_id"]][cell["arm"]] = cell
    for case_id, case_cells in by_case.items():
        if set(case_cells) != set(ARMS):
            raise ValueError(f"incomplete case: {case_id}")
        if len({cell["initial_start_sha256"] for cell in case_cells.values()}) != 1:
            raise ValueError(f"unmatched starts: {case_id}")
        initial_hashes = {cell["initial"]["schedule_sha256"] for cell in case_cells.values()}
        if len(initial_hashes) != 1:
            raise ValueError(f"unmatched initial schedules: {case_id}")
    grouped = {
        seed: [by_case[case_id] for case_id in sorted(by_case) if by_case[case_id][ARMS[0]]["seed"] == seed]
        for seed in sorted({cells[ARMS[0]]["seed"] for cells in by_case.values()})
    }
    seeds = sorted(grouped)
    seed_summary = [
        summarize_arm(grouped[seed], arm, seed)
        for seed in seeds for arm in DISPLAY_ARMS
    ]
    all_cases = [by_case[case_id] for case_id in sorted(by_case)]
    overall_summary = [summarize_arm(all_cases, arm, "ALL") for arm in DISPLAY_ARMS]
    contrasts = [
        contrast_row(grouped[seed], arm, comparator, seed)
        for seed in seeds for arm, comparator in CONTRAST_DEFINITIONS
    ]
    contrasts.extend(contrast_row(all_cases, arm, comparator, "ALL") for arm, comparator in CONTRAST_DEFINITIONS)
    if bootstrap_replicates is None:
        bootstrap_replicates = int(protocol["analysis_plan"]["cluster_bootstrap"]["replicates"])
    bootstrap = bootstrap_contrasts(grouped, int(bootstrap_replicates))
    loog = leave_one_seed_out(grouped, seeds) if len(seeds) >= 2 else []
    summary = {
        "schema": SUMMARY_SCHEMA,
        "scope": SCOPE,
        "protocol_sha256": cells[0]["protocol_sha256"],
        "selected_case_ids": selected_ids,
        "n_cases": len(by_case),
        "n_seed_groups": len(seeds),
        "complete_44_case_study": len(by_case) == 44,
        "rate_estimand": "independently verified final lower_nats; paired exact-rational differences converted to float only for descriptive statistics",
        "modern_envelope": "case-wise maximum final lower_nats of FU_SCA and THU_IDE; this is an algorithmic envelope, not a global upper bound",
        "modern_envelope_timing": "sum of FU_SCA and THU_IDE refinement times because both are required to construct the envelope",
        "seed_summary": seed_summary,
        "overall_summary": overall_summary,
        "paired_contrasts": contrasts,
        "leave_one_seed_out": loog,
        "bootstrap": bootstrap,
    }
    write_json(output / "summary.json", summary)
    write_csv(output / "seed_summary.csv", seed_summary, [
        "seed", "arm", "n_cases", "initial_lower_mean_nats", "final_lower_mean_nats",
        "final_lower_median_nats", "final_lower_min_nats", "final_lower_max_nats",
        "verified_lower_gain_mean_nats", "refinement_elapsed_mean_seconds", "wall_deadline_exceeded_cases",
    ])
    write_csv(output / "overall_summary.csv", overall_summary, [
        "seed", "arm", "n_cases", "initial_lower_mean_nats", "final_lower_mean_nats",
        "final_lower_median_nats", "final_lower_min_nats", "final_lower_max_nats",
        "verified_lower_gain_mean_nats", "refinement_elapsed_mean_seconds", "wall_deadline_exceeded_cases",
    ])
    write_csv(output / "contrasts.csv", contrasts, [
        "seed", "arm", "comparator", "contrast", "n_cases", "mean_difference_nats",
        "median_difference_nats", "min_difference_nats", "max_difference_nats", "wins", "ties", "losses",
    ])
    write_csv(output / "bootstrap.csv", bootstrap["rows"], [
        "arm", "comparator", "contrast", "completed_replicates", "seed_groups", "cases_per_replicate",
        "mean_point_nats", "mean_percentile_ci_nats", "median_point_nats", "median_percentile_ci_nats",
        "bootstrap_probability_mean_gt_zero", "bootstrap_probability_mean_lt_zero",
    ])
    return summary
