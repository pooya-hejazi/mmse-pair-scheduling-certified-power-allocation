"""Matched fixed-assignment power-kernel study for the R4 revision.

Only power refiners are called.  In particular, this module never imports or
calls the legacy assignment-search driver.  Frozen cases and COMMON_GRID
anchors are read from the R3 ZIP without extracting or modifying it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import sys
import time
import zipfile
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_key] = "1"

ARMS = ("T", "W", "S", "FU_SCA", "THU_IDE")
MODERN_ARMS = ("FU_SCA", "THU_IDE")
BOOTSTRAP_SEED = 2026110399
BOOTSTRAP_REPLICATES = 20000
CELL_SCHEMA = "R4_MATCHED_FIXED_ASSIGNMENT_CELL_V1"
PROTOCOL_SCHEMA = "R4_MATCHED_FIXED_ASSIGNMENT_PROTOCOL_V1"
SUMMARY_SCHEMA = "R4_MATCHED_FIXED_ASSIGNMENT_SUMMARY_V1"
SCOPE = (
    "Fixed-assignment power-kernel comparison from each frozen COMMON_GRID "
    "anchor; no assignment search, exchanges, or matching; no standalone, "
    "complete-system, or global-optimality claim."
)
HERE = Path(__file__).resolve().parent
DEFAULT_ARCHIVE = HERE.parents[2] / "output/TCOM-Submission-2026-11-04-R3/Supplementary_Materials.zip"
DEFAULT_LEGACY = HERE.parent / "legacy-method/CR033/method"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_bytes(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def object_digest(obj) -> str:
    return sha256_bytes(canonical_bytes(obj))


def jsonable(value):
    """Convert legacy NumPy diagnostics without silently accepting NaN/Inf."""
    import numpy as np

    if isinstance(value, np.generic):
        return jsonable(value.item())
    if isinstance(value, np.ndarray):
        return jsonable(value.tolist())
    if isinstance(value, Fraction):
        return str(value)
    if isinstance(value, dict):
        return {str(key): jsonable(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(val) for val in value]
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("nonfinite diagnostic/result value")
    return value


def write_json(path: Path, obj) -> str:
    """Exclusive publication: existing results are never overwritten."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(jsonable(obj), sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    return sha256_bytes(data)


def read_json(path: Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _display_path(path: Path) -> str:
    try:
        return path.resolve().relative_to(HERE.parents[2]).as_posix()
    except ValueError:
        return str(path.resolve())


def source_hashes(root: Path) -> list[dict]:
    return [
        {
            "path": _display_path(path),
            "absolute_path": str(path.resolve()),
            "sha256": sha256_file(path),
        }
        for path in sorted(root.rglob("*.py"), key=lambda p: p.as_posix())
        if "__pycache__" not in path.parts
    ]


def load_frozen_cases(archive_path: Path) -> tuple[dict, list[dict]]:
    """Read and authenticate all 44 holdout cases and all 44 frozen anchors."""
    archive_path = Path(archive_path).resolve()
    archive_hash = sha256_file(archive_path)
    with zipfile.ZipFile(archive_path, "r") as archive:
        manifest_name = "CR033/study/holdout-INPUTS.json"
        manifest_bytes = archive.read(manifest_name)
        manifest = json.loads(manifest_bytes)
        rows = manifest["inputs"]
        if len(rows) != 44:
            raise ValueError(f"expected 44 holdout cases, found {len(rows)}")
        records = []
        for row in sorted(rows, key=lambda item: item["id"]):
            case_id = row["id"]
            case_name = f"CR033/study/inputs/{case_id}.json"
            anchor_name = f"CR033/study/common/{case_id}/result.json"
            case_bytes = archive.read(case_name)
            anchor_bytes = archive.read(anchor_name)
            case_hash = sha256_bytes(case_bytes)
            if case_hash != row["sha256"]:
                raise ValueError(f"case hash mismatch: {case_id}")
            case = json.loads(case_bytes)
            anchor_result = json.loads(anchor_bytes)
            if anchor_result.get("method") != "COMMON_GRID" or not anchor_result.get("valid"):
                raise ValueError(f"invalid/non-COMMON_GRID anchor: {case_id}")
            if anchor_result.get("case_id") != case_id or anchor_result.get("case_sha256") != case_hash:
                raise ValueError(f"anchor/case binding mismatch: {case_id}")
            schedule = anchor_result["schedule"]
            records.append(
                {
                    "case_id": case_id,
                    "seed": int(row["seed"]),
                    "solver_seed": int(row.get("solver_seed", row["seed"])),
                    "ordinal": int(row["ordinal"]),
                    "regime": row["regime"],
                    "case": case,
                    "anchor_schedule": schedule,
                    "case_zip_path": case_name,
                    "case_sha256": case_hash,
                    "case_canonical_sha256": object_digest(case),
                    "anchor_zip_path": anchor_name,
                    "anchor_result_sha256": sha256_bytes(anchor_bytes),
                    "anchor_schedule_sha256": object_digest(schedule),
                }
            )
    seeds = {record["seed"] for record in records}
    if len(records) != 44 or len(seeds) != 11 or any(sum(r["seed"] == seed for r in records) != 4 for seed in seeds):
        raise ValueError("holdout design is not 11 whole seeds with four cases each")
    archive_record = {
        "path": _display_path(archive_path),
        "absolute_path": str(archive_path),
        "sha256": archive_hash,
        "bytes": archive_path.stat().st_size,
        "holdout_manifest_zip_path": manifest_name,
        "holdout_manifest_sha256": sha256_bytes(manifest_bytes),
    }
    return archive_record, records


def select_cases(records: list[dict], selections: list[str] | None) -> tuple[list[dict], dict]:
    """Default to all cases; allow explicit IDs or a deterministic first-N smoke."""
    if not selections:
        return list(records), {"kind": "all_holdout", "requested": None, "selected_case_ids": [r["case_id"] for r in records]}
    tokens = []
    for selection in selections:
        tokens.extend(token.strip() for token in selection.split(",") if token.strip())
    if len(tokens) == 1 and tokens[0].isdigit():
        count = int(tokens[0])
        if not 1 <= count <= len(records):
            raise ValueError(f"--cases count must be in [1,{len(records)}]")
        selected = records[:count]
        rule = "first_n_sorted_case_ids_smoke"
    else:
        by_id = {record["case_id"]: record for record in records}
        missing = [token for token in tokens if token not in by_id]
        if missing:
            raise ValueError("unknown holdout case IDs: " + ", ".join(missing))
        if len(set(tokens)) != len(tokens):
            raise ValueError("duplicate case selection")
        selected = [by_id[case_id] for case_id in sorted(tokens)]
        rule = "explicit_case_ids_smoke"
    return selected, {
        "kind": rule,
        "requested": tokens,
        "selected_case_ids": [record["case_id"] for record in selected],
        "is_full_44_case_study": len(selected) == 44,
    }


def make_protocol(
    archive: dict,
    records: list[dict],
    selected: list[dict],
    selection: dict,
    legacy_root: Path,
    seconds_per_cell: float,
    bootstrap_replicates: int,
) -> dict:
    frozen_inputs = []
    for record in records:
        frozen_inputs.append({key: value for key, value in record.items() if key not in ("case", "anchor_schedule")})
    legacy_sources = source_hashes(legacy_root)
    r4_sources = source_hashes(HERE)
    verifier = legacy_root / "core/vendor/verify_upper.py"
    return {
        "schema": PROTOCOL_SCHEMA,
        "created_utc": utc_now(),
        "protocol_status": "SAVED_BEFORE_ANY_RESULTS",
        "scope": SCOPE,
        "design": {
            "cases_available": 44,
            "whole_seed_groups_available": 11,
            "cases_per_whole_seed": 4,
            "cases_executed": len(selected),
            "cells_planned": 5 * len(selected),
            "arms": list(ARMS),
            "case_order": [record["case_id"] for record in selected],
            "arm_order_within_case": list(ARMS),
            "fixed_assignment_source": "frozen COMMON_GRID result.schedule decoded once per arm to identical exact rationals",
            "initial_power_source": "the same frozen COMMON_GRID result.schedule powers for every arm",
            "assignment_search": False,
            "assignment_exchanges": False,
            "matching_updates": False,
            "multistart_outer_search": False,
            "refiners": {
                "T": "core/transfer.py::refine_power",
                "W": "core/wmmse.py::refine_power (not refine_matching)",
                "S": "core/slsqp_power.py::refine_power",
                "FU_SCA": "modern/fu_sca.py::refine_power",
                "THU_IDE": "modern/thu_ide.py::refine_power",
            },
            "seconds_per_cell_refinement_wall_deadline": seconds_per_cell,
            "deadline_mechanism": "legacy cooperative monotonic deadline; initial/final independent verification lies outside the refinement timer; overruns are retained and reported",
            "thu_rng_seed_sequence": "[frozen holdout solver_seed, 987654]",
            "common_power_starts": "empty; no outer starts are supplied",
            "modern_envelope": "per-case maximum independently verified final lower_nats of FU_SCA and THU_IDE",
            "statistic": "differences of independently verified final lower_nats, paired within case",
        },
        "selection": selection,
        "frozen_archive": archive,
        "frozen_inputs": frozen_inputs,
        "method_source_hashes": legacy_sources,
        "r4_source_hashes_at_protocol": r4_sources,
        "independent_verifier": {
            "path": _display_path(verifier),
            "sha256": sha256_file(verifier),
            "call": "verify_upper.verify with universal MMSE_PARTITION_PROOF_V1 on initial and final exact rational schedules",
            "additional_check": "Problem.checked_candidate and matrix/scalar rate consistency",
        },
        "analysis_plan": {
            "seed_summary": "all selected whole seeds; four regimes remain together",
            "paired_contrasts": "T, W, S each minus FU_SCA, THU_IDE, and MODERN_ENVELOPE; FU_SCA minus THU_IDE",
            "cluster_bootstrap": {
                "replicates": bootstrap_replicates,
                "seed": BOOTSTRAP_SEED,
                "unit": "whole seed group with replacement; all four cases retained",
                "interval": "2.5th and 97.5th percentiles for mean and median paired differences",
                "minimum_seed_groups": 2,
            },
            "leave_one_seed_out": "overall paired mean and median recomputed after removing each whole seed group",
            "missing_or_invalid_cells": "not pairwise deleted silently; analysis requires every planned arm in every selected case",
        },
        "runtime_at_protocol": {
            "python": sys.version,
            "platform": platform.platform(),
            "numpy": __import__("numpy").__version__,
            "scipy": __import__("scipy").__version__,
        },
    }


def load_legacy(legacy_root: Path):
    """Import frozen modules by path; never edit or extract their sources."""
    legacy_root = Path(legacy_root).resolve()
    paths = [legacy_root, legacy_root / "core", legacy_root / "modern", legacy_root / "core/vendor"]
    for path in reversed(paths):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    from problem import Problem
    import slsqp_power
    import transfer
    import verify_upper
    import wmmse
    from modern import fu_sca, thu_ide

    refiners = {
        "T": transfer.refine_power,
        "W": wmmse.refine_power,
        "S": slsqp_power.refine_power,
        "FU_SCA": fu_sca.refine_power,
        "THU_IDE": thu_ide.refine_power,
    }
    return Problem, verify_upper, refiners


def independent_check(problem, verify_upper, case: dict, schedule: list[dict], assignment, powers):
    """Check exact encoded powers/rates independently of the producer refiner."""
    checked = problem.checked_candidate(assignment, powers)
    scalar_matrix = problem.matrix_scalar_check(checked)
    proof = {
        "schema": "MMSE_PARTITION_PROOF_V1",
        "case_sha256": object_digest(case),
        "universal": True,
        "dual": None,
        "spatial": None,
    }
    verify_upper.clear_caches()
    verification = verify_upper.verify(case, {"proof": proof, "schedule": checked["schedule"]}, seconds=60.0)
    if not verification.get("valid"):
        raise ValueError("independent verifier rejected candidate")
    return {
        "schedule": checked["schedule"],
        "schedule_sha256": object_digest(checked["schedule"]),
        "assignment": [list(pair) for pair in checked["assignment"]],
        "powers": [str(power) for power in checked["powers"]],
        "producer_checked_candidate": {
            "lower_nats": str(checked["lo"]),
            "upper_nats": str(checked["hi"]),
            "numeric_nats": checked["value"],
            "matrix_numeric_nats": scalar_matrix["matrix"],
            "scalar_matrix_abs_discrepancy_nats": scalar_matrix["discrepancy"],
        },
        "independent_verification": verification,
        "feasible_and_rate_checked": True,
    }


def validate_cell(cell: dict) -> None:
    required = {
        "schema", "scope", "case_id", "seed", "arm", "protocol_sha256",
        "initial", "final", "refinement", "fixed_assignment", "initial_start_sha256",
    }
    if set(cell) < required or not required.issubset(cell):
        raise ValueError("cell schema missing required fields")
    if cell["schema"] != CELL_SCHEMA or cell["arm"] not in ARMS:
        raise ValueError("cell schema/arm mismatch")
    if cell["fixed_assignment"] != cell["initial"]["assignment"] or cell["fixed_assignment"] != cell["final"]["assignment"]:
        raise ValueError("assignment changed")
    for label in ("initial", "final"):
        checked = cell[label]
        scheduled_assignment = [row["users"] for row in sorted(checked["schedule"], key=lambda row: row["resource"])]
        if scheduled_assignment != cell["fixed_assignment"]:
            raise ValueError(f"{label} schedule assignment mismatch")
        if not checked["feasible_and_rate_checked"] or not checked["independent_verification"]["valid"]:
            raise ValueError(f"{label} candidate lacks independent validation")
        Fraction(checked["independent_verification"]["lower_nats"])
        Fraction(checked["independent_verification"]["upper_nats"])
    if not cell["refinement"]["assignment_unchanged"]:
        raise ValueError("refinement assignment guard failed")


def run_cell(
    record: dict,
    arm: str,
    seconds_per_cell: float,
    protocol_hash: str,
    Problem,
    verify_upper,
    refiner,
) -> dict:
    if arm not in ARMS:
        raise ValueError(arm)
    import numpy as np

    case = record["case"]
    problem = Problem(case)
    problem.common_power_starts = []
    # Decode the same frozen schedule into exact rational powers for every arm.
    anchored = problem.anchor(record["anchor_schedule"])
    fixed_assignment = anchored["assignment"]
    initial_powers = anchored["powers"]
    initial = independent_check(problem, verify_upper, case, record["anchor_schedule"], fixed_assignment, initial_powers)
    start_payload = {
        "assignment": [list(pair) for pair in fixed_assignment],
        "powers": [str(power) for power in initial_powers],
    }
    start_hash = object_digest(start_payload)
    callback_count = 0
    last_callback_diagnostics = None

    def fixed_publish(assignment, powers, diagnostics):
        nonlocal callback_count, last_callback_diagnostics
        normalized = tuple(tuple(sorted(map(int, pair))) for pair in assignment)
        if normalized != fixed_assignment:
            raise RuntimeError("fixed-assignment guard: callback attempted an assignment change")
        candidate = problem.checked_candidate(fixed_assignment, powers)
        if candidate["assignment"] != fixed_assignment:
            raise RuntimeError("fixed-assignment guard: checked callback assignment changed")
        callback_count += 1
        last_callback_diagnostics = jsonable(diagnostics)
        return True

    rng = np.random.default_rng(np.random.SeedSequence([record["solver_seed"], 987654]))
    started = time.monotonic()
    started_utc = utc_now()
    deadline = started + seconds_per_cell
    returned_powers, diagnostics = refiner(
        problem, fixed_assignment, initial_powers, deadline, rng, fixed_publish
    )
    ended = time.monotonic()
    raw_exact = tuple(
        value if isinstance(value, Fraction) else Fraction(float(value))
        for value in returned_powers
    )
    if len(raw_exact) != problem.k or not all(math.isfinite(float(value)) for value in returned_powers):
        raise ValueError("refiner returned malformed powers")
    raw_feasible = all(problem.low <= power <= problem.high for power in raw_exact) and sum(raw_exact, Fraction(0)) <= problem.budget
    proposed_final = independent_check(problem, verify_upper, case, record["anchor_schedule"], fixed_assignment, raw_exact)
    if proposed_final["assignment"] != initial["assignment"]:
        raise RuntimeError("fixed-assignment guard: final assignment changed")
    initial_lower = Fraction(initial["independent_verification"]["lower_nats"])
    proposed_lower = Fraction(proposed_final["independent_verification"]["lower_nats"])
    # Independent outward enclosures can move by a few ulps even when the
    # producer's own interval accepted a candidate. Never publish a checked
    # decrease: retain the common start and preserve the rejected return record.
    independent_fallback = proposed_lower < initial_lower
    final = initial if independent_fallback else proposed_final
    final_lower = initial_lower if independent_fallback else proposed_lower
    elapsed = ended - started
    diagnostics = jsonable(diagnostics)
    cell = {
        "schema": CELL_SCHEMA,
        "scope": SCOPE,
        "case_id": record["case_id"],
        "seed": record["seed"],
        "solver_seed": record["solver_seed"],
        "regime": record["regime"],
        "ordinal": record["ordinal"],
        "arm": arm,
        "protocol_sha256": protocol_hash,
        "case_zip_path": record["case_zip_path"],
        "case_sha256": record["case_sha256"],
        "case_canonical_sha256": record["case_canonical_sha256"],
        "anchor_zip_path": record["anchor_zip_path"],
        "anchor_result_sha256": record["anchor_result_sha256"],
        "anchor_schedule_sha256": record["anchor_schedule_sha256"],
        "fixed_assignment": [list(pair) for pair in fixed_assignment],
        "initial_start_sha256": start_hash,
        "initial": initial,
        "final": final,
        "proposed_final": proposed_final,
        "independent_retention": {
            "rule": "retain the common start if the independently checked proposed lower enclosure is below the initial lower enclosure",
            "fallback_to_initial": independent_fallback,
            "proposed_lower_nats": str(proposed_lower),
            "retained_lower_nats": str(final_lower),
        },
        "verified_lower_gain_nats": str(final_lower - initial_lower),
        "refinement": {
            "refiner": {
                "T": "transfer.refine_power",
                "W": "wmmse.refine_power",
                "S": "slsqp_power.refine_power",
                "FU_SCA": "fu_sca.refine_power",
                "THU_IDE": "thu_ide.refine_power",
            }[arm],
            "seconds_per_cell_wall_deadline": seconds_per_cell,
            "started_monotonic": started,
            "deadline_monotonic": deadline,
            "ended_monotonic": ended,
            "started_utc": started_utc,
            "ended_utc": utc_now(),
            "elapsed_seconds": elapsed,
            "wall_deadline_exceeded": ended > deadline,
            "deadline_overrun_seconds": max(0.0, ended - deadline),
            "reported_stop_reason": diagnostics.get("stop_reason"),
            "diagnostics": diagnostics,
            "callback_count": callback_count,
            "last_callback_diagnostics": last_callback_diagnostics,
            "assignment_unchanged": True,
            "raw_returned_powers_exact_float_rationals": [str(power) for power in raw_exact],
            "raw_returned_powers_exactly_feasible": bool(raw_feasible),
            "encoded_final_powers": final["powers"],
        },
    }
    validate_cell(cell)
    return cell


def check_source_drift(protocol: dict) -> None:
    for group in ("method_source_hashes", "r4_source_hashes_at_protocol"):
        for row in protocol[group]:
            if sha256_file(Path(row["absolute_path"])) != row["sha256"]:
                raise RuntimeError("source drift after protocol: " + row["path"])


def run_study(args) -> Path:
    if not math.isfinite(args.seconds_per_cell) or args.seconds_per_cell <= 0:
        raise ValueError("--seconds-per-cell must be finite and positive")
    if args.bootstrap < 0:
        raise ValueError("--bootstrap must be nonnegative")
    output = Path(args.output).resolve()
    if output.exists():
        raise FileExistsError("--output must name a new directory: " + str(output))
    archive, records = load_frozen_cases(Path(args.archive))
    selected, selection = select_cases(records, args.cases)
    protocol = make_protocol(
        archive, records, selected, selection, Path(args.legacy_method).resolve(),
        args.seconds_per_cell, args.bootstrap,
    )
    output.mkdir(parents=True, exist_ok=False)
    # This is deliberately the first file written in the output directory.
    protocol_hash = write_json(output / "protocol.json", protocol)
    Problem, verify_upper, refiners = load_legacy(Path(args.legacy_method))
    completed = []
    for record in selected:
        case_cells = []
        for arm in ARMS:
            cell = run_cell(
                record, arm, args.seconds_per_cell, protocol_hash,
                Problem, verify_upper, refiners[arm],
            )
            cell_path = output / "cells" / record["case_id"] / f"{arm}.json"
            cell_hash = write_json(cell_path, cell)
            completed.append(cell)
            case_cells.append(cell)
            print(json.dumps({
                "case_id": record["case_id"], "arm": arm,
                "final_lower_nats": cell["final"]["independent_verification"]["lower_nats"],
                "elapsed_seconds": cell["refinement"]["elapsed_seconds"],
                "cell_sha256": cell_hash,
            }), flush=True)
        if len({cell["initial_start_sha256"] for cell in case_cells}) != 1:
            raise RuntimeError("matched-start guard failed across arms")
        if len({object_digest(cell["fixed_assignment"]) for cell in case_cells}) != 1:
            raise RuntimeError("matched-assignment guard failed across arms")
    with (output / "cells.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for cell in completed:
            stream.write(canonical_bytes(cell).decode("utf-8") + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    from r4_analysis import analyze_directory
    analyze_directory(output, bootstrap_replicates=args.bootstrap)
    check_source_drift(protocol)
    complete = {
        "schema": "R4_MATCHED_FIXED_ASSIGNMENT_RUN_COMPLETE_V1",
        "scope": SCOPE,
        "protocol_sha256": protocol_hash,
        "selected_cases": len(selected),
        "seed_groups": len({record["seed"] for record in selected}),
        "cells_completed": len(completed),
        "all_initial_final_independently_checked": True,
        "all_starts_matched_within_case": True,
        "all_assignments_unchanged": True,
        "full_44_case_study": len(selected) == 44,
        "completed_utc": utc_now(),
    }
    write_json(output / "RUN_COMPLETE.json", complete)
    manifest_rows = []
    for path in sorted(output.rglob("*"), key=lambda p: p.as_posix()):
        if path.is_file() and path.name != "MANIFEST.json":
            manifest_rows.append({
                "path": path.relative_to(output).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    write_json(output / "MANIFEST.json", {
        "schema": "R4_MATCHED_FIXED_ASSIGNMENT_MANIFEST_V1",
        "protocol_sha256": protocol_hash,
        "files": manifest_rows,
    })
    return output


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds-per-cell", type=float, default=20.0, help="cooperative refinement wall deadline per arm/case (default: 20)")
    parser.add_argument("--cases", nargs="+", help="optional smoke selection: comma-separated case IDs, or one positive N for the first N sorted cases")
    parser.add_argument("--output", required=True, help="new output directory; existing directories are rejected")
    parser.add_argument("--archive", default=str(DEFAULT_ARCHIVE), help="frozen R3 Supplementary_Materials.zip")
    parser.add_argument("--legacy-method", default=str(DEFAULT_LEGACY), help="read-only extracted legacy method directory")
    parser.add_argument("--bootstrap", type=int, default=BOOTSTRAP_REPLICATES, help="whole-seed bootstrap replicates (default: 20000; 0 disables)")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    result = run_study(args)
    print(str(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
