"""Independently replay all 220 matched cells without running any refiner."""
from __future__ import annotations

import argparse
import math
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from matched_study import (
    ARMS, DEFAULT_ARCHIVE, DEFAULT_LEGACY, independent_check, load_frozen_cases,
    load_legacy, read_json, sha256_file, validate_cell, write_json,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study", type=Path)
    parser.add_argument("--output", type=Path, required=True, help="new report JSON")
    parser.add_argument("--archive", default=str(DEFAULT_ARCHIVE))
    parser.add_argument("--legacy-method", default=str(DEFAULT_LEGACY))
    parser.add_argument("--hash-only", action="store_true", help="skip numerical rechecking; hashes/schema/statistics only")
    args = parser.parse_args()
    root = args.study.resolve()
    manifest = read_json(root / "MANIFEST.json")
    for row in manifest["files"]:
        path = root / row["path"]
        if path.stat().st_size != row["bytes"] or sha256_file(path) != row["sha256"]:
            raise ValueError("manifest mismatch: " + row["path"])
    paths = sorted((root / "cells").glob("*/*.json"), key=lambda p: p.as_posix())
    if len(paths) != 220:
        raise ValueError(f"expected 220 cells, found {len(paths)}")
    cells = [read_json(path) for path in paths]
    for cell in cells:
        validate_cell(cell)
    _, records = load_frozen_cases(Path(args.archive))
    records = {record["case_id"]: record for record in records}
    Problem, verify_upper, _ = load_legacy(Path(args.legacy_method))
    numeric_checks = 0
    for cell in cells:
        case_cells = [other for other in cells if other["case_id"] == cell["case_id"]]
        if len({other["initial_start_sha256"] for other in case_cells}) != 1 or len(case_cells) != 5:
            raise ValueError("unmatched case arms/starts: " + cell["case_id"])
        if not args.hash_only:
            record = records[cell["case_id"]]
            problem = Problem(record["case"])
            assignment = tuple(tuple(pair) for pair in cell["fixed_assignment"])
            for label in ("initial", "final"):
                saved = cell[label]
                powers = tuple(Fraction(value) for value in saved["powers"])
                checked = independent_check(problem, verify_upper, record["case"], record["anchor_schedule"], assignment, powers)
                for field in ("lower_nats", "upper_nats"):
                    if Fraction(checked["independent_verification"][field]) != Fraction(saved["independent_verification"][field]):
                        raise ValueError(f"independent {field} mismatch: {cell['case_id']}/{cell['arm']}/{label}")
                numeric_checks += 1
    grouped = defaultdict(dict)
    for cell in cells:
        grouped[cell["case_id"]][cell["arm"]] = cell
    summary = read_json(root / "summary.json")
    tolerance = 1e-12
    for row in summary["overall_summary"]:
        arm = row["arm"]
        selected = []
        for case_cells in grouped.values():
            if arm == "MODERN_ENVELOPE":
                selected.append(max((case_cells[a] for a in ("FU_SCA", "THU_IDE")), key=lambda c: Fraction(c["final"]["independent_verification"]["lower_nats"])))
            else:
                selected.append(case_cells[arm])
        gains = [float(Fraction(c["final"]["independent_verification"]["lower_nats"]) - Fraction(c["initial"]["independent_verification"]["lower_nats"])) for c in selected]
        if abs(sum(gains) / len(gains) - row["verified_lower_gain_mean_nats"]) > tolerance:
            raise ValueError("overall gain summary mismatch: " + arm)
    for row in summary["paired_contrasts"]:
        if row["seed"] != "ALL":
            continue
        differences = []
        for case_cells in grouped.values():
            def value(arm):
                if arm == "MODERN_ENVELOPE":
                    return max(Fraction(case_cells[a]["final"]["independent_verification"]["lower_nats"]) for a in ("FU_SCA", "THU_IDE"))
                return Fraction(case_cells[arm]["final"]["independent_verification"]["lower_nats"])
            differences.append(float(value(row["arm"]) - value(row["comparator"])))
        if abs(sum(differences) / len(differences) - row["mean_difference_nats"]) > tolerance:
            raise ValueError("paired summary mismatch: " + row["contrast"])
    report = {
        "schema": "R4_MATCHED_REPLAY_V1",
        "valid": True,
        "manifest_files_checked": len(manifest["files"]),
        "cells_checked": len(cells),
        "independent_initial_final_numerical_checks": numeric_checks,
        "overall_summaries_recomputed": len(summary["overall_summary"]),
        "paired_contrasts_recomputed": sum(row["seed"] == "ALL" for row in summary["paired_contrasts"]),
        "refiners_executed": 0,
        "scope": "Saved matched fixed-assignment evidence only; no new optimization or channel generation",
    }
    write_json(args.output, report)
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
