"""Finalize a completed matched run after the recorded LOO-list postprocessing fix.

This script never invokes a refiner or changes a cell. It validates all 220 saved
cells, reruns only descriptive analysis, records the source repair explicitly,
and writes completion/manifest records.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from matched_study import (
    ARMS, SCOPE, read_json, sha256_file, utc_now, validate_cell, write_json,
)
from r4_analysis import analyze_directory


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    protocol = read_json(output / "protocol.json")
    cells = sorted((output / "cells").glob("*/*.json"), key=lambda p: p.as_posix())
    if len(cells) != 220:
        raise ValueError(f"expected 220 completed cells, found {len(cells)}")
    for path in cells:
        validate_cell(read_json(path))
    if (output / "summary.json").exists():
        raise FileExistsError("summary already exists; refusing to overwrite analysis")
    changed = []
    for group in ("method_source_hashes", "r4_source_hashes_at_protocol"):
        for row in protocol[group]:
            current = sha256_file(Path(row["absolute_path"]))
            if current != row["sha256"]:
                changed.append({"path": row["path"], "protocol_sha256": row["sha256"], "current_sha256": current})
    expected = {"output/TCOM-Submission-2026-11-06-R4/r4-method/r4_analysis.py"}
    if {row["path"] for row in changed} != expected:
        raise RuntimeError("unexpected source drift: " + repr(changed))
    remediation = {
        "schema": "R4_MATCHED_POSTPROCESSING_REMEDIATION_V1",
        "created_utc": utc_now(),
        "scope": "Descriptive postprocessing only; no refiner, input, power, schedule or cell result was rerun or edited.",
        "defect": "leave_one_seed_out constructed a list of case-dictionary lists rather than a flat case-dictionary list",
        "repair": "Flatten retained case dictionaries before contrast_row; all 220 cell files remain byte-identical.",
        "changed_sources": changed,
        "cell_count_validated_before_analysis": len(cells),
    }
    remediation_hash = write_json(output / "POSTPROCESSING.json", remediation)
    summary = analyze_directory(output)
    if not summary["complete_44_case_study"] or summary["n_seed_groups"] != 11:
        raise RuntimeError("analysis is not the complete 44-case/11-seed study")
    complete = {
        "schema": "R4_MATCHED_FIXED_ASSIGNMENT_RUN_COMPLETE_V1",
        "scope": SCOPE,
        "protocol_sha256": read_json(output / "cells" / summary["selected_case_ids"][0] / "T.json")["protocol_sha256"],
        "selected_cases": 44,
        "seed_groups": 11,
        "cells_completed": 220,
        "all_initial_final_independently_checked": True,
        "all_starts_matched_within_case": True,
        "all_assignments_unchanged": True,
        "full_44_case_study": True,
        "postprocessing_remediation_sha256": remediation_hash,
        "completed_utc": utc_now(),
    }
    write_json(output / "RUN_COMPLETE.json", complete)
    rows = []
    for path in sorted(output.rglob("*"), key=lambda p: p.as_posix()):
        if path.is_file() and path.name != "MANIFEST.json":
            rows.append({"path": path.relative_to(output).as_posix(), "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    write_json(output / "MANIFEST.json", {
        "schema": "R4_MATCHED_FIXED_ASSIGNMENT_MANIFEST_V1",
        "protocol_sha256": complete["protocol_sha256"],
        "files": rows,
    })
    print({"status": "COMPLETE", "cells": 220, "files": len(rows), "output": str(output)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
