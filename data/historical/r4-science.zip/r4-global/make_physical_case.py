"""Create deterministic physical nonorthogonal K=4,S=2,M=4 case JSON files."""
from __future__ import annotations

import argparse
import itertools
import json
from fractions import Fraction as F
from pathlib import Path

import numpy as np


def make_case(seed: int) -> dict:
    rng = np.random.default_rng(np.random.SeedSequence(seed))
    h = (rng.standard_normal((4, 4, 2)) + 1j * rng.standard_normal((4, 4, 2))) / np.sqrt(2)
    gains_target = [[2.0, 3.0, 5.0, 7.0], [3.0, 4.0, 6.0, 8.0]]
    for i in range(4):
        for s in range(2):
            h[i, :, s] *= np.sqrt(gains_target[s][i] / float(np.vdot(h[i, :, s], h[i, :, s]).real))
    vectors, gains, rows = {}, {}, []
    for i in range(4):
        for s in range(2):
            vector = [(F(float(z.real)), F(float(z.imag))) for z in h[i, :, s]]
            vectors[i, s] = vector
            gains[i, s] = sum(a * a + b * b for a, b in vector)
    for i, j in itertools.combinations(range(4), 2):
        for s in range(2):
            re = sum(a * c + b * d for (a, b), (c, d) in zip(vectors[i, s], vectors[j, s]))
            im = sum(a * d - b * c for (a, b), (c, d) in zip(vectors[i, s], vectors[j, s]))
            g, q = gains[i, s], gains[j, s]
            rows.append(dict(users=[i, j], resource=s, gain1=str(g), gain2=str(q), r=str((re * re + im * im) / (g * q))))
    return dict(K=4, S=2, M=4, pmin="1/20", pmax="1/5", budget="2/5", pairs=rows,
                channels_re=h.real.tolist(), channels_im=h.imag.tolist(), generator_seed=seed)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.write_text(json.dumps(make_case(args.seed), indent=2) + "\n", encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
