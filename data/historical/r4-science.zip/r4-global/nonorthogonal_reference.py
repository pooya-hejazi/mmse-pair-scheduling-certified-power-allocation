"""Small exact global-reference driver for nonorthogonal K=4, S=2 cases.

The producer is the existing certificates.run spatial partitioner.  All bounds
reported here come from the independent verify_upper checker, not from producer
advisory values.  This driver handles one case only; it is not a campaign tool.
"""
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import argparse
import hashlib
import json
import random
import time
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT.parent / "legacy-method" / "CR033" / "method" / "core" / "vendor"
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

import certificates  # noqa: E402
import verify_upper  # noqa: E402
from replay_nonorthogonal import (  # noqa: E402
    ASSIGNMENT_SCHEMA,
    EXPECTED_ASSIGNMENTS,
    SUMMARY_SCHEMA,
    case_digest,
    verify_bundle,
    write_json,
)

GLOBAL_SCHEMA = "R4_NONORTHOGONAL_GLOBAL_CANDIDATE_V1"


def labelled_assignments():
    """Return the six resource-labelled K4 assignments in producer order."""
    found = list(certificates.assignments(4))
    if found != EXPECTED_ASSIGNMENTS:
        raise RuntimeError("existing assignment enumerator changed unexpectedly")
    return found


def make_fixture(kind="rational", seed=20261106):
    """Build a deterministic scalar K4/S2 fixture with nonzero correlations."""
    if kind not in ("rational", "binary64"):
        raise ValueError("fixture must be rational or binary64")
    rng = random.Random(seed)
    if kind == "rational":
        gains = [[2, 3, 5, 7], [3, 4, 6, 8]]
    else:
        gains = [[0.5 + 3.0 * rng.random() for _ in range(4)] for _ in range(2)]
    case = dict(K=4, S=2, pmin="1/20", pmax="1/5", budget="2/5", pairs=[])
    for u in range(4):
        for v in range(u + 1, 4):
            for resource in range(2):
                if kind == "rational":
                    correlation = str(Fraction(1 + (u + 2 * v + 3 * resource) % 4, 8))
                else:
                    # repr round-trips to the same binary64 value on reading.
                    correlation = repr(0.05 + 0.85 * rng.random())
                case["pairs"].append(dict(
                    users=[u, v], resource=resource,
                    gain1=str(gains[resource][u]),
                    gain2=str(gains[resource][v]), r=correlation,
                ))
    return case


def _validate_case(case):
    if case.get("K") != 4 or case.get("S") != 2:
        raise ValueError("this reference requires exactly K=4 and S=2")
    if not any(Fraction(row["r"]) != 0 for row in case["pairs"]):
        raise ValueError("fixture/case is orthogonal; nonorthogonal reference requires some r != 0")
    # Reuse the existing producer's complete domain and consistency checks.
    return certificates.Model(case)


def _prepare_output(path):
    path = Path(path)
    if path.exists() and any(path.iterdir()):
        raise ValueError("output directory must be empty to avoid mixed replay artifacts")
    path.mkdir(parents=True, exist_ok=True)
    return path


def _finite_cap_status(metrics):
    return dict(
        spatial_split_limit_reached=bool(metrics.get("spatial_split_limit_reached", False)),
        spatial_root_limit_reached=bool(metrics.get("spatial_root_limit_reached", False)),
        producer_split_cap=certificates.MAX_SPLITS,
        producer_root_cap=certificates.MAX_ROOTS,
        verifier_aggregate_event_cap=verify_upper.MAX_EVENTS,
    )


def generate(case, output, seconds=0.25, verify_seconds=30.0, replay_seconds=120.0,
             tolerance="1/100", source="case"):
    """Generate and independently verify one global bound and six witnesses.

    Complete assignment coverage and meeting the requested gap target are
    deliberately separate statuses.  Partial spatial coverage retains the
    checker's explicit universal upper cover and never claims target success.
    """
    model = _validate_case(case)
    if seconds < 0 or verify_seconds < 0 or replay_seconds < 0:
        raise ValueError("time limits must be nonnegative")
    tolerance = Fraction(tolerance)
    if tolerance < 0:
        raise ValueError("tolerance must be nonnegative")
    assignments = labelled_assignments()
    output = _prepare_output(output)

    # One small producer call; mode=reference uses the generic valid majorants.
    produced = certificates.run(case, "reference", seconds=float(seconds))
    verify_upper.clear_caches()
    checked = verify_upper.verify(case, produced, seconds=float(verify_seconds))
    lower, upper = Fraction(checked["lower_nats"]), Fraction(checked["upper_nats"])
    gap = upper - lower
    roots = [] if produced["proof"]["spatial"] is None else produced["proof"]["spatial"]["roots"]
    by_pairs = {tuple(tuple(pair) for pair in root["pairs"]): root for root in roots}
    if len(by_pairs) != len(roots):
        raise RuntimeError("producer emitted duplicate assignment roots")

    write_json(output / "case.json", case)
    global_candidate = dict(schema=GLOBAL_SCHEMA, case_sha256=case_digest(case), candidate=produced)
    write_json(output / "global-candidate.json", global_candidate)

    records, assignment_rows = [], []
    uniform_power = min(model.high, model.budget / model.k)
    for index, pairs in enumerate(assignments):
        root = by_pairs.get(pairs)
        filename = f"assignment-{index:02d}.json"
        row = dict(assignment_index=index, pairs=[list(pair) for pair in pairs],
                   root_generated=root is not None,
                   witness=filename if root is not None else None)
        assignment_rows.append(row)
        if root is None:
            continue
        witness = dict(
            schema=ASSIGNMENT_SCHEMA, case_sha256=case_digest(case),
            assignment_index=index, pairs=[list(pair) for pair in pairs],
            root=root,
            # Repeat the complete proof so verify_upper.verify can establish a
            # global upper.  The uniform feasible schedule belongs to this
            # assignment, so its independently checked lower is assignment-local.
            candidate=dict(
                schedule=model.encode(pairs, (uniform_power,) * model.k),
                proof=produced["proof"],
            ),
        )
        path = output / filename
        write_json(path, witness)
        records.append(dict(
            assignment_index=index, pairs=row["pairs"], path=filename,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        ))

    complete = len(records) == 6 and checked["metrics"]["complete_assignment_coverage"]
    coverage_status = "COMPLETE_6_OF_6" if complete else f"INCOMPLETE_{len(records)}_OF_6"
    target_met = complete and gap <= tolerance
    summary = dict(
        schema=SUMMARY_SCHEMA, case_sha256=case_digest(case),
        scope="One nonorthogonal K=4,S=2 case; six resource-labelled assignments",
        status="VERIFIED_COMPLETE_GLOBAL_BOUND" if complete else "VERIFIED_PARTIAL_WITH_UNIVERSAL_COVER",
        coverage_status=coverage_status,
        target_status="TARGET_MET" if target_met else "TARGET_NOT_MET",
        target_tolerance_nats=str(tolerance),
        lower_nats=str(lower), upper_nats=str(upper), gap_nats=str(gap),
        certificate_mathematical=bool(complete and checked["certificate_mathematical"]),
        assignments_total=6, assignment_witnesses=len(records), assignments=assignment_rows,
        witness_files=records,
        global_candidate_file="global-candidate.json",
        global_candidate_sha256=hashlib.sha256((output / "global-candidate.json").read_bytes()).hexdigest(),
        producer_status=produced["status"], producer_metrics=produced["metrics"],
        finite_caps=_finite_cap_status(produced["metrics"]),
        initial_independent_verification=checked,
        source=source,
        note="Valid verified bounds only; TARGET_NOT_MET is not an optimality claim.",
    )
    write_json(output / "summary.json", summary)

    # Replay every self-contained witness independently after all files are saved.
    report = verify_bundle(output, seconds=float(replay_seconds))
    write_json(output / "verification-report.json", report)
    return summary


def _load_case(path):
    with Path(path).open("r", encoding="utf-8") as stream:
        return json.load(stream)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    gen = sub.add_parser("generate", help="generate one case, six witnesses, and verified global bounds")
    source = gen.add_mutually_exclusive_group()
    source.add_argument("--case", type=Path, help="existing case JSON")
    source.add_argument("--fixture", choices=("rational", "binary64"), default="rational")
    gen.add_argument("--seed", type=int, default=20261106, help="binary64 fixture seed")
    gen.add_argument("--output", type=Path, required=True, help="new or empty bundle directory")
    gen.add_argument("--seconds", type=float, default=0.25, help="single producer time cap")
    gen.add_argument("--verify-seconds", type=float, default=30.0, help="initial independent verification cap")
    gen.add_argument("--replay-seconds", type=float, default=120.0, help="whole-bundle replay cap")
    gen.add_argument("--tolerance", default="1/100", help="reporting target in nats, not a promised result")
    args = parser.parse_args(argv)
    if args.command == "generate":
        if args.case is not None:
            case, origin = _load_case(args.case), f"case:{args.case}"
        else:
            case, origin = make_fixture(args.fixture, args.seed), f"fixture:{args.fixture};seed:{args.seed}"
        began = time.perf_counter()
        summary = generate(case, args.output, seconds=args.seconds,
                           verify_seconds=args.verify_seconds, replay_seconds=args.replay_seconds,
                           tolerance=args.tolerance, source=origin)
        print(json.dumps(dict(
            status=summary["status"], coverage_status=summary["coverage_status"],
            target_status=summary["target_status"], lower_nats=summary["lower_nats"],
            upper_nats=summary["upper_nats"], gap_nats=summary["gap_nats"],
            assignment_witnesses=summary["assignment_witnesses"],
            seconds=time.perf_counter() - began, output=str(args.output),
        ), indent=2))
        return 0 if summary["coverage_status"] == "COMPLETE_6_OF_6" else 2
    raise AssertionError("unreachable")


if __name__ == "__main__":
    raise SystemExit(main())
