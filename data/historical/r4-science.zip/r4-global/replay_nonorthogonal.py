"""Independent replay for nonorthogonal_reference.py bundles.

This module imports the existing independent verify_upper checker, but never
imports certificates or any other producer/optimizer code.  Every assignment
witness contains a complete global candidate and is checked in a fresh cache.
"""
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import argparse
import hashlib
import json
import time
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT.parent / "legacy-method" / "CR033" / "method" / "core" / "vendor"
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

import verify_upper  # noqa: E402

ASSIGNMENT_SCHEMA = "R4_NONORTHOGONAL_ASSIGNMENT_WITNESS_V1"
SUMMARY_SCHEMA = "R4_NONORTHOGONAL_GLOBAL_SUMMARY_V1"
GLOBAL_SCHEMA = "R4_NONORTHOGONAL_GLOBAL_CANDIDATE_V1"
EXPECTED_ASSIGNMENTS = [
    ((0, 1), (2, 3)),
    ((0, 2), (1, 3)),
    ((0, 3), (1, 2)),
    ((1, 2), (0, 3)),
    ((1, 3), (0, 2)),
    ((2, 3), (0, 1)),
]


def case_digest(case):
    encoded = json.dumps(case, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()


def read_json(path):
    with Path(path).open("r", encoding="utf-8") as stream:
        return json.load(stream)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
                          encoding="utf-8")


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _pairs(value):
    return tuple(tuple(pair) for pair in value)


def _root_for(candidate, pairs):
    spatial = candidate["proof"]["spatial"]
    _require(spatial is not None, "witness has no spatial proof")
    matches = [root for root in spatial["roots"] if _pairs(root["pairs"]) == pairs]
    _require(len(matches) == 1, "witness assignment root is absent or duplicated")
    return matches[0]


def verify_bundle(bundle, seconds=120.0):
    """Replay global and per-assignment proofs; return bounds, never trust stored ones."""
    bundle = Path(bundle).resolve()
    began = time.perf_counter()
    deadline = began + max(0.0, float(seconds))

    def remaining():
        left = deadline - time.perf_counter()
        if left <= 0:
            raise TimeoutError("nonorthogonal bundle replay deadline")
        return left

    case = read_json(bundle / "case.json")
    _require(case.get("K") == 4 and case.get("S") == 2, "replay requires K=4,S=2")
    _require(any(Fraction(row["r"]) != 0 for row in case["pairs"]),
             "replay scope requires a nonorthogonal case")
    digest = case_digest(case)
    summary = read_json(bundle / "summary.json")
    _require(summary.get("schema") == SUMMARY_SCHEMA, "summary schema")
    _require(summary.get("case_sha256") == digest, "summary case hash")

    global_name = summary.get("global_candidate_file")
    _require(global_name == "global-candidate.json", "unexpected global candidate path")
    global_path = bundle / global_name
    _require(hashlib.sha256(global_path.read_bytes()).hexdigest() == summary["global_candidate_sha256"],
             "global candidate file hash")
    global_artifact = read_json(global_path)
    _require(global_artifact.get("schema") == GLOBAL_SCHEMA, "global candidate schema")
    _require(global_artifact.get("case_sha256") == digest, "global candidate case hash")
    global_candidate = global_artifact["candidate"]

    verify_upper.clear_caches()
    global_check = verify_upper.verify(case, global_candidate, seconds=remaining())
    lower = Fraction(global_check["lower_nats"])
    upper = Fraction(global_check["upper_nats"])
    gap = upper - lower
    _require(lower <= upper, "invalid global interval")
    _require(str(lower) == summary["lower_nats"] and str(upper) == summary["upper_nats"],
             "stored global bounds differ from replay")
    _require(str(gap) == summary["gap_nats"], "stored gap differs from replay")

    records = summary.get("witness_files")
    _require(isinstance(records, list) and len(records) <= 6, "witness file list")
    seen, checks = set(), []
    for record in records:
        index = record["assignment_index"]
        _require(isinstance(index, int) and not isinstance(index, bool) and 0 <= index < 6,
                 "assignment index")
        _require(index not in seen, "duplicate assignment witness")
        seen.add(index)
        expected = EXPECTED_ASSIGNMENTS[index]
        _require(_pairs(record["pairs"]) == expected, "assignment enumeration/order")
        filename = f"assignment-{index:02d}.json"
        _require(record["path"] == filename, "unexpected witness path")
        path = bundle / filename
        _require(hashlib.sha256(path.read_bytes()).hexdigest() == record["sha256"],
                 "witness file hash")
        witness = read_json(path)
        _require(witness.get("schema") == ASSIGNMENT_SCHEMA, "witness schema")
        _require(witness.get("case_sha256") == digest, "witness case hash")
        _require(witness.get("assignment_index") == index, "witness index")
        _require(_pairs(witness["pairs"]) == expected, "witness pairs")
        candidate = witness["candidate"]
        _require(_root_for(candidate, expected) == witness["root"], "witness root is not its global-proof root")
        # Compare in resource order, independently of JSON row ordering.
        schedule_pairs = tuple(_pairs([row["users"] for row in
                                       sorted(candidate["schedule"], key=lambda row: row["resource"])]))
        _require(schedule_pairs == expected, "witness schedule is not for its assignment")

        # Fresh caches make each self-contained witness an independent replay.
        verify_upper.clear_caches()
        checked = verify_upper.verify(case, candidate, seconds=remaining())
        _require(checked["upper_nats"] == str(upper),
                 "assignment witness does not reproduce the global upper")
        _require(Fraction(checked["lower_nats"]) <= upper, "invalid assignment lower/global upper")
        checks.append(dict(
            assignment_index=index, pairs=[list(pair) for pair in expected], valid=True,
            lower_nats=checked["lower_nats"], upper_nats=checked["upper_nats"],
            spatial_roots=checked["metrics"]["spatial_roots"],
            spatial_leaves=checked["metrics"]["spatial_leaves"],
            proof_splits=checked["metrics"]["proof_splits"],
        ))

    complete = (seen == set(range(6)) and global_check["metrics"]["complete_assignment_coverage"])
    coverage_status = "COMPLETE_6_OF_6" if complete else f"INCOMPLETE_{len(seen)}_OF_6"
    expected_status = "VERIFIED_COMPLETE_GLOBAL_BOUND" if complete else "VERIFIED_PARTIAL_WITH_UNIVERSAL_COVER"
    tolerance = Fraction(summary["target_tolerance_nats"])
    target_status = "TARGET_MET" if complete and gap <= tolerance else "TARGET_NOT_MET"
    _require(summary["coverage_status"] == coverage_status, "stored coverage status")
    _require(summary["status"] == expected_status, "stored global status")
    _require(summary["target_status"] == target_status, "stored target status")
    _require(summary["assignments_total"] == 6 and summary["assignment_witnesses"] == len(seen),
             "stored assignment counts")
    _require(summary["certificate_mathematical"] == bool(complete and global_check["certificate_mathematical"]),
             "stored mathematical certificate flag")
    _require(len(summary["assignments"]) == 6, "summary must enumerate all six assignments")
    for index, row in enumerate(summary["assignments"]):
        _require(row["assignment_index"] == index and _pairs(row["pairs"]) == EXPECTED_ASSIGNMENTS[index],
                 "summary assignment enumeration")
        _require(row["root_generated"] == (index in seen), "summary root-generated flag")
        _require(row["witness"] == (f"assignment-{index:02d}.json" if index in seen else None),
                 "summary witness link")

    return dict(
        valid=True, status=expected_status, coverage_status=coverage_status,
        target_status=target_status, target_tolerance_nats=str(tolerance),
        lower_nats=str(lower), upper_nats=str(upper), gap_nats=str(gap),
        certificate_mathematical=bool(complete and global_check["certificate_mathematical"]),
        assignments_verified=len(checks), checks=checks,
        global_metrics=global_check["metrics"], seconds=time.perf_counter() - began,
        arithmetic=global_check["arithmetic"],
        producer_imported=False,
        note="Bounds are independently replayed; TARGET_NOT_MET and partial coverage are explicit.",
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle", type=Path)
    parser.add_argument("--seconds", type=float, default=120.0, help="whole-bundle replay deadline")
    parser.add_argument("--report", type=Path, help="optional replay report JSON")
    args = parser.parse_args(argv)
    report = verify_bundle(args.bundle, seconds=args.seconds)
    if args.report is not None:
        write_json(args.report, report)
    print(json.dumps(report, indent=2))
    return 0 if report["coverage_status"] == "COMPLETE_6_OF_6" else 2


if __name__ == "__main__":
    raise SystemExit(main())
