"""Compare five fixed-assignment refiners with saved certified K4 global uppers.

The assignment is the producer's best assignment in each independently replayed
bundle. All arms start at identical uniform feasible powers; no assignment search
is performed. This is a two-fixture check, not a generic K8 optimality claim.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from fractions import Fraction
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
R4 = HERE.parent
sys.path.insert(0, str(R4 / "r4-method"))
from matched_study import (  # noqa: E402
    ARMS, independent_check, load_legacy, object_digest, sha256_file, utc_now,
    write_json,
)


def run_bundle(bundle: Path, seconds: float, Problem, verify_upper, refiners) -> list[dict]:
    case = json.loads((bundle / "case.json").read_text(encoding="utf-8"))
    summary = json.loads((bundle / "summary.json").read_text(encoding="utf-8"))
    global_candidate = json.loads((bundle / "global-candidate.json").read_text(encoding="utf-8"))
    if summary["status"] != "VERIFIED_COMPLETE_GLOBAL_BOUND" or summary["assignment_witnesses"] != 6:
        raise ValueError("bundle lacks a complete six-witness global reference")
    upper = Fraction(summary["upper_nats"])
    problem = Problem(case)
    produced_schedule = global_candidate["candidate"]["schedule"]
    fixed_assignment = problem.anchor(produced_schedule)["assignment"]
    initial_powers = (min(problem.high, problem.budget / problem.k),) * problem.k
    initial = independent_check(problem, verify_upper, case, produced_schedule, fixed_assignment, initial_powers)
    initial_lower = Fraction(initial["independent_verification"]["lower_nats"])
    start_hash = object_digest({"assignment": [list(p) for p in fixed_assignment], "powers": [str(p) for p in initial_powers]})
    out = bundle / "kernel-comparison"
    out.mkdir(exist_ok=False)
    rows = []
    for arm in ARMS:
        callbacks = [0]
        def publish(assignment, powers, diagnostics):
            if tuple(tuple(sorted(map(int, pair))) for pair in assignment) != fixed_assignment:
                raise RuntimeError("assignment changed")
            callbacks[0] += 1
        rng = np.random.default_rng(np.random.SeedSequence([20261106, 987654]))
        started = time.monotonic()
        returned, diagnostics = refiners[arm](
            problem, fixed_assignment, initial_powers, started + seconds, rng, publish,
        )
        elapsed = time.monotonic() - started
        exact = tuple(value if isinstance(value, Fraction) else Fraction(float(value)) for value in returned)
        proposed = independent_check(problem, verify_upper, case, produced_schedule, fixed_assignment, exact)
        proposed_lower = Fraction(proposed["independent_verification"]["lower_nats"])
        fallback = proposed_lower < initial_lower
        final = initial if fallback else proposed
        lower = initial_lower if fallback else proposed_lower
        if lower > upper:
            raise RuntimeError("heuristic lower exceeds certified global upper")
        row = {
            "schema": "R4_K4_GLOBAL_FIXED_KERNEL_CELL_V1",
            "bundle": bundle.name,
            "arm": arm,
            "fixed_assignment": [list(pair) for pair in fixed_assignment],
            "initial_start_sha256": start_hash,
            "initial": initial,
            "proposed_final": proposed,
            "final": final,
            "fallback_to_initial": fallback,
            "global_upper_nats": str(upper),
            "deficit_nats": str(upper - lower),
            "deficit_bit_per_s_Hz": float((upper - lower) / (case["S"] * math.log(2))),
            "refinement_seconds": elapsed,
            "callback_count": callbacks[0],
            "diagnostics": diagnostics,
        }
        write_json(out / f"{arm}.json", row)
        rows.append(row)
        print(bundle.name, arm, "deficit_nats", row["deficit_nats"], "seconds", elapsed, flush=True)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=float, default=5.0)
    parser.add_argument("--bundles", nargs="+", type=Path,
                        default=[HERE / "rational-bundle", HERE / "binary64-bundle"])
    args = parser.parse_args()
    if not math.isfinite(args.seconds) or args.seconds <= 0:
        raise ValueError("seconds must be positive")
    Problem, verify_upper, refiners = load_legacy(R4 / "legacy-method/CR033/method")
    all_rows = []
    for bundle in args.bundles:
        all_rows.extend(run_bundle(bundle.resolve(), args.seconds, Problem, verify_upper, refiners))
    summary = {
        "schema": "R4_K4_GLOBAL_FIXED_KERNEL_SUMMARY_V1",
        "created_utc": utc_now(),
        "scope": "Two nonorthogonal K=4,S=2 fixtures; fixed certified-best assignment; common uniform start; no generic K8 claim",
        "refinement_deadline_seconds_per_arm": args.seconds,
        "cells": len(all_rows),
        "results": all_rows,
    }
    output = HERE / "global-kernel-summary.json"
    write_json(output, summary)
    files = []
    for bundle in args.bundles:
        for path in sorted((bundle.resolve() / "kernel-comparison").glob("*.json")):
            files.append({"path": str(path.relative_to(HERE)), "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    files.append({"path": output.name, "bytes": output.stat().st_size, "sha256": sha256_file(output)})
    write_json(HERE / "global-kernel-manifest.json", {"schema": "R4_K4_GLOBAL_FIXED_KERNEL_MANIFEST_V1", "files": files})
    print({"status": "COMPLETE", "cells": len(all_rows), "summary": str(output)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
