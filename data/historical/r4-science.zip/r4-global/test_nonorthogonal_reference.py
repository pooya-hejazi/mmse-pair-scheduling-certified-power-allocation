"""Light deterministic tests for the small K4 nonorthogonal global reference."""
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import json
import shutil
import tempfile
import unittest
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nonorthogonal_reference import labelled_assignments, make_fixture, generate  # noqa: E402
from replay_nonorthogonal import EXPECTED_ASSIGNMENTS, read_json, verify_bundle, write_json  # noqa: E402


class NonorthogonalReferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(dir=ROOT)
        cls.base = Path(cls.temp.name)
        cls.case = make_fixture("rational")
        cls.bundle = cls.base / "complete"
        cls.summary = generate(cls.case, cls.bundle, seconds=0.25,
                               verify_seconds=30.0, replay_seconds=120.0)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_small_nonorthogonal_k4_has_six_labelled_assignments(self):
        self.assertEqual(self.case["K"], 4)
        self.assertEqual(self.case["S"], 2)
        self.assertTrue(any(Fraction(row["r"]) != 0 for row in self.case["pairs"]))
        self.assertEqual(len(self.case["pairs"]), 12)
        self.assertEqual(labelled_assignments(), EXPECTED_ASSIGNMENTS)
        self.assertEqual(len(set(labelled_assignments())), 6)

    def test_complete_bundle_replays_all_self_contained_witnesses(self):
        self.assertEqual(self.summary["coverage_status"], "COMPLETE_6_OF_6")
        self.assertEqual(self.summary["assignment_witnesses"], 6)
        report = verify_bundle(self.bundle, seconds=120.0)
        self.assertTrue(report["valid"])
        self.assertEqual(report["assignments_verified"], 6)
        self.assertFalse(report["producer_imported"])
        for index, check in enumerate(report["checks"]):
            witness = read_json(self.bundle / f"assignment-{index:02d}.json")
            self.assertEqual(witness["assignment_index"], index)
            self.assertEqual(witness["root"]["pairs"], witness["pairs"])
            schedule_pairs = [row["users"] for row in sorted(
                witness["candidate"]["schedule"], key=lambda row: row["resource"])]
            self.assertEqual(schedule_pairs, witness["pairs"])
            self.assertGreater(Fraction(check["lower_nats"]), 0)
            self.assertEqual(check["upper_nats"], report["upper_nats"])
            self.assertEqual(len(witness["candidate"]["proof"]["spatial"]["roots"]), 6)

    def test_feasible_lower_and_global_upper_are_consistent(self):
        lower = Fraction(self.summary["lower_nats"])
        upper = Fraction(self.summary["upper_nats"])
        self.assertLessEqual(lower, upper)
        self.assertGreater(lower, 0)
        self.assertEqual(Fraction(self.summary["gap_nats"]), upper - lower)
        candidate = read_json(self.bundle / "global-candidate.json")["candidate"]
        powers = [Fraction(power) for row in candidate["schedule"] for power in row["powers"]]
        self.assertEqual(len(powers), 4)
        self.assertTrue(all(Fraction(self.case["pmin"]) <= p <= Fraction(self.case["pmax"]) for p in powers))
        self.assertLessEqual(sum(powers), Fraction(self.case["budget"]))
        expected_target = "TARGET_MET" if upper - lower <= Fraction("1/100") else "TARGET_NOT_MET"
        self.assertEqual(self.summary["target_status"], expected_target)

    def test_hash_binding_detects_witness_modification(self):
        altered = self.base / "altered"
        shutil.copytree(self.bundle, altered)
        path = altered / "assignment-00.json"
        witness = read_json(path)
        witness["pairs"] = [[0, 2], [1, 3]]
        write_json(path, witness)
        with self.assertRaisesRegex(ValueError, "witness file hash"):
            verify_bundle(altered, seconds=30.0)

    def test_zero_producer_budget_is_explicit_partial_not_success(self):
        partial = self.base / "partial"
        summary = generate(self.case, partial, seconds=0.0,
                           verify_seconds=30.0, replay_seconds=30.0)
        self.assertEqual(summary["status"], "VERIFIED_PARTIAL_WITH_UNIVERSAL_COVER")
        self.assertEqual(summary["coverage_status"], "INCOMPLETE_0_OF_6")
        self.assertEqual(summary["target_status"], "TARGET_NOT_MET")
        self.assertEqual(summary["assignment_witnesses"], 0)
        report = verify_bundle(partial, seconds=30.0)
        self.assertTrue(report["valid"])
        self.assertEqual(report["coverage_status"], "INCOMPLETE_0_OF_6")
        self.assertLessEqual(Fraction(report["lower_nats"]), Fraction(report["upper_nats"]))

    def test_binary64_fixture_is_deterministic_and_nonorthogonal(self):
        left = make_fixture("binary64", seed=17)
        right = make_fixture("binary64", seed=17)
        self.assertEqual(left, right)
        self.assertNotEqual(left, make_fixture("binary64", seed=18))
        self.assertTrue(all(0 < float(row["r"]) < 1 for row in left["pairs"]))
        # Every user gain is consistent across all six pairs on each resource.
        gains = {}
        for row in left["pairs"]:
            u, v = row["users"]
            resource = row["resource"]
            for user, key in ((u, "gain1"), (v, "gain2")):
                value = Fraction(row[key])
                self.assertIn(value, (gains.setdefault((user, resource), value),))


if __name__ == "__main__":
    unittest.main(verbosity=2)
