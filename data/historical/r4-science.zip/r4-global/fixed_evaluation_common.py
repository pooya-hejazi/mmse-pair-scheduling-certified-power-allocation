"""Shared serialization and exact unit conversion for fixed-assignment evaluation."""
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT.parent / "legacy-method" / "CR033" / "method" / "core" / "vendor"
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

import verify_upper  # noqa: E402

ARMS = ("T", "W", "S", "FU_SCA", "THU_IDE")
CELL_SCHEMA = "R4_FIXED_ASSIGNMENT_CELL_V1"
CONTEXT_SCHEMA = "R4_FIXED_ASSIGNMENT_CONTEXT_V1"
SUMMARY_SCHEMA = "R4_FIXED_ASSIGNMENT_SUMMARY_V1"
MANIFEST_SCHEMA = "R4_FIXED_ASSIGNMENT_MANIFEST_V1"


def read_json(path):
    with Path(path).open("r", encoding="utf-8") as stream:
        return json.load(stream)


def canonical_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def value_digest(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def file_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
                    encoding="utf-8")


def assignment_of(schedule):
    return tuple(tuple(row["users"]) for row in sorted(schedule, key=lambda row: row["resource"]))


def powers_of(schedule):
    powers = [None] * 4
    for row in schedule:
        for user, power in zip(row["users"], row["powers"]):
            if powers[user] is not None:
                raise ValueError("duplicate schedule user")
            powers[user] = Fraction(power)
    if any(power is None for power in powers):
        raise ValueError("incomplete schedule powers")
    return tuple(powers)


def nats_to_bits(value):
    """Return a decimal value and an exact rational interval for nats/ln(2)."""
    value = Fraction(value)
    if value < 0:
        raise ValueError("rate/deficit conversion requires a nonnegative value")
    ln2_lower, ln2_upper = verify_upper.log_enclosure(2)
    lower, upper = value / ln2_upper, value / ln2_lower
    with localcontext() as context:
        context.prec = 70
        decimal = ((Decimal(value.numerator) / Decimal(value.denominator)) / Decimal(2).ln())
        text = format(decimal, ".60g")
    with localcontext() as context:
        context.prec = 50
        decimal_value = Decimal(text)
        _require_interval(decimal_value, lower, upper)
    return dict(
        decimal=text,
        lower=str(lower),
        upper=str(upper),
        ln2_lower=str(ln2_lower),
        ln2_upper=str(ln2_upper),
    )


def _require_interval(decimal_value, lower, upper):
    # The decimal is a display value; the exact strings above define the interval.
    # Check with a conservative decimal enclosure of the exact endpoints.
    low_decimal = Decimal(lower.numerator if isinstance(lower, Fraction) else Fraction(lower).numerator)
    del low_decimal  # Endpoint validity is checked below without binary floating point.
    lower, upper = Fraction(lower), Fraction(upper)
    with localcontext() as context:
        context.prec = 60
        approximate_lower = Decimal(lower.numerator) / Decimal(lower.denominator)
        approximate_upper = Decimal(upper.numerator) / Decimal(upper.denominator)
        tolerance = Decimal("1e-45") * max(Decimal(1), abs(approximate_upper))
        if not approximate_lower - tolerance <= decimal_value <= approximate_upper + tolerance:
            raise ValueError("decimal bit conversion lies outside its exact interval")


def deficit_values(global_upper_nats, final_lower_nats):
    deficit = Fraction(global_upper_nats) - Fraction(final_lower_nats)
    if deficit < 0:
        raise ValueError("verified final lower exceeds the verified global upper")
    converted = nats_to_bits(deficit)
    return dict(
        deficit_below_global_upper_nats=str(deficit),
        deficit_below_global_upper_bit_s_hz=converted["decimal"],
        deficit_below_global_upper_bit_s_hz_lower=converted["lower"],
        deficit_below_global_upper_bit_s_hz_upper=converted["upper"],
        ln2_lower_nats=converted["ln2_lower"],
        ln2_upper_nats=converted["ln2_upper"],
    )


def validate_deficit_fields(record, global_upper_nats, final_lower_nats):
    expected = deficit_values(global_upper_nats, final_lower_nats)
    for key, value in expected.items():
        if record.get(key) != value:
            raise ValueError(f"deficit arithmetic mismatch: {key}")
