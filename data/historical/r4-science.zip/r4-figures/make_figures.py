#!/usr/bin/env python3
"""Build R4 scientific figures without modifying the frozen evidence archives.

Usage (from any working directory):
    python r4-figures/make_figures.py --legacy-only
    python r4-figures/make_figures.py --matched-dir matched-kernel-results-v2

The first command writes the three detailed legacy figures and the compact rate
and certification figures. The second additionally writes detailed and compact matched
figures, but only after summary.json declares completion and all 220 common-start
cells pass integrity checks. Paths default to the R4 directory
containing this script; archives can be overridden with --r3-archive and
--r1-archive. Every run writes source/images/r4-figures-manifest.json with
SHA-256 hashes for all consumed files/archive members and generated figures.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.ticker import ScalarFormatter
from PIL import Image


R4_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = R4_DIR.parents[1]
DEFAULT_R3 = PROJECT_ROOT / "output" / "TCOM-Submission-2026-11-04-R3" / "Supplementary_Materials.zip"
DEFAULT_R1 = PROJECT_ROOT / "tmp" / "tcom-r3-science" / "baseline_R1" / "Supplementary_Materials.zip"
DEFAULT_OUTPUT = R4_DIR / "source" / "images"
R3_CSV = "CR033/study/analysis/holdout/all-cells.csv"
R3_SUMMARY = "CR033/study/analysis/holdout/SUMMARY.json"
R3_CONTRASTS = "CR033/study/analysis/holdout/CONTRASTS.json"
R3_PROTOCOL = "CR033/protocol-v2/PROTOCOL.json"
R1_CSV = "reproduction/studies/corrected/analysis/all-cells.csv"
TARGET_NATS = 0.01
ARMS = ("T", "W", "S", "FU_SCA", "THU_IDE")
ARM_LABELS = {
    "T": "T",
    "W": "W",
    "S": "S",
    "FU_SCA": "Fu-SCA (adapted; Fu et al., TCOM 2026)",
    "THU_IDE": "Thu-IDE (adapted; Thu et al., TCOM 2026; AM v1)",
}
COLORS = {
    "blue": "#0072B2",
    "orange": "#E69F00",
    "green": "#009E73",
    "vermillion": "#D55E00",
    "purple": "#7B3294",
    "sky": "#56B4E9",
    "pink": "#CC79A7",
    "gray": "#6E6E6E",
    "light_gray": "#D9D9D9",
    "black": "#222222",
}
ARM_COLORS = {
    "T": COLORS["blue"],
    "W": COLORS["purple"],
    "S": COLORS["green"],
    "FU_SCA": COLORS["orange"],
    "THU_IDE": COLORS["vermillion"],
}
ARM_MARKERS = {"T": "o", "W": "s", "S": "^", "FU_SCA": "D", "THU_IDE": "v"}


class FigureDataError(RuntimeError):
    """Raised when an input is absent, incomplete, or internally inconsistent."""


@dataclass
class LegacyData:
    corrective_rows: list[dict[str, str]]
    modern_summary: dict[str, Any]
    modern_contrasts: list[dict[str, Any]]
    practical_threshold: float


@dataclass
class MatchedData:
    protocol: dict[str, Any]
    summary: dict[str, Any]
    cells: dict[str, dict[str, dict[str, Any]]]
    case_order: list[str]
    gains: dict[str, np.ndarray]
    times: dict[str, np.ndarray]
    verification_times: dict[str, np.ndarray]
    seeds: np.ndarray


class HashRegistry:
    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []
        self._seen: set[str] = set()

    @staticmethod
    def _hash(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def file(self, path: Path, role: str) -> None:
        key = f"file:{path.resolve()}:{role}"
        if key in self._seen:
            return
        data = path.read_bytes()
        self.records.append(
            {
                "role": role,
                "path": str(path.resolve()),
                "bytes": len(data),
                "sha256": self._hash(data),
            }
        )
        self._seen.add(key)

    def member(self, archive: Path, member: str, data: bytes, role: str) -> None:
        key = f"member:{archive.resolve()}:{member}:{role}"
        if key in self._seen:
            return
        self.records.append(
            {
                "role": role,
                "path": str(archive.resolve()),
                "zip_member": member,
                "bytes": len(data),
                "sha256": self._hash(data),
            }
        )
        self._seen.add(key)


def read_member(archive: Path, member: str, registry: HashRegistry, role: str) -> bytes:
    try:
        with zipfile.ZipFile(archive) as zf:
            data = zf.read(member)
    except FileNotFoundError as exc:
        raise FigureDataError(f"Required frozen archive not found: {archive}") from exc
    except KeyError as exc:
        raise FigureDataError(f"Required member {member!r} not found in {archive}") from exc
    registry.member(archive, member, data, role)
    return data


def read_csv_member(archive: Path, member: str, registry: HashRegistry, role: str) -> list[dict[str, str]]:
    data = read_member(archive, member, registry, role)
    return list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"))))


def read_json_member(archive: Path, member: str, registry: HashRegistry, role: str) -> Any:
    data = read_member(archive, member, registry, role)
    return json.loads(data.decode("utf-8-sig"))


def finite_float(value: Any, context: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise FigureDataError(f"Non-numeric value for {context}: {value!r}") from exc
    if not math.isfinite(result):
        raise FigureDataError(f"Non-finite value for {context}: {value!r}")
    return result


def rational_float(value: Any, context: str) -> tuple[Fraction, float]:
    try:
        exact = Fraction(value)
    except (TypeError, ValueError, ZeroDivisionError) as exc:
        raise FigureDataError(f"Invalid exact rational for {context}: {value!r}") from exc
    result = float(exact)
    if not math.isfinite(result):
        raise FigureDataError(f"Non-finite exact rational for {context}: {value!r}")
    return exact, result


def load_legacy(r3_archive: Path, r1_archive: Path, registry: HashRegistry) -> LegacyData:
    registry.file(r3_archive, "frozen R3 archive")
    registry.file(r1_archive, "frozen R1 corrective archive")
    corrective = read_csv_member(r1_archive, R1_CSV, registry, "corrective per-cell rates and certificates")
    summary = read_json_member(r3_archive, R3_SUMMARY, registry, "R3 modern-effect summary")
    contrasts = read_json_member(r3_archive, R3_CONTRASTS, registry, "R3 paired case contrasts")
    protocol = read_json_member(r3_archive, R3_PROTOCOL, registry, "R3 prospective practical threshold")
    # Read the complete modern table as an integrity cross-check, although the
    # plotted paired effects come from CONTRASTS.json.
    modern_rows = read_csv_member(r3_archive, R3_CSV, registry, "R3 complete 220-cell table")

    selected = [r for r in corrective if r.get("panel") in {"main", "scale"}]
    expected = {(scene, panel, index) for scene in ("o1", "asu") for panel, count in (("main", 12), ("scale", 4)) for index in range(count)}
    observed = {(r["scene"], r["panel"], int(r["index"])) for r in selected}
    if observed != expected:
        raise FigureDataError("Corrective CSV does not contain exactly the 24 main and 8 scale cases")
    for scene in ("o1", "asu"):
        for method in ("joint", "grid", "full"):
            rows = [r for r in selected if r["scene"] == scene and r["panel"] == "main" and r["method"] == method]
            if len(rows) != 12:
                raise FigureDataError(f"Expected 12 {scene} main rows for {method}; found {len(rows)}")
        for method in ("grid", "pricing"):
            rows = [r for r in selected if r["scene"] == scene and r["panel"] == "scale" and r["method"] == method]
            if len(rows) != 4:
                raise FigureDataError(f"Expected 4 {scene} scale rows for {method}; found {len(rows)}")
    for row in selected:
        if row["method"] not in {"joint", "grid", "full", "pricing"}:
            continue
        lower = finite_float(row["lower_nats"], f"{row['case']} lower_nats")
        upper = finite_float(row["upper_nats"], f"{row['case']} upper_nats")
        gap = finite_float(row["gap_nats"], f"{row['case']} gap_nats")
        if gap < 0 or not math.isclose(gap, upper - lower, rel_tol=2e-8, abs_tol=2e-10):
            raise FigureDataError(f"Certificate gap is inconsistent for {row['case']} ({row['method']})")

    if summary.get("complete") is not True or summary.get("completed_valid_cells") != 220:
        raise FigureDataError("R3 modern summary is not the complete 220-cell holdout analysis")
    if len(modern_rows) != 220 or len(contrasts) != 44:
        raise FigureDataError("R3 modern data must contain 220 cells and 44 paired contrasts")
    effects = summary.get("effects", {}).get("absolute_modern", {})
    if len(effects.get("group_effects", [])) != 11 or len(effects.get("leave_one_group_out", [])) != 11:
        raise FigureDataError("R3 absolute_modern effect must contain 11 group and 11 LOO values")
    threshold = finite_float(
        protocol["primary"]["absolute_substantial_threshold_bit_per_s_Hz"],
        "registered practical threshold",
    )
    return LegacyData(selected, summary, contrasts, threshold)


def validate_modern(data: LegacyData) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float, float]:
    seeds = np.array(sorted({int(row["seed"]) for row in data.modern_contrasts}), dtype=int)
    if len(seeds) != 11:
        raise FigureDataError(f"Expected 11 whole-seed groups; found {len(seeds)}")
    values = np.array([finite_float(row["absolute_modern"], row["case_id"]) for row in data.modern_contrasts])
    row_seeds = np.array([int(row["seed"]) for row in data.modern_contrasts])
    group_effects = np.array([values[row_seeds == seed].mean() for seed in seeds])
    loo_means = np.array([values[row_seeds != seed].mean() for seed in seeds])
    loo_medians = np.array([np.median(values[row_seeds != seed]) for seed in seeds])
    effect = data.modern_summary["effects"]["absolute_modern"]
    archived_groups = np.array(effect["group_effects"], dtype=float)
    archived_loo = np.array(effect["leave_one_group_out"], dtype=float)
    if not np.allclose(group_effects, archived_groups, rtol=2e-10, atol=2e-14):
        raise FigureDataError("Recomputed whole-seed effects do not match R3 SUMMARY.json")
    if not np.allclose(loo_means, archived_loo, rtol=2e-10, atol=2e-14):
        raise FigureDataError("Recomputed leave-one-seed-out means do not match R3 SUMMARY.json")
    if not math.isclose(values.mean(), finite_float(effect["mean"], "absolute_modern mean"), rel_tol=2e-10, abs_tol=2e-14):
        raise FigureDataError("Overall modern-effect mean does not match R3 SUMMARY.json")
    return seeds, group_effects, loo_means, loo_medians, float(values.mean()), float(np.median(values))


def set_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8.5,
            "axes.labelsize": 9,
            "axes.titlesize": 9.5,
            "axes.titleweight": "bold",
            "legend.fontsize": 8,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "axes.linewidth": 0.8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "axes.axisbelow": True,
            "grid.color": "#E6E6E6",
            "grid.linewidth": 0.6,
            "grid.alpha": 0.9,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "lines.linewidth": 1.25,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "mathtext.fontset": "dejavusans",
        }
    )


def scientific(axis: Any, which: str = "y") -> None:
    formatter = ScalarFormatter(useMathText=True)
    formatter.set_scientific(True)
    formatter.set_powerlimits((-3, 3))
    target = axis.yaxis if which == "y" else axis.xaxis
    target.set_major_formatter(formatter)


def case_rows(data: LegacyData, scene: str, panel: str, method: str) -> list[dict[str, str]]:
    return sorted(
        [r for r in data.corrective_rows if r["scene"] == scene and r["panel"] == panel and r["method"] == method],
        key=lambda r: int(r["index"]),
    )


def decomposition(data: LegacyData) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for scene in ("o1", "asu"):
        w = np.array([finite_float(r["SE"], r["case"]) for r in case_rows(data, scene, "main", "joint")])
        g = np.array([finite_float(r["SE"], r["case"]) for r in case_rows(data, scene, "main", "grid")])
        f = np.array([finite_float(r["SE"], r["case"]) for r in case_rows(data, scene, "main", "full")])
        grid_gain = g - w
        refinement_gain = f - g
        result[scene] = {
            "wmmse": w,
            "grid": g,
            "full": f,
            "grid_gain": grid_gain,
            "refinement_gain": refinement_gain,
            "mean_grid_gain": float(grid_gain.mean()),
            "mean_refinement_gain": float(refinement_gain.mean()),
            "mean_total_gain": float((f - w).mean()),
        }
    grid = sum(result[s]["mean_grid_gain"] for s in ("o1", "asu")) / 2
    refinement = sum(result[s]["mean_refinement_gain"] for s in ("o1", "asu")) / 2
    total = grid + refinement
    if total <= 0:
        raise FigureDataError("Pooled Full-minus-WMMSE gain is not positive; decomposition share undefined")
    result["overall"] = {
        "mean_grid_gain": grid,
        "mean_refinement_gain": refinement,
        "mean_total_gain": total,
        "grid_share_percent": 100 * grid / total,
        "refinement_share_percent": 100 * refinement / total,
    }
    return result


def plot_rate_decomposition(data: LegacyData) -> tuple[plt.Figure, dict[str, Any]]:
    dec = decomposition(data)
    fig = plt.figure(figsize=(7.5, 6.5), constrained_layout=True)
    grid_spec = fig.add_gridspec(2, 2, height_ratios=(1.22, 1.0))
    method_colors = (COLORS["purple"], COLORS["blue"], COLORS["vermillion"])
    method_markers = ("s", "o", "^")
    for col, scene in enumerate(("o1", "asu")):
        ax = fig.add_subplot(grid_spec[0, col])
        rates = np.column_stack((dec[scene]["wmmse"], dec[scene]["grid"], dec[scene]["full"]))
        for row in rates:
            ax.plot((0, 1, 2), row, color="#8A8A8A", alpha=0.58, linewidth=0.9, zorder=1)
        for method_index in range(3):
            ax.scatter(
                np.full(rates.shape[0], method_index),
                rates[:, method_index],
                s=20,
                marker=method_markers[method_index],
                facecolor=method_colors[method_index],
                edgecolor="white",
                linewidth=0.35,
                alpha=0.9,
                zorder=2,
            )
        ax.set_xticks((0, 1, 2), ("WMMSE", "Grid", "Full"))
        ax.set_xlim(-0.3, 2.3)
        ax.set_ylabel("Achieved rate (bit/s/Hz)")
        ax.set_title(f"({'ab'[col]}) {scene.upper()}: 12 paired per-case trajectories", loc="left")
        ax.grid(axis="x", visible=False)
        ax.margins(y=0.09)

    ax = fig.add_subplot(grid_spec[1, :])
    labels = ("O1", "ASU", "Overall")
    grid_values = np.array([dec["o1"]["mean_grid_gain"], dec["asu"]["mean_grid_gain"], dec["overall"]["mean_grid_gain"]])
    ref_values = np.array([dec["o1"]["mean_refinement_gain"], dec["asu"]["mean_refinement_gain"], dec["overall"]["mean_refinement_gain"]])
    y = np.arange(3)
    ax.barh(y, grid_values, color=COLORS["blue"], height=0.55)
    ax.barh(y, ref_values, left=grid_values, color=COLORS["orange"], height=0.55)
    overall_share = dec["overall"]["grid_share_percent"]
    for index in range(3):
        total = grid_values[index] + ref_values[index]
        ax.text(grid_values[index] / 2, y[index], f"Grid {grid_values[index]:.6f}", ha="center", va="center", color="white", fontsize=7.5, fontweight="bold")
        annotation = f"Shared refinement +{ref_values[index]:.6f}"
        if index == 2:
            annotation += f"\nOverall Grid share: {overall_share:.6f}% ({overall_share:.1f}% to 1 d.p.)"
        ax.text(total + 0.0022, y[index], annotation, ha="left", va="center", color=COLORS["black"], fontsize=7.4)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlim(0, max(grid_values + ref_values) * 1.72)
    ax.set_xlabel("Mean Full-minus-WMMSE gain (bit/s/Hz)")
    ax.set_title("(c) Grid versus shared-refinement gain decomposition", loc="left")
    ax.grid(axis="y", visible=False)
    metrics = {
        scene: {
            key: (value.tolist() if isinstance(value, np.ndarray) else value)
            for key, value in dec[scene].items()
        }
        for scene in ("o1", "asu", "overall")
    }
    metrics["rounding_note"] = "Exact corrective-CSV computation; one-decimal rounding uses standard round-to-nearest."
    return fig, metrics


def plot_rate_decomposition_compact(data: LegacyData) -> tuple[plt.Figure, dict[str, Any]]:
    """IEEE-width decomposition-only companion to the detailed trajectory figure."""
    dec = decomposition(data)
    fig, ax = plt.subplots(figsize=(7.2, 2.75), constrained_layout=True)
    labels = ("O1", "ASU", "Overall")
    grid_values = np.array([dec["o1"]["mean_grid_gain"], dec["asu"]["mean_grid_gain"], dec["overall"]["mean_grid_gain"]])
    ref_values = np.array([dec["o1"]["mean_refinement_gain"], dec["asu"]["mean_refinement_gain"], dec["overall"]["mean_refinement_gain"]])
    y = np.arange(3)
    ax.barh(y, grid_values, color=COLORS["blue"], height=0.56)
    ax.barh(y, ref_values, left=grid_values, color=COLORS["orange"], height=0.56)
    overall_share = dec["overall"]["grid_share_percent"]
    for index in range(3):
        total = grid_values[index] + ref_values[index]
        ax.text(grid_values[index] / 2, y[index], f"Grid {grid_values[index]:.6f}", ha="center", va="center", color="white", fontsize=8, fontweight="bold")
        annotation = f"Shared refinement +{ref_values[index]:.6f}"
        if index == 2:
            annotation += f"\nGrid share {overall_share:.6f}% ({overall_share:.1f}% to 1 d.p.)"
        ax.text(total + 0.003, y[index], annotation, ha="left", va="center", color=COLORS["black"], fontsize=8)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlim(0, max(grid_values + ref_values) * 1.90)
    ax.set_xlabel("Mean Full-minus-WMMSE gain (bit/s/Hz)")
    ax.set_title("O1/ASU/overall gain decomposition", loc="left")
    ax.grid(axis="y", visible=False)
    metrics = {
        scene: {
            "mean_grid_gain": dec[scene]["mean_grid_gain"],
            "mean_refinement_gain": dec[scene]["mean_refinement_gain"],
            "mean_total_gain": dec[scene]["mean_total_gain"],
        }
        for scene in ("o1", "asu", "overall")
    }
    metrics["overall"]["grid_share_percent"] = overall_share
    metrics["figure_size_inches"] = [7.2, 2.75]
    return fig, metrics


def plot_certification_gap(data: LegacyData) -> tuple[plt.Figure, dict[str, Any]]:
    fig, axes = plt.subplots(1, 2, figsize=(7.5, 4.25), sharey=True, constrained_layout=True)
    metrics: dict[str, Any] = {"target_nats": TARGET_NATS, "scenes": {}}
    specs = (
        ("full", "main", "Full (main)", COLORS["vermillion"], "^", -0.13),
        ("grid", "scale", "Grid (scale)", COLORS["blue"], "o", 0.0),
        ("pricing", "scale", "Grid + pricing (scale)", COLORS["green"], "s", 0.13),
    )
    for ax, scene, panel_tag in zip(axes, ("o1", "asu"), ("a", "b")):
        ax.axhspan(0.004, TARGET_NATS, color="#F2F2F2", zorder=0)
        ax.axvline(11.5, color="#AAAAAA", linewidth=0.8, zorder=1)
        ax.axhline(TARGET_NATS, color=COLORS["black"], linestyle=(0, (4, 3)), linewidth=1.1, zorder=2)
        scene_metrics: dict[str, Any] = {}
        for method, panel, label, color, marker, offset in specs:
            rows = case_rows(data, scene, panel, method)
            x = np.arange(len(rows)) + (12 if panel == "scale" else 0) + offset
            gaps = np.array([finite_float(r["gap_nats"], r["case"]) for r in rows])
            ax.scatter(x, gaps, s=31, marker=marker, color=color, edgecolor="white", linewidth=0.45, label=label, zorder=3)
            misses = gaps > TARGET_NATS
            scene_metrics[method] = {
                "cases": [r["case"] for r in rows],
                "gap_nats": gaps.tolist(),
                "above_target": misses.tolist(),
                "above_target_count": int(misses.sum()),
                "count": len(rows),
            }
        ax.set_yscale("log")
        ax.set_ylim(0.004, 100)
        ax.set_xlim(-0.8, 16.0)
        ax.set_xticks(np.arange(16), [f"M{i:02d}" for i in range(12)] + [f"S{i:02d}" for i in range(4)], rotation=45, ha="right")
        ax.tick_params(axis="x", labelsize=7.3)
        ax.set_xlabel("Main case (M) / scale case (S)")
        ax.set_title(f"({panel_tag}) {scene.upper()}: all 12 main + 4 scale cases", loc="left")
        ax.grid(axis="x", visible=False)
        ax.text(11.7, 75, "scale", fontsize=7, color=COLORS["gray"], va="top")
        ax.text(11.3, 75, "main", fontsize=7, color=COLORS["gray"], va="top", ha="right")
        summary = "; ".join(
            f"{label.split(' (')[0]} {scene_metrics[method]['above_target_count']}/{scene_metrics[method]['count']}"
            for method, _, label, *_ in specs
        )
        ax.text(
            0.02,
            0.025,
            f"Above 0.01-nat target: {summary}",
            transform=ax.transAxes,
            fontsize=7.1,
            va="bottom",
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.88, "pad": 1.5},
        )
        metrics["scenes"][scene] = scene_metrics
    axes[0].set_ylabel("Absolute upper-minus-lower gap (nats, log scale)")
    axes[0].text(0.025, TARGET_NATS * 1.22, "0.01-nat target", fontsize=7.4, color=COLORS["black"])
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside upper center", ncol=3, frameon=False)
    return fig, metrics


def plot_certification_gap_compact(data: LegacyData) -> tuple[plt.Figure, dict[str, Any]]:
    """IEEE-width certificate coverage plot; no cases or target misses are omitted."""
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.75), sharey=True, constrained_layout=True)
    metrics: dict[str, Any] = {"target_nats": TARGET_NATS, "figure_size_inches": [7.2, 2.75], "scenes": {}}
    specs = (
        ("full", "main", "Full (main)", COLORS["vermillion"], "^", -0.12),
        ("grid", "scale", "Grid (scale)", COLORS["blue"], "o", 0.0),
        ("pricing", "scale", "Grid + pricing", COLORS["green"], "s", 0.12),
    )
    for ax, scene, panel_tag in zip(axes, ("o1", "asu"), ("a", "b")):
        ax.axhspan(0.004, TARGET_NATS, color="#F2F2F2", zorder=0)
        ax.axvline(11.5, color="#AAAAAA", linewidth=0.75, zorder=1)
        ax.axhline(TARGET_NATS, color=COLORS["black"], linestyle=(0, (4, 3)), linewidth=1.0, zorder=2)
        scene_metrics: dict[str, Any] = {}
        for method, panel, label, color, marker, offset in specs:
            rows = case_rows(data, scene, panel, method)
            x = np.arange(len(rows)) + (12 if panel == "scale" else 0) + offset
            gaps = np.array([finite_float(r["gap_nats"], r["case"]) for r in rows])
            ax.scatter(x, gaps, s=22, marker=marker, color=color, edgecolor="white", linewidth=0.35, label=label, zorder=3)
            misses = gaps > TARGET_NATS
            scene_metrics[method] = {
                "cases": [r["case"] for r in rows],
                "gap_nats": gaps.tolist(),
                "above_target": misses.tolist(),
                "above_target_count": int(misses.sum()),
                "count": len(rows),
            }
        ax.set_yscale("log")
        ax.set_ylim(0.004, 100)
        ax.set_xlim(-0.8, 16.0)
        ax.set_xticks(np.arange(16), [f"M{i:02d}" for i in range(12)] + [f"S{i:02d}" for i in range(4)], rotation=45, ha="right")
        ax.tick_params(axis="x", labelsize=6.4)
        ax.tick_params(axis="y", labelsize=7.4)
        ax.set_xlabel("Case (M = main, S = scale)", fontsize=8)
        ax.set_title(f"({panel_tag}) {scene.upper()}: 12 main + 4 scale", loc="left", fontsize=9)
        ax.grid(axis="x", visible=False)
        ax.text(
            0.02,
            0.018,
            "Misses: Full 12/12; Grid 4/4; pricing 4/4",
            transform=ax.transAxes,
            fontsize=6.6,
            va="bottom",
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.90, "pad": 1.0},
        )
        ax.text(0.98, 0.17, "0.01-nat target", transform=ax.transAxes, fontsize=6.6, ha="right", va="bottom", color=COLORS["black"])
        metrics["scenes"][scene] = scene_metrics
    axes[0].set_ylabel("Absolute gap (nats; log scale)", fontsize=8.5)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside upper center", ncol=3, frameon=False, fontsize=7.4)
    return fig, metrics


def plot_modern_leverage(data: LegacyData) -> tuple[plt.Figure, dict[str, Any]]:
    seeds, groups, loo_means, loo_medians, overall_mean, overall_median = validate_modern(data)
    special_index = int(np.flatnonzero(seeds == 2026113404)[0])
    x = np.arange(len(seeds))
    fig, axes = plt.subplots(2, 2, figsize=(7.5, 6.4), constrained_layout=True)
    ax = axes[0, 0]
    for index, value in enumerate(groups):
        special = index == special_index
        color = COLORS["vermillion"] if special else COLORS["blue"]
        ax.vlines(index, 0, value, color=color, linewidth=1.0, alpha=0.75)
        ax.scatter(index, value, s=39 if special else 27, marker="D" if special else "o", color=color, edgecolor="white", linewidth=0.45, zorder=3)
    ax.axhline(0, color=COLORS["black"], linewidth=0.8)
    ax.annotate(
        f"group 2026113404\n{groups[special_index]:.6e} bit/s/Hz",
        xy=(special_index, groups[special_index]),
        xytext=(special_index + 1.0, groups[special_index] * 0.70),
        arrowprops={"arrowstyle": "->", "color": COLORS["vermillion"], "lw": 0.9},
        fontsize=7.5,
        color=COLORS["vermillion"],
    )
    ax.text(
        0.02,
        0.03,
        f"Substantial threshold +{data.practical_threshold:.2f} bit/s/Hz (off scale)",
        transform=ax.transAxes,
        fontsize=7.2,
        va="bottom",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.9, "pad": 1.5},
    )
    ax.set_title("(a) All 11 whole-seed T-modern effects", loc="left")
    ax.set_ylabel("Four-case mean effect (bit/s/Hz)")
    scientific(ax)

    ax = axes[0, 1]
    ordinary = np.delete(groups, special_index)
    zoom_limit = float(np.max(np.abs(ordinary))) * 1.35
    for index, value in enumerate(groups):
        if index == special_index:
            continue
        ax.vlines(index, 0, value, color=COLORS["blue"], linewidth=1.0, alpha=0.75)
        ax.scatter(index, value, s=27, marker="o", color=COLORS["blue"], edgecolor="white", linewidth=0.45, zorder=3)
    ax.set_ylim(-zoom_limit, zoom_limit)
    ax.annotate(
        f"2026113404 retained; below zoom\n{groups[special_index]:.6e} bit/s/Hz",
        xy=(special_index, -zoom_limit * 0.93),
        xytext=(special_index + 0.75, zoom_limit * 0.58),
        arrowprops={"arrowstyle": "->", "color": COLORS["vermillion"], "lw": 0.9},
        fontsize=7.3,
        color=COLORS["vermillion"],
    )
    ax.scatter(special_index, -zoom_limit * 0.93, marker="v", s=40, color=COLORS["vermillion"], clip_on=False, zorder=4)
    ax.axhline(0, color=COLORS["black"], linewidth=0.8)
    ax.set_title("(b) Tiny-effect zoom (all groups retained)", loc="left")
    scientific(ax)

    ax = axes[1, 0]
    colors = [COLORS["vermillion"] if i == special_index else COLORS["blue"] for i in x]
    ax.plot(x, loo_means, color="#AAAAAA", linewidth=0.8, zorder=1)
    ax.scatter(x, loo_means, c=colors, s=29, marker="o", edgecolor="white", linewidth=0.45, zorder=3, label="LOO mean")
    ax.axhline(overall_mean, color=COLORS["black"], linestyle=(0, (4, 3)), linewidth=1.0, label="All-seed mean")
    ax.axhline(0, color="#888888", linewidth=0.7)
    ax.set_title("(c) Leave-one-whole-seed-out means", loc="left")
    ax.set_ylabel("Mean of retained case contrasts")
    scientific(ax)
    ax.legend(frameon=False, loc="upper right", fontsize=7.2)

    ax = axes[1, 1]
    ax.plot(x, loo_medians, color="#AAAAAA", linewidth=0.8, zorder=1)
    ax.scatter(x, loo_medians, c=colors, s=30, marker="s", edgecolor="white", linewidth=0.45, zorder=3, label="LOO median")
    ax.axhline(overall_median, color=COLORS["black"], linestyle=(0, (4, 3)), linewidth=1.0, label="All-seed median")
    ax.axhline(0, color="#888888", linewidth=0.7)
    ax.set_title("(d) Leave-one-whole-seed-out medians", loc="left")
    scientific(ax)
    ax.legend(frameon=False, loc="upper right", fontsize=7.2)

    for ax in axes.flat:
        ax.set_xticks(x, [f"{seed % 100:02d}" for seed in seeds])
        ax.set_xlim(-0.55, 10.55)
        ax.grid(axis="x", visible=False)
    axes[0, 0].set_xlabel("Whole-seed group (20261134xx)")
    axes[0, 1].set_xlabel("Whole-seed group (20261134xx)")
    axes[1, 0].set_xlabel("Omitted whole-seed group (20261134xx)")
    axes[1, 1].set_xlabel("Omitted whole-seed group (20261134xx)")
    metrics = {
        "effect": "T minus per-case maximum of Fu-SCA and Thu-IDE; frozen R3 absolute_modern",
        "seed_groups": seeds.tolist(),
        "whole_seed_group_effects_bit_per_s_Hz": groups.tolist(),
        "leave_one_seed_out_means_bit_per_s_Hz": loo_means.tolist(),
        "leave_one_seed_out_medians_bit_per_s_Hz": loo_medians.tolist(),
        "overall_mean_bit_per_s_Hz": overall_mean,
        "overall_median_bit_per_s_Hz": overall_median,
        "influential_group": {"seed": 2026113404, "effect_bit_per_s_Hz": float(groups[special_index]), "retained": True},
        "registered_substantial_threshold_bit_per_s_Hz": data.practical_threshold,
    }
    return fig, metrics


def load_matched(matched_dir: Path, registry: HashRegistry) -> MatchedData:
    summary_path = matched_dir / "summary.json"
    protocol_path = matched_dir / "protocol.json"
    if not summary_path.is_file():
        raise FigureDataError(
            f"Matched study incomplete: {summary_path} is missing. "
            "Run --matched-dir only after the completed analysis writes summary.json; use --legacy-only meanwhile."
        )
    if not protocol_path.is_file():
        raise FigureDataError(f"Matched study incomplete: protocol is missing at {protocol_path}")
    registry.file(summary_path, "matched-study completion summary")
    registry.file(protocol_path, "matched-study protocol")
    try:
        summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
        protocol = json.loads(protocol_path.read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise FigureDataError(f"Matched study incomplete: summary/protocol JSON is not readable: {exc}") from exc
    if summary.get("complete_44_case_study") is not True or summary.get("n_cases") != 44 or summary.get("n_seed_groups") != 11:
        raise FigureDataError(
            f"Matched study incomplete: {summary_path} must certify 44 cases and 11 whole-seed groups; "
            f"found complete_44_case_study={summary.get('complete_44_case_study')!r}, "
            f"n_cases={summary.get('n_cases')!r}, n_seed_groups={summary.get('n_seed_groups')!r}."
        )
    design = protocol.get("design", {})
    case_order = list(design.get("case_order", []))
    arms = tuple(design.get("arms", ARMS))
    if arms != ARMS:
        raise FigureDataError(f"Matched arm order/identity changed: expected {ARMS}, found {arms}")
    if len(case_order) != 44 or len(set(case_order)) != 44:
        raise FigureDataError(f"Matched study requires 44 unique cases; protocol lists {len(case_order)}")
    expected_cells = int(design.get("cells_planned", 220))
    if expected_cells != 220:
        raise FigureDataError(f"Matched protocol plans {expected_cells} cells rather than 220")
    for key in ("expected_cells", "completed_valid_cells"):
        if key in summary and int(summary[key]) != (220 if key == "expected_cells" else 220):
            raise FigureDataError(f"Matched summary {key}={summary[key]!r}; expected 220")
    if "cases" in summary and isinstance(summary["cases"], int) and summary["cases"] != 44:
        raise FigureDataError(f"Matched summary reports {summary['cases']} cases rather than 44")

    cells: dict[str, dict[str, dict[str, Any]]] = {}
    gains = {arm: np.zeros(44) for arm in ARMS}
    times = {arm: np.zeros(44) for arm in ARMS}
    verification_times = {arm: np.zeros(44) for arm in ARMS}
    seeds = np.zeros(44, dtype=int)
    missing: list[str] = []
    for case_index, case_id in enumerate(case_order):
        cells[case_id] = {}
        common_initial_lower: Fraction | None = None
        common_schedule_hash: str | None = None
        common_start_hash: str | None = None
        resource_count: int | None = None
        for arm in ARMS:
            path = matched_dir / "cells" / case_id / f"{arm}.json"
            if not path.is_file():
                missing.append(str(path))
                continue
            registry.file(path, f"matched cell {case_id}/{arm}")
            try:
                cell = json.loads(path.read_text(encoding="utf-8-sig"))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                raise FigureDataError(f"Matched cell is not readable: {path}: {exc}") from exc
            if cell.get("case_id") != case_id or cell.get("arm") != arm:
                raise FigureDataError(f"Matched cell identity mismatch in {path}")
            initial = cell.get("initial", {})
            final = cell.get("final", {})
            initial_verify = initial.get("independent_verification", {})
            final_verify = final.get("independent_verification", {})
            if not initial.get("feasible_and_rate_checked") or not final.get("feasible_and_rate_checked"):
                raise FigureDataError(f"Initial/final feasibility verification failed in {path}")
            if not initial_verify.get("valid") or not final_verify.get("valid"):
                raise FigureDataError(f"Independent interval verification is invalid in {path}")
            initial_exact, _ = rational_float(initial_verify.get("lower_nats"), f"{path} initial lower")
            final_exact, _ = rational_float(final_verify.get("lower_nats"), f"{path} final lower")
            gain_exact, _ = rational_float(cell.get("verified_lower_gain_nats"), f"{path} verified gain")
            if final_exact - initial_exact != gain_exact:
                raise FigureDataError(f"Verified gain does not equal final-minus-initial lower bound in {path}")
            if gain_exact < 0:
                raise FigureDataError(f"Independently retained gain is negative in {path}")
            schedule_hash = initial.get("schedule_sha256")
            start_hash = cell.get("initial_start_sha256")
            resources = len(initial.get("schedule", []))
            if resources <= 0 or len(final.get("schedule", [])) != resources:
                raise FigureDataError(f"Invalid resource schedule in {path}")
            if common_initial_lower is None:
                common_initial_lower = initial_exact
                common_schedule_hash = schedule_hash
                common_start_hash = start_hash
                resource_count = resources
            elif (
                initial_exact != common_initial_lower
                or schedule_hash != common_schedule_hash
                or start_hash != common_start_hash
                or resources != resource_count
            ):
                raise FigureDataError(f"Common-start identity/initial verification mismatch in {path}")
            elapsed = finite_float(cell.get("refinement", {}).get("elapsed_seconds"), f"{path} refinement time")
            verify_initial = finite_float(initial_verify.get("seconds"), f"{path} initial verification time")
            verify_final = finite_float(final_verify.get("seconds"), f"{path} final verification time")
            if min(elapsed, verify_initial, verify_final) < 0:
                raise FigureDataError(f"Negative timing value in {path}")
            gains[arm][case_index] = float(gain_exact / (resource_count * math.log(2.0)))
            times[arm][case_index] = elapsed
            verification_times[arm][case_index] = verify_initial + verify_final
            cells[case_id][arm] = cell
        if missing:
            continue
        first = cells[case_id]["T"]
        seeds[case_index] = int(first["seed"])
        for arm in ARMS:
            if cells[case_id][arm].get("seed") != first.get("seed"):
                raise FigureDataError(f"Whole-seed identity mismatch in matched case {case_id}")
    if missing:
        preview = "\n  ".join(missing[:8])
        raise FigureDataError(
            f"Matched study incomplete: {len(missing)} of 220 required cell files are missing. "
            f"First missing paths:\n  {preview}\nNo matched figure was generated."
        )
    if len(set(seeds.tolist())) != 11:
        raise FigureDataError("Matched study must retain 11 whole-seed groups")
    return MatchedData(protocol, summary, cells, case_order, gains, times, verification_times, seeds)


def matched_contrasts(data: MatchedData) -> tuple[list[tuple[str, np.ndarray]], np.ndarray, np.ndarray]:
    specs = (
        ("T − W", "T", "W"),
        ("T − S", "T", "S"),
        ("T − Fu-SCA", "T", "FU_SCA"),
        ("T − Thu-IDE", "T", "THU_IDE"),
        ("Fu-SCA − Thu-IDE", "FU_SCA", "THU_IDE"),
    )
    contrasts = [(label, data.gains[left] - data.gains[right]) for label, left, right in specs]
    seed_values = np.array(sorted(set(data.seeds.tolist())))
    group_matrix = np.array(
        [[values[data.seeds == seed].mean() for _, values in contrasts] for seed in seed_values]
    )
    plan = data.protocol.get("analysis_plan", {}).get("cluster_bootstrap", {})
    replicates = int(plan.get("replicates", 20000))
    rng_seed = int(plan.get("seed", 2026110399))
    if replicates < 1000:
        raise FigureDataError(f"Matched bootstrap replicate count is too small: {replicates}")
    rng = np.random.Generator(np.random.PCG64(rng_seed))
    indices = rng.integers(0, len(seed_values), size=(replicates, len(seed_values)))
    boot = group_matrix[indices, :].mean(axis=1)
    intervals = np.percentile(boot, (2.5, 97.5), axis=0).T
    return contrasts, seed_values, intervals


def matched_boxplot(ax: plt.Axes, arrays: list[np.ndarray], positions: np.ndarray) -> None:
    box = ax.boxplot(
        arrays,
        positions=positions,
        widths=0.55,
        whis=(5, 95),
        showfliers=False,
        patch_artist=True,
        medianprops={"color": COLORS["black"], "linewidth": 1.2},
        whiskerprops={"color": "#777777", "linewidth": 0.8},
        capprops={"color": "#777777", "linewidth": 0.8},
        flierprops={"markersize": 0},
    )
    for patch, arm in zip(box["boxes"], ARMS):
        patch.set_facecolor(ARM_COLORS[arm])
        patch.set_alpha(0.16)
        patch.set_edgecolor(ARM_COLORS[arm])
        patch.set_linewidth(1.0)


def plot_matched(data: MatchedData) -> tuple[plt.Figure, dict[str, Any]]:
    contrasts, seed_values, intervals = matched_contrasts(data)
    fig = plt.figure(figsize=(11.0, 6.7), constrained_layout=True)
    spec = fig.add_gridspec(2, 2, width_ratios=(1.05, 1.15), height_ratios=(1, 1))
    ax_gain = fig.add_subplot(spec[0, 0])
    ax_contrast = fig.add_subplot(spec[0, 1])
    ax_time = fig.add_subplot(spec[1, 0])
    ax_verify = fig.add_subplot(spec[1, 1])
    positions = np.arange(len(ARMS))
    rng = np.random.Generator(np.random.PCG64(2026110604))
    jitter = rng.uniform(-0.16, 0.16, size=(len(ARMS), len(data.case_order)))
    matched_boxplot(ax_gain, [data.gains[arm] for arm in ARMS], positions)
    for index, arm in enumerate(ARMS):
        ax_gain.scatter(
            np.full(44, index) + jitter[index],
            data.gains[arm],
            s=10,
            marker=ARM_MARKERS[arm],
            color=ARM_COLORS[arm],
            alpha=0.52,
            linewidth=0,
            label=ARM_LABELS[arm],
            zorder=3,
        )
    ax_gain.axhline(0, color=COLORS["black"], linewidth=0.8)
    ax_gain.set_xticks(positions, ("T", "W", "S", "Fu-SCA", "Thu-IDE"))
    ax_gain.set_ylabel("Verified gain from common start (bit/s/Hz)")
    ax_gain.set_title("(a) All 44 common-start gains per arm", loc="left")
    ax_gain.grid(axis="x", visible=False)
    scientific(ax_gain)

    y = np.arange(len(contrasts))
    for index, (label, values) in enumerate(contrasts):
        group_means = np.array([values[data.seeds == seed].mean() for seed in seed_values])
        ax_contrast.scatter(group_means, np.full(11, index) + rng.uniform(-0.12, 0.12, 11), s=12, color="#888888", alpha=0.65, linewidth=0, zorder=2)
        mean = values.mean()
        low, high = intervals[index]
        ax_contrast.errorbar(
            mean,
            index,
            xerr=np.array([[mean - low], [high - mean]]),
            fmt="D",
            markersize=5.5,
            color=COLORS["blue"],
            ecolor=COLORS["blue"],
            elinewidth=1.3,
            capsize=3,
            zorder=3,
        )
        ax_contrast.text(high, index + 0.25, f"mean {mean:.3e}", fontsize=7.0, color=COLORS["blue"], va="bottom")
    ax_contrast.axvline(0, color=COLORS["black"], linewidth=0.85)
    ax_contrast.set_yticks(y, [label for label, _ in contrasts])
    ax_contrast.invert_yaxis()
    ax_contrast.set_xlabel("Paired gain contrast (bit/s/Hz)")
    ax_contrast.set_title("(b) Case-paired contrasts; whole-seed means and 95% CIs", loc="left")
    ax_contrast.grid(axis="y", visible=False)
    scientific(ax_contrast, "x")

    matched_boxplot(ax_time, [data.times[arm] for arm in ARMS], positions)
    for index, arm in enumerate(ARMS):
        ax_time.scatter(np.full(44, index) + jitter[index], data.times[arm], s=9, marker=ARM_MARKERS[arm], color=ARM_COLORS[arm], alpha=0.45, linewidth=0)
    deadline = finite_float(data.protocol["design"]["seconds_per_cell_refinement_wall_deadline"], "matched refinement deadline")
    ax_time.axhline(deadline, color=COLORS["black"], linestyle=(0, (4, 3)), linewidth=1.0, label=f"{deadline:g} s deadline")
    ax_time.set_xticks(positions, ("T", "W", "S", "Fu-SCA", "Thu-IDE"))
    ax_time.set_ylabel("Refinement wall time (s)")
    ax_time.set_title("(c) All 44 measured refinement times per arm", loc="left")
    ax_time.grid(axis="x", visible=False)
    ax_time.legend(frameon=False, loc="upper left", fontsize=7.2)
    ax_time.margins(y=0.10)

    matched_boxplot(ax_verify, [data.verification_times[arm] for arm in ARMS], positions)
    for index, arm in enumerate(ARMS):
        ax_verify.scatter(np.full(44, index) + jitter[index], data.verification_times[arm], s=9, marker=ARM_MARKERS[arm], color=ARM_COLORS[arm], alpha=0.45, linewidth=0)
    ax_verify.set_xticks(positions, ("T", "W", "S", "Fu-SCA", "Thu-IDE"))
    ax_verify.set_ylabel("Initial + final verification time (s)")
    ax_verify.set_title("(d) Independent verification timing (all cells)", loc="left")
    ax_verify.grid(axis="x", visible=False)
    ax_verify.margins(y=0.10)

    handles = [Line2D([0], [0], marker=ARM_MARKERS[arm], color=ARM_COLORS[arm], markerfacecolor=ARM_COLORS[arm], markersize=5.5, linewidth=1.0) for arm in ARMS]
    fig.legend(handles, [ARM_LABELS[arm] for arm in ARMS], loc="outside lower center", ncol=2, frameon=False)
    metrics: dict[str, Any] = {
        "cases": len(data.case_order),
        "whole_seed_groups": len(seed_values),
        "conversion": "verified_lower_gain_nats / (S * ln(2)); gross occupied-resource bit/s/Hz",
        "gains_bit_per_s_Hz": {},
        "refinement_seconds": {},
        "verification_seconds": {},
        "paired_contrasts_bit_per_s_Hz": {},
    }
    for arm in ARMS:
        for destination, values in (
            ("gains_bit_per_s_Hz", data.gains[arm]),
            ("refinement_seconds", data.times[arm]),
            ("verification_seconds", data.verification_times[arm]),
        ):
            metrics[destination][arm] = {
                "values": values.tolist(),
                "mean": float(values.mean()),
                "median": float(np.median(values)),
                "minimum": float(values.min()),
                "maximum": float(values.max()),
            }
    for index, (label, values) in enumerate(contrasts):
        metrics["paired_contrasts_bit_per_s_Hz"][label] = {
            "values": values.tolist(),
            "mean": float(values.mean()),
            "median": float(np.median(values)),
            "whole_seed_bootstrap_95_percent_interval": intervals[index].tolist(),
            "bootstrap_replicates": int(data.protocol.get("analysis_plan", {}).get("cluster_bootstrap", {}).get("replicates", 20000)),
        }
    return fig, metrics


def plot_matched_compact(data: MatchedData) -> tuple[plt.Figure, dict[str, Any]]:
    """Main-paper matched comparison with independent contrast scales and no timing panels."""
    contrasts, seed_values, intervals = matched_contrasts(data)
    fig = plt.figure(figsize=(7.2, 3.05), constrained_layout=True)
    spec = fig.add_gridspec(1, 3, width_ratios=(1.85, 1.0, 1.0))
    ax_gain = fig.add_subplot(spec[0, 0])
    positions = np.arange(len(ARMS))
    rng = np.random.Generator(np.random.PCG64(2026110604))
    jitter = rng.uniform(-0.15, 0.15, size=(len(ARMS), len(data.case_order)))
    matched_boxplot(ax_gain, [data.gains[arm] for arm in ARMS], positions)
    for index, arm in enumerate(ARMS):
        ax_gain.scatter(
            np.full(44, index) + jitter[index],
            data.gains[arm],
            s=7,
            marker=ARM_MARKERS[arm],
            color=ARM_COLORS[arm],
            alpha=0.50,
            linewidth=0,
            zorder=3,
        )
    ax_gain.axhline(0, color=COLORS["black"], linewidth=0.8)
    ax_gain.set_xticks(positions, ("T", "W", "S", "Fu-SCA", "Thu-IDE"))
    ax_gain.set_ylabel("Verified gain (bit/s/Hz)")
    ax_gain.set_title("(a) Common-start gains (44 cases)", loc="left")
    ax_gain.grid(axis="x", visible=False)
    ax_gain.margins(y=0.12)
    scientific(ax_gain)

    selected = (
        ("T − Fu-SCA", "FU_SCA", "b", 1e9, r"$\times 10^{-9}$"),
        ("T − Thu-IDE", "THU_IDE", "c", 1e6, r"$\times 10^{-6}$"),
    )
    contrast_lookup = {label: (values, intervals[index]) for index, (label, values) in enumerate(contrasts)}
    compact_metrics: dict[str, Any] = {
        "cases": len(data.case_order),
        "whole_seed_groups": len(seed_values),
        "conversion": "verified_lower_gain_nats / (S * ln(2)); gross occupied-resource bit/s/Hz",
        "figure_size_inches": [7.2, 3.05],
        "key_contrasts_bit_per_s_Hz": {},
    }
    for column, (label, arm, panel_tag, display_scale, exponent_label) in enumerate(selected, start=1):
        values, interval = contrast_lookup[label]
        group_means = np.array([values[data.seeds == seed].mean() for seed in seed_values])
        mean = float(values.mean())
        low, high = (float(interval[0]), float(interval[1]))
        scaled_mean = mean * display_scale
        ax = fig.add_subplot(spec[0, column])
        ax.scatter(group_means * display_scale, rng.uniform(-0.20, 0.20, len(seed_values)), s=13, color="#777777", alpha=0.72, linewidth=0, zorder=2)
        ax.errorbar(
            scaled_mean,
            0,
            xerr=np.array([[(mean - low) * display_scale], [(high - mean) * display_scale]]),
            fmt="D",
            markersize=5.5,
            color=ARM_COLORS[arm],
            ecolor=ARM_COLORS[arm],
            elinewidth=1.4,
            capsize=3,
            zorder=3,
        )
        ax.text(scaled_mean, 0.35, f"mean {scaled_mean:.3f}", ha="center", va="bottom", fontsize=7.4, color=ARM_COLORS[arm])
        ax.axvline(0, color=COLORS["black"], linewidth=0.8)
        ax.set_ylim(-0.62, 0.62)
        ax.set_yticks([])
        ax.set_xlabel(f"Paired gain\n({exponent_label} bit/s/Hz)")
        ax.set_title(f"({panel_tag}) {label}", loc="left")
        ax.grid(axis="y", visible=False)
        ax.margins(x=0.18)
        compact_metrics["key_contrasts_bit_per_s_Hz"][label] = {
            "mean": mean,
            "whole_seed_bootstrap_95_percent_interval": [low, high],
            "whole_seed_group_means": group_means.tolist(),
        }

    handles = [
        Line2D([0], [0], marker=ARM_MARKERS[arm], color=ARM_COLORS[arm], markerfacecolor=ARM_COLORS[arm], markersize=5.5, linewidth=1.0)
        for arm in ("FU_SCA", "THU_IDE")
    ]
    fig.legend(handles, [ARM_LABELS[arm] for arm in ("FU_SCA", "THU_IDE")], loc="outside lower center", ncol=1, frameon=False, fontsize=8)
    return fig, compact_metrics


def save_figure(fig: plt.Figure, name: str, output_dir: Path, registry: HashRegistry) -> dict[str, Any]:
    paths = {extension: output_dir / f"{name}.{extension}" for extension in ("png", "pdf", "svg")}
    fig.savefig(paths["png"], dpi=300, bbox_inches="tight", pad_inches=0.045, metadata={"Software": "R4 make_figures.py"})
    fig.savefig(paths["pdf"], bbox_inches="tight", pad_inches=0.045, metadata={"Title": name, "CreationDate": None})
    fig.savefig(paths["svg"], bbox_inches="tight", pad_inches=0.045, metadata={"Date": None, "Creator": "R4 make_figures.py"})
    plt.close(fig)
    output: dict[str, Any] = {}
    for extension, path in paths.items():
        registry.file(path, f"generated figure {name} ({extension})")
        record = registry.records[-1]
        output[extension] = {"path": str(path), "bytes": record["bytes"], "sha256": record["sha256"]}
    with Image.open(paths["png"]) as image:
        output["png"]["pixel_dimensions"] = list(image.size)
        output["png"]["dpi_metadata"] = list(image.info.get("dpi", ()))
        if image.info.get("dpi") and not all(abs(value - 300) < 0.1 for value in image.info["dpi"]):
            raise FigureDataError(f"PNG DPI metadata is not 300 for {paths['png']}")
    return output


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--legacy-only", action="store_true", help="Generate detailed legacy figures and compact rate/certification figures")
    mode.add_argument("--matched-dir", type=Path, help="Completed matched-study directory; also generates all legacy and compact figures")
    parser.add_argument("--r3-archive", type=Path, default=DEFAULT_R3, help=argparse.SUPPRESS)
    parser.add_argument("--r1-archive", type=Path, default=DEFAULT_R1, help=argparse.SUPPRESS)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT, help=argparse.SUPPRESS)
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = parse_args(argv)
    set_style()
    output_dir = args.output_dir.resolve()
    registry = HashRegistry()
    script_path = Path(__file__).resolve()
    try:
        registry.file(script_path, "figure-generation script")
        legacy = load_legacy(args.r3_archive.resolve(), args.r1_archive.resolve(), registry)
        matched = load_matched(args.matched_dir.resolve(), registry) if args.matched_dir else None
        figures: dict[str, Any] = {}
        metrics: dict[str, Any] = {}
        builders = [
            ("r4-rate-decomposition", plot_rate_decomposition),
            ("r4-rate-decomposition-compact", plot_rate_decomposition_compact),
            ("r4-certification-gap", plot_certification_gap),
            ("r4-certification-gap-compact", plot_certification_gap_compact),
            ("r4-modern-leverage", plot_modern_leverage),
        ]
        # Validate and construct every figure before writing any output. An
        # incomplete matched study therefore cannot leave a partial new set.
        prepared: list[tuple[str, plt.Figure, dict[str, Any]]] = []
        for name, builder in builders:
            fig, figure_metrics = builder(legacy)
            prepared.append((name, fig, figure_metrics))
        if matched is not None:
            fig, figure_metrics = plot_matched(matched)
            prepared.append(("r4-matched-tcom", fig, figure_metrics))
            fig, figure_metrics = plot_matched_compact(matched)
            prepared.append(("r4-matched-tcom-compact", fig, figure_metrics))
        output_dir.mkdir(parents=True, exist_ok=True)
        for name, fig, figure_metrics in prepared:
            figures[name] = save_figure(fig, name, output_dir, registry)
            metrics[name] = figure_metrics
        input_records = list(registry.records)
        # save_figure appends generated files to the same registry; inputs are
        # exactly the records preceding the first generated-figure record.
        input_records = [record for record in registry.records if not str(record["role"]).startswith("generated figure")]
        manifest = {
            "schema": "R4_SCIENTIFIC_FIGURE_MANIFEST_V1",
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "mode": "legacy-only" if args.legacy_only else "legacy-plus-matched",
            "style": {
                "color_palette": "colorblind-safe Okabe-Ito-derived categorical colors plus redundant markers",
                "png_dpi": 300,
                "pdf_font_type": 42,
                "svg_font_type": "none (live text)",
                "font_family": "DejaVu Sans",
            },
            "inputs": input_records,
            "outputs": figures,
            "computed_metrics": metrics,
            "integrity_notes": [
                "All 24 corrective main cases and all 8 scale cases are plotted; no target misses are filtered.",
                "All 11 R3 whole-seed groups are plotted; group 2026113404 remains in every summary.",
                "No source-paper numerical curves are read, inferred, or reconstructed.",
                "Matched figures require complete_44_case_study=true, 44 cases/11 seeds, 220 verified cells, exact common starts, and exact rational gain identities.",
            ],
        }
        manifest_path = output_dir / "r4-figures-manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"Wrote {len(figures)} figures in PNG/PDF/SVG to {output_dir}")
        print(f"Manifest: {manifest_path}")
        if matched is None:
            print("Matched figure skipped (--legacy-only).")
        return 0
    except FigureDataError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except (OSError, KeyError, IndexError, TypeError, ValueError) as exc:
        print(f"ERROR: Figure generation failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
