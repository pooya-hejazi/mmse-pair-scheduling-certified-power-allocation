import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class ReplayCompletenessTest(unittest.TestCase):
    def test_missing_planned_attempt_is_not_valid(self):
        script = Path(__file__).with_name("replay_certificates.py")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "campaign-ledger.json").write_text(json.dumps({"rows": [{
                "case": "missing", "method": "full", "panel": "main", "scene": "O1", "index": 0,
            }]}), encoding="utf-8")
            completed = subprocess.run([sys.executable, str(script), str(root), "--seconds", "5"], check=False)
            self.assertNotEqual(completed.returncode, 0)
            report = json.loads((root / "CERTIFICATE_REPLAY.json").read_text(encoding="utf-8"))
            self.assertFalse(report["valid"])
            self.assertEqual(report["planned_cells"], 1)
            self.assertEqual(report["cells_checked"], 0)
            self.assertEqual(report["errors"][0]["error"], "MISSING_PLANNED_ATTEMPT")


if __name__ == "__main__":
    unittest.main()
