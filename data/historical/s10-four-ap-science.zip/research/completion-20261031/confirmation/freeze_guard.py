"""Frozen local dependency closure and runtime identity, checked before dispatch."""
from pathlib import Path
import hashlib,json,sys,importlib.metadata as md,importlib.util
D=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def runtime():
    out={'executable':sys.executable,'python':sys.version,'executable_sha256':digest(sys.executable),'distributions':{},'generator_sources':{}}
    for name in ['numpy','scipy','sympy','psutil','DeepMIMO']:
        try:
            dist=md.distribution(name);records=[p for p in (dist.files or []) if str(p).endswith('.dist-info/RECORD')]
            out['distributions'][name]={'version':dist.version,'RECORD_sha256':digest(dist.locate_file(records[0])) if records else None}
        except md.PackageNotFoundError:out['distributions'][name]=None
    spec=importlib.util.find_spec('DeepMIMOv3')
    if spec:
        root=Path(spec.origin).parent
        out['generator_sources']={str(p.relative_to(root)):digest(p) for p in root.rglob('*.py')}
    return out
def verify_frozen():
    manifest=json.loads((D/'NOMINAL_INPUT_MANIFEST.json').read_text(encoding='utf-8-sig'))
    for name,expected in manifest['code_sha256'].items():
        assert digest(D/name)==expected, 'frozen file hash mismatch: '+name
    expected=json.loads((D/'NOMINAL_RUNTIME.json').read_text(encoding='utf-8'))
    actual=runtime();key=next((k for k,v in expected.items() if Path(v['executable']).resolve()==Path(sys.executable).resolve()),None)
    assert key is not None and actual==expected[key], 'runtime identity differs from freeze'
    return digest(D/'NOMINAL_INPUT_MANIFEST.json')

if __name__=='__main__':print(json.dumps(runtime(),indent=2))
