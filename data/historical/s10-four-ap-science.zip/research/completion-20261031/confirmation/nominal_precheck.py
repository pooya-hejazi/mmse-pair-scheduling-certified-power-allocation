"""Synthetic/analytic only. Entire script externally capped at60 s. No held-out I/O."""
import json,time,math
from pathlib import Path
from fractions import Fraction as F
from nominal_worker import price,ceiling,Snapshot,spatial
from global_core import Problem,rate_iv
from nominal_analysis import primary
D=Path(__file__).resolve().parent

def fixture(a='0',b='2',r='0',budget='1/5'):
    return dict(name='SYNTHETIC',K=2,S=1,M=2,pmin='1/20',pmax='1/5',budget=budget,
                pairs=[dict(users=[0,1],resource=0,gain1=a,gain2=b,r=r)])

def main():
    started=time.perf_counter();checks=[]
    for a,b,r in [('0','0','0'),('0','2','0'),('2','0','0'),('2','3','1'),('2','3','999999/1000000')]:
        case=fixture(a,b,r);p=Problem(case);upper=ceiling(p)
        for x in [F(1,20),F(1,10),F(1,5)]:
            for y in [F(1,20),F(1,10),F(1,5)]:
                assert rate_iv(F(a),F(b),F(r),x,y)[0]<=upper
        for lam in [F(0),F(1),F(5)]:
            z=price(F(a),F(b),F(r),lam,F(1,20),F(1,5))
            assert z['upper']>=z['lower']
            for x in [F(1,20),F(1,10),F(1,5)]:
                for y in [F(1,20),F(1,10),F(1,5)]:
                    assert rate_iv(F(a),F(b),F(r),x,y)[0]-lam*(x+y)<=z['upper']
        checks.append('zero/collinear/near-collinear pricing and full-family ceiling '+str((a,b,r)))
    # Direct stationary coordinate: g=2, lambda=3/2 -> p=1/6, zero user atlow.
    z=price(F(0),F(2),F(0),F(3,2),F(1,20),F(1,5));assert z['point']==[F(1,20),F(1,6)]
    path=D/'synthetic.snapshot.json';snap=Snapshot(fixture(),path,time.perf_counter(),time.perf_counter()+3,'analytic')
    p=snap.problem;s,powers=p.parse_schedule(snap.best);assert sum(powers)<=p.budget
    spatial(snap,True,time.perf_counter()+.2)
    prior=path.read_bytes();snap.deadline=time.perf_counter()-1;assert not snap.commit({'status':'LATE'},True);assert prior==path.read_bytes()
    checks.extend(['analytic stationary p=1/lambda-1/g','uniform fallback exact feasibility','late commit preserves valid prior snapshot'])
    out=primary([[0,0]]*24);assert out['conservative95_interval'][0]<0<out['conservative95_interval'][1]
    missing=primary([[0,0]]*23+[[None,0]]);assert not missing['confirmatory_complete']
    checks.extend(['Clopper-Pearson nonzero width at no discordance','NOT_RUN not failure'])
    for file in D.glob('*.py'):compile(file.read_text(encoding='utf-8'),str(file),'exec')
    out=dict(status='PASS',seconds=time.perf_counter()-started,synthetic_only=True,checks=checks,no_new_channel_access=True)
    (D/'NOMINAL_PRECHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

if __name__=='__main__':main()
