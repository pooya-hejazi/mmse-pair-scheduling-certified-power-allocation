"""Serial controller. Requires explicit root-created GO file after independent audit."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import argparse,json,time,subprocess,hashlib,sys
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from global_core import Problem
D=Path(__file__).resolve().parent

def plan():
    rng=np.random.default_rng(20261112);rows=[]
    for i in range(24):
        for m in rng.permutation(['full','reference']):rows.append(dict(panel='B',index=i,method=str(m),charged=20,external=22,levels='1/20,1/10,1/5'))
    for i in range(24):
        for m in rng.permutation(['grid','curvature','slsqp','iwmmse']):rows.append(dict(panel='B',index=i,method=str(m),charged=20,external=22,levels='1/20,1/10,1/5'))
    for i in range(4):
        for levels in ['1/20,1/10,1/5','1/20,3/40,1/10,1/8,3/20,7/40,1/5']:
            rows.append(dict(panel='gridcontrol',index=i,method='grid',charged=29,external=30,levels=levels))
    for i in range(8):
        for m in rng.permutation(['grid_repair','slsqp','iwmmse']):rows.append(dict(panel='scale',index=i,method=str(m),charged=60,external=65,levels='1/20,1/10,1/5'))
    return rows

def atomic(path,obj):
    tmp=path.with_suffix('.tmp')
    with tmp.open('w',encoding='utf-8') as stream:
        stream.write(json.dumps(obj,indent=2)+'\n');stream.flush();os.fsync(stream.fileno())
    os.replace(tmp,path)

def launch(row,casefile,outdir,python):
    name=f"{row['panel']}-{row['index']:02d}-{row['method']}-L{len(row['levels'].split(','))}"
    raw=outdir/(name+'.snapshot.json');final=outdir/(name+'.json')
    attempt_path=outdir/(name+'.attempt.json')
    if raw.exists() or final.exists() or attempt_path.exists():raise RuntimeError('write-once cell already exists')
    began=time.perf_counter();deadline=began+row['charged'];lastseq=0;eligible=None;peak=0;validation_errors=[]
    from nominal_reconcile import persist_immutable,persist_parent_receipt
    persist_immutable(attempt_path,dict(row,cell=name,status='LAUNCH_ATTEMPT',started_perf_counter=began,
                                      scientific_deadline_perf_counter=deadline,case_file=str(casefile),python=python))
    case=json.loads(casefile.read_text(encoding='utf-8'));p=Problem(case)
    cmd=[python,'-B',str(D/'nominal_worker.py'),'--case',str(casefile),'--output',str(raw),'--method',row['method'],
         '--started',str(began),'--deadline',str(deadline),'--levels',row['levels']]
    log=outdir/(name+'.log')
    import psutil
    with log.open('wb') as stream:
        try:
            process=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except OSError as exc:
            result=dict(row,cell=name,status='PROCESS_LAUNCH_ERROR',error=repr(exc),certified_by_deadline=False,eligible_snapshot=None)
            atomic(final,result);return result
        try:proc=psutil.Process(process.pid)
        except psutil.Error:proc=None
        killed=False;reason=None
        while True:
            try:peak=max(peak,proc.memory_info().rss) if proc is not None else peak
            except psutil.Error:pass
            if raw.exists():
                try:
                    candidate=json.loads(raw.read_text(encoding='utf-8'))
                    if candidate['snapshot_sequence']!=lastseq:
                        lastseq=candidate['snapshot_sequence'];s,powers=p.parse_schedule(candidate['schedule']);validlo=p.value(s,powers)[0]
                        assert candidate['interval_valid'] is True
                        assert F(candidate['lower_nats'])<=validlo and F(candidate['upper_nats'])>=F(candidate['lower_nats'])
                        # Persist validated snapshot before scientific deadline, then record observed completion.
                        if time.perf_counter()<deadline:
                            received=persist_parent_receipt(outdir,name,candidate,attempt_path,lastseq)
                            if received is not None:eligible=received
                except Exception as exc:validation_errors.append(repr(exc))
            if process.poll() is not None:break
            if time.perf_counter()-began>=row['external'] or peak>8*1024**3:
                reason='EXTERNAL_WATCHDOG' if peak<=8*1024**3 else 'RAM_LIMIT';process.kill();killed=True;process.wait();break
            time.sleep(.025)
        elapsed=time.perf_counter()-began
    result=dict(row,cell=name,case_sha256=hashlib.sha256(casefile.read_bytes()).hexdigest(),
                status=reason or ('RETURNED' if process.returncode==0 else 'PROCESS_ERROR'),returncode=process.returncode,
                elapsed_parent=elapsed,peak_worker_RSS_bytes=peak,eligible_snapshot=eligible,snapshot_validation_errors=validation_errors,
                certified_by_deadline=bool(eligible and F(eligible['upper_nats'])-F(eligible['lower_nats'])<=F(1,100)),
                raw_snapshot_sha256=hashlib.sha256(raw.read_bytes()).hexdigest() if raw.exists() else None,
                output_scope='global intervals include universal fallback; local completion does not imply global optimality')
    atomic(final,result);return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--go',required=True);ap.add_argument('--inputs',required=True)
    ap.add_argument('--output',required=True);ap.add_argument('--python',default=sys.executable)
    ap.add_argument('--campaign-deadline',type=float,required=True);args=ap.parse_args()
    assert Path(args.go).read_text().strip()=='S04_PREFLIGHT_PASS_ROOT_GO'
    from freeze_guard import verify_frozen
    freeze_hash=verify_frozen()
    out=Path(args.output);out.mkdir(exist_ok=True);root=Path(args.inputs)
    cells=plan();atomic(out/'dispatch-plan.json',cells);atomic(out/'freeze-verified.json',{'input_manifest_sha256':freeze_hash})
    for position,row in enumerate(cells):
        needed=row['external']
        # Primary blocks reserve BOTH cells, preserving their paired opportunity.
        if position<48 and position%2==0:needed=44
        if time.perf_counter()+needed>=args.campaign_deadline:
            name=f"{row['panel']}-{row['index']:02d}-{row['method']}-L{len(row['levels'].split(','))}"
            atomic(out/(name+'.json'),dict(row,status='NOT_RUN_RESOURCE_LIMIT',certified_by_deadline=None));continue
        panel='B' if row['panel']=='gridcontrol' else row['panel']
        launch(row,root/f"{panel}-{row['index']:02d}.json",out,args.python)

if __name__=='__main__':main()
