"""Frozen prospective analysis; no result discovery at import time."""
import argparse,json,math
from pathlib import Path
import numpy as np
from scipy.stats import beta

def cp(k,n,confidence=.975):
    alpha=1-confidence
    return (0. if k==0 else float(beta.ppf(alpha/2,k,n-k+1)),
            1. if k==n else float(beta.ppf(1-alpha/2,k+1,n-k)))

def primary(pairs):
    # Every one of the 24 planned pairs must appear, including NOT_RUN cells.
    assert len(pairs)==24
    complete=[p for p in pairs if p[0] is not None and p[1] is not None]
    missing=len(pairs)-len(complete);n=len(complete)
    table={f'{a}{b}':sum(x==a and y==b for x,y in complete) for a in (0,1) for b in (0,1)}
    score=table['10']-table['01'];low=(score-missing)/24;high=(score+missing)/24
    out=dict(planned=24,observed_pairs=n,administratively_missing_pairs=missing,table_full_generic=table,
             worst_best_completion_difference=[low,high],confirmatory_complete=missing==0)
    if missing:return out
    l10,u10=cp(table['10'],24);l01,u01=cp(table['01'],24)
    rng=np.random.default_rng(20261113);diff=np.array([x-y for x,y in complete],float)
    boot=diff[rng.integers(0,24,size=(10000,24))].mean(axis=1)
    out.update(difference=score/24,conservative95_interval=[l10-u01,u10-l01],
               superiority_demonstrated=l10-u01>0,bootstrap95_descriptive=np.quantile(boot,[.025,.975]).tolist())
    return out

def metrics(case,snapshot):
    lookup={(r['users'][0],r['users'][1],r['resource']):tuple(float(__import__('fractions').Fraction(r[k])) for k in ['gain1','gain2','r']) for r in case['pairs']}
    rates=[0.]*case['K'];power=0.
    for row in snapshot['schedule']:
        u,v=row['users'];a,b,r=lookup[u,v,row['resource']];p,q=map(lambda z:float(__import__('fractions').Fraction(z)),row['powers'])
        x,y=a*p,b*q;d=1+x+y+(1-r)*x*y
        rates[u]=math.log(d/(1+y),2);rates[v]=math.log(d/(1+x),2);power+=p+q
    sq=sum(v*v for v in rates);total=sum(rates)
    return dict(sumSE=total,occupied_bandwidth_normalized_SE=total/case['S'],radiated_W=power,
                minimum_user_SE=min(rates),Jain_fairness=total**2/(case['K']*sq) if sq else None,
                zero_rate_users=sum(v==0 for v in rates),user_SE=rates)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    from nominal_reconcile import ledger,name_of
    root=Path(a.results);pairs=[];failures=[];all_rows=ledger(root)
    by_name={name_of(row):row for row in all_rows}
    for i in range(24):
        values=[]
        for method in ['full','reference']:
            out=by_name[f'B-{i:02d}-{method}-L3']
            values.append(None if out['status'].startswith('NOT_RUN') else int(out['certified_by_deadline']))
            if out['status']!='RETURNED':failures.append(dict(index=i,method=method,status=out['status']))
        pairs.append(values)
    Path(a.output).write_text(json.dumps(dict(primary=primary(pairs),failure_accounting=failures,expected_cells=176,complete_ledger=all_rows),indent=2)+'\n')

if __name__=='__main__':main()
