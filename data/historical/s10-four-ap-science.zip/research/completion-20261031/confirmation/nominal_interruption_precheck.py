"""S04-PF-01 synthetic interruption fixtures only; no channel inputs or optimization."""
import json,time,sys,subprocess
from pathlib import Path
from nominal_campaign import plan,atomic,launch
from nominal_reconcile import name_of,persist_immutable,persist_parent_receipt,classify,reconcile,digest
D=Path(__file__).resolve().parent

def fixture_child(root,mode,row):
    name=name_of(row);start=time.perf_counter();attempt=root/(name+'.attempt.json')
    persist_immutable(attempt,dict(row,cell=name,started_perf_counter=start,scientific_deadline_perf_counter=start+row['charged']))
    if mode=='before-output':__import__('os')._exit(17)
    snapshot={'interval_valid':True,'lower_nats':'0','upper_nats':'0','snapshot_sequence':1,'schedule':[],
              'worker_elapsed':0.001,'certificate_mathematical':True}
    if mode=='timely-receipt':
        persist_parent_receipt(root,name,snapshot,attempt,1)
        # A later unreceipted candidate must never erase the earlier evidence.
        persist_immutable(root/(name+'.eligible-00000002.json'),dict(snapshot,upper_nats='1',snapshot_sequence=2))
    else:
        # Looks successful by a worker clock; absence of parent receipt remains decisive.
        persist_immutable(root/(name+'.snapshot.json'),snapshot)
    __import__('os')._exit(17)

def main():
    if len(sys.argv)>1:
        root=Path(sys.argv[1]);row=json.loads(sys.argv[3]);fixture_child(root,sys.argv[2],row);return
    started=time.perf_counter();root=D/'synthetic-interruption-check';root.mkdir(exist_ok=False)
    rows=plan();selected=[next(r for r in rows if r['panel']=='B' and r['index']==i and r['method']=='full') for i in range(4)]
    names={name_of(r) for r in selected}
    # Other planned records are neutral synthetic completions, making denominators testable.
    for row in rows:
        if name_of(row) not in names:
            persist_immutable(root/(name_of(row)+'.json'),dict(row,status='RETURNED',certified_by_deadline=False,synthetic=True))
    codes=[]
    for mode,row in zip(['before-output','timely-receipt','late-only'],selected):
        z=subprocess.run([sys.executable,'-B',str(Path(__file__)),str(root),mode,json.dumps(row)],timeout=8)
        assert z.returncode==17;codes.append(z.returncode)
    before=[classify(root,row,'SYNTHETIC_FORCED_EXIT') for row in selected]
    assert [r['status'] for r in before]==['INTERRUPTED_DISPATCHED']*3+['NOT_RUN_UNDISPATCHED']
    assert [r['certified_by_deadline'] for r in before]==[False,True,False,None]
    analysis=root/'analysis-before.json'
    subprocess.run([sys.executable,'-B',str(D/'nominal_analysis.py'),'--results',str(root),'--output',str(analysis)],check=True,timeout=8)
    primary=json.loads(analysis.read_text())['primary'];assert primary['administratively_missing_pairs']==1
    retained=root/(name_of(rows[1])+'.json')
    if name_of(rows[1]) in names:retained=next(root.glob('B-*-reference-L3.json'))
    oldhash=digest(retained);result=reconcile(root,'SYNTHETIC_FORCED_EXIT');assert len(result['rows'])==176
    assert digest(retained)==oldhash
    assert [classify(root,row)['certified_by_deadline'] for row in selected]==[False,True,False,None]
    # Spawn failure is also an attempted outcome, even with no worker snapshot.
    spawnroot=root/'spawn-failure';spawnroot.mkdir()
    case=spawnroot/'case.json';case.write_text(json.dumps({'K':2,'S':1,'pmin':'1/20','pmax':'1/5','budget':'1/5',
        'pairs':[{'users':[0,1],'resource':0,'gain1':'0','gain2':'0','r':'0'}]}))
    result_spawn=launch(dict(panel='synthetic',index=0,method='full',charged=4,external=5,levels='1/20,1/10,1/5'),case,spawnroot,'__nonexistent_synthetic_interpreter__.exe')
    assert result_spawn['status']=='PROCESS_LAUNCH_ERROR' and result_spawn['certified_by_deadline'] is False
    assert (spawnroot/'synthetic-00-full-L3.attempt.json').exists()
    out=dict(status='PASS',synthetic_only=True,seconds=time.perf_counter()-started,child_forced_exit_codes=codes,
             cases=[dict(name=name_of(r),status=z['status'],certified=z['certified_by_deadline']) for r,z in zip(selected,before)],
             expected_ledger=176,missing_pairs_before_reconciliation=primary['administratively_missing_pairs'],
             existing_final_sha256_preserved=oldhash,spawn_failure_status=result_spawn['status'],
             no_new_channel_access=True,no_solver_execution=True)
    (D/'NOMINAL_INTERRUPTION_PRECHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

if __name__=='__main__':main()
