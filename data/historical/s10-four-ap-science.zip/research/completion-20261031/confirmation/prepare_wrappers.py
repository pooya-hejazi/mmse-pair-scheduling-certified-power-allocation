"""Prospective one-shot adaptation of frozen development sources; no data reads."""
from pathlib import Path
D=Path(__file__).resolve().parent
p=D/'global_core.py'
s=p.read_text();s=s.replace('g1>0 and g2>0', 'g1>=0 and g2>=0')
s=s.replace("sys.path.insert(0,str(Path(__file__).resolve().parent.parent))", "# Local frozen oracle copy is preferred.")
p.write_text(s,encoding='utf-8')
p=D/'local_core.py';s=p.read_text()
s=s.replace('g1 > 0 and g2 > 0', 'g1 >= 0 and g2 >= 0')
s=s.replace('class Deadline(Exception):', "# Optional campaign callback: persists exact-validated feasible candidates.\nPROGRESS = lambda result: None\nGRID_LEVELS = None\n\nclass Deadline(Exception):")
s=s.replace("return numeric, q", "PROGRESS({'schedule': _schedule_json(best['schedule'], best['p']), 'status': 'LOCAL_PROGRESS'})\n        return numeric, q")
s=s.replace("levels = [v for v in (F(1,20), F(1,10), F(1,5)) if low <= v <= high]", "levels = [v for v in (GRID_LEVELS or (F(1,20), F(1,10), F(1,5))) if low <= v <= high]")
s=s.replace("remaining = max(.001, min(10., seconds-(time.perf_counter()-began)))", "remaining = max(.001, min(4., seconds-(time.perf_counter()-began)))")
s=s.replace("    lp = linprog", "    PROGRESS({'schedule': _schedule_json(best_schedule,best_p), 'status': 'GRID_MILP_PROGRESS'})\n    if time.perf_counter()-began >= seconds:\n        return {'schedule': _schedule_json(best_schedule,best_p), 'status': 'GRID_NO_TIME_FOR_LP'}\n    lp = linprog")
p.write_text(s,encoding='utf-8')
