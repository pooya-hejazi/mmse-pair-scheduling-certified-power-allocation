"""Synthetic process check only, <=8s; never reads a physical channel."""
from pathlib import Path
import json,sys,time
from nominal_campaign import launch
from nominal_precheck import fixture
D=Path(__file__).resolve().parent
out=D/'synthetic-process-check';out.mkdir(exist_ok=True)
case=out/'case.json';case.write_text(json.dumps(fixture('0','0','0')))
result=launch(dict(panel='synthetic',index=0,method='full',charged=4,external=5,levels='1/20,1/10,1/5'),case,out,sys.executable)
assert result['certified_by_deadline']
assert result['eligible_snapshot']['parent_validated_persisted_elapsed']<=4
print(json.dumps({k:result[k] for k in ['status','certified_by_deadline','elapsed_parent','peak_worker_RSS_bytes']}))
