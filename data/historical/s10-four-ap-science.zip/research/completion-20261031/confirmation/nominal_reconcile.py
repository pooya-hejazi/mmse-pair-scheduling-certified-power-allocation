"""Recover planned-cell accounting from durable parent evidence; never run a solver."""
import argparse,json,hashlib,time,os
from fractions import Fraction as F
from pathlib import Path

def name_of(row):return f"{row['panel']}-{row['index']:02d}-{row['method']}-L{len(row['levels'].split(','))}"
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def persist_immutable(path,obj):
    """Unique parent-owned file, durable before return, never replaces existing evidence."""
    path=Path(path)
    if path.exists():raise FileExistsError(path)
    payload=(json.dumps(obj,indent=2)+'\n').encode('utf-8')
    # Unique names and serial parent ownership avoid inter-writer replacement races.
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('xb') as stream:stream.write(payload);stream.flush();os.fsync(stream.fileno())
    if path.exists():raise FileExistsError(path)
    os.replace(tmp,path)
    return hashlib.sha256(payload).hexdigest()

def persist_parent_receipt(root,name,candidate,attempt_path,sequence):
    """Call only AFTER parent feasibility/interval validation.

    Candidate persistence completes first; parent samples its own clock afterwards.
    A receipt may finish later, but it reports the actual earlier parent completion.
    Missing/incomplete receipt is deliberately not recoverable as certification.
    """
    root=Path(root);attempt=json.loads(Path(attempt_path).read_text(encoding='utf-8'))
    candidate_path=root/f'{name}.eligible-{sequence:08d}.json'
    candidate_hash=persist_immutable(candidate_path,candidate)
    completed=time.perf_counter()
    if completed>attempt['scientific_deadline_perf_counter']:return None
    receipt=dict(schema='S04_PARENT_ELIGIBILITY_V1',cell=name,candidate_file=candidate_path.name,
                 candidate_sha256=candidate_hash,attempt_file=Path(attempt_path).name,attempt_sha256=digest(attempt_path),
                 parent_validated_persisted_perf_counter=completed,
                 parent_validated_persisted_elapsed=completed-attempt['started_perf_counter'],
                 scientific_deadline_perf_counter=attempt['scientific_deadline_perf_counter'],
                 validation='parent exact feasibility and lower interval checked before candidate persistence')
    receipt_path=root/f'{name}.receipt-{sequence:08d}.json';persist_immutable(receipt_path,receipt)
    return dict(candidate,parent_validated_persisted_elapsed=receipt['parent_validated_persisted_elapsed'],
                parent_receipt_file=receipt_path.name,parent_receipt_sha256=digest(receipt_path))

def read_eligible(root,name):
    """Require intact attempt, receipt, candidate hashes and parent clock evidence."""
    root=Path(root);attempt_path=root/(name+'.attempt.json');errors=[];valid=[]
    if not attempt_path.exists():return None,errors
    try:
        attempt=json.loads(attempt_path.read_text(encoding='utf-8'));assert attempt['cell']==name
    except Exception as exc:return None,[repr(exc)]
    for path in sorted(root.glob(name+'.receipt-*.json')):
        try:
            receipt=json.loads(path.read_text(encoding='utf-8'))
            assert receipt['schema']=='S04_PARENT_ELIGIBILITY_V1' and receipt['cell']==name
            assert receipt['attempt_file']==attempt_path.name and receipt['attempt_sha256']==digest(attempt_path)
            candidate_name=receipt['candidate_file'];assert Path(candidate_name).name==candidate_name
            assert candidate_name.startswith(name+'.eligible-') and candidate_name.endswith('.json')
            candidate_path=root/candidate_name;assert digest(candidate_path)==receipt['candidate_sha256']
            completion=receipt['parent_validated_persisted_perf_counter']
            start=attempt['started_perf_counter'];deadline=attempt['scientific_deadline_perf_counter']
            assert deadline==receipt['scientific_deadline_perf_counter'] and start<=completion<=deadline
            assert receipt['parent_validated_persisted_elapsed']==completion-start
            assert deadline-start<=float(attempt['charged'])+1e-6
            candidate=json.loads(candidate_path.read_text(encoding='utf-8'))
            assert candidate['interval_valid'] is True and F(candidate['lower_nats'])<=F(candidate['upper_nats'])
            valid.append(dict(candidate,parent_validated_persisted_elapsed=completion-start,
                              parent_receipt_file=path.name,parent_receipt_sha256=digest(path)))
        except Exception as exc:errors.append(dict(file=path.name,error=repr(exc)))
    return (min(valid,key=lambda row:F(row['upper_nats'])-F(row['lower_nats'])) if valid else None),errors

def classify(root,row,reason='CONTROLLER_INTERRUPTED_OR_FINAL_RECORD_ABSENT'):
    root=Path(root);name=name_of(row);final=root/(name+'.json')
    if final.exists():return json.loads(final.read_text(encoding='utf-8'))
    artifacts=[p for p in root.glob(name+'.*') if p.is_file() and
               any(tag in p.name for tag in ('.attempt.', '.log', '.snapshot.', '.eligible', '.receipt-'))]
    attempted=bool(artifacts)
    eligible,errors=read_eligible(root,name)
    return dict(row,cell=name,status='INTERRUPTED_DISPATCHED' if attempted else 'NOT_RUN_UNDISPATCHED',
                interruption_reason=reason,attempted=attempted,
                dispatch_evidence=[p.name for p in sorted(artifacts)],eligible_snapshot=eligible,
                receipt_validation_errors=errors,
                certified_by_deadline=bool(eligible and F(eligible['upper_nats'])-F(eligible['lower_nats'])<=F(1,100)) if attempted else None,
                recovery_rule='only intact parent receipt establishes deadline eligibility; worker times never used')

def ledger(root,reason='CONTROLLER_INTERRUPTED_OR_FINAL_RECORD_ABSENT'):
    from nominal_campaign import plan
    rows=plan();assert len(rows)==176
    return [classify(root,row,reason) for row in rows]

def reconcile(results,reason='CONTROLLER_INTERRUPTED_OR_FINAL_RECORD_ABSENT'):
    from nominal_campaign import atomic
    root=Path(results);root.mkdir(parents=True,exist_ok=True)
    rows=ledger(root,reason)
    for out in rows:
        path=root/(name_of(out)+'.json')
        if not path.exists():persist_immutable(path,out)
    summary=dict(expected_cells=176,rows=rows,reason=reason,
                 interrupted_dispatched=sum(r['status']=='INTERRUPTED_DISPATCHED' for r in rows),
                 undispatched=sum(r['status'].startswith('NOT_RUN') for r in rows))
    atomic(root/'reconciled-ledger.json',summary);return summary

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--results',required=True)
    parser.add_argument('--reason',default='CONTROLLER_INTERRUPTED_OR_FINAL_RECORD_ABSENT');args=parser.parse_args()
    result=reconcile(args.results,args.reason)
    print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
