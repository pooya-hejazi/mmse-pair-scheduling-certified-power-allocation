"""PROSPECTIVE generation ONLY after independent preflight and explicit root GO.
Run with parent's <=600 s watchdog. One shared B/scale generation; no retries.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import argparse,json,time,hashlib
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import numpy as np
D=Path(__file__).resolve().parent;ROOT=D.parents[2]

def convert(h,name,ids,resources,rawhash):
    K,M,S=h.shape;vectors={};g={};rows=[]
    for u in range(K):
        for s in range(S):
            vectors[u,s]=[(F(float(z.real)),F(float(z.imag))) for z in h[u,:,s]]
            g[u,s]=sum(a*a+b*b for a,b in vectors[u,s])
    for u,v in combinations(range(K),2):
        for s in range(S):
            re=sum(a*c+b*d for (a,b),(c,d) in zip(vectors[u,s],vectors[v,s]))
            im=sum(a*d-b*c for (a,b),(c,d) in zip(vectors[u,s],vectors[v,s]))
            r=(re*re+im*im)/(g[u,s]*g[v,s]) if g[u,s]*g[v,s] else F(0)
            rows.append(dict(users=[u,v],resource=s,gain1=str(g[u,s]),gain2=str(g[v,s]),r=str(r)))
    return dict(name=name,K=K,S=S,M=M,pmin='1/20',pmax='1/5',budget=str(F(K,10)),pairs=rows,
                input_sha256=rawhash,user_indices=ids.tolist(),resources=resources,
                scope='conditional draws on one fixed map; ideal coherent perfect-CSI physical model')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--go',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--prior-coordinates',required=True);ap.add_argument('--panel-a-coordinates',required=True);a=ap.parse_args()
    assert Path(a.go).read_text().strip()=='S04_PREFLIGHT_PASS_ROOT_GO'
    from freeze_guard import verify_frozen
    freeze_hash=verify_frozen()
    dest=Path(a.output);assert not dest.exists();dest.mkdir(parents=True)
    # Source integrity verifies existing manifest; no model or channel fitting.
    sources=json.loads((ROOT/'research/reproduction/data-source.json').read_text())
    for row in sources:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
    import DeepMIMOv3 as dm
    p=dm.default_params();p['dataset_folder']=str(ROOT/'DeepMIMO_sena');p['scenario']='O1_60'
    p['active_BS']=np.arange(1,5);p['num_paths']=10;p['user_rows']=np.arange(201,301);p['enable_BS2BS']=0
    p['bs_antenna']['shape']=np.array([1,8,1]);p['ue_antenna']['shape']=np.array([1,1,1])
    p['OFDM']['bandwidth']=.05;p['OFDM']['subcarriers']=32;p['OFDM']['selected_subcarriers']=np.arange(32)
    started=time.perf_counter();data=dm.generate_data(p)
    H=np.stack([v['user']['channel'][:,0,:,:] for v in data],axis=1);loc=data[0]['user']['location']
    assert H.shape[1:]==(4,8,32) and np.isfinite(H).all()
    assert all(np.array_equal(loc,v['user']['location']) for v in data)
    now=set(map(tuple,loc.tolist()))
    for path in (a.prior_coordinates,a.panel_a_coordinates):
        old=np.load(path);coordinates=old['location'] if isinstance(old,np.lib.npyio.NpzFile) else old
        assert not now.intersection(map(tuple,coordinates.tolist())), 'coordinate overlap: stop, no resampling'
    np.savez_compressed(dest/'channels32.npz',H=H,location=loc)
    rawhash=hashlib.sha256((dest/'channels32.npz').read_bytes()).hexdigest()
    noise=10**((-174+7-30)/10)*(50e6/32);manifest=[]
    for panel,N,K,seed,resources in [('B',24,8,20261111,[0,8,16,24]),('scale',8,16,20261114,list(range(0,32,4)))]:
        rng=np.random.default_rng(seed)
        for i in range(N):
            ids=rng.choice(len(H),K,replace=False)
            h=(np.sqrt(32)*H[ids]).reshape(K,32,32)[:,:,resources]/np.sqrt(noise)
            name=f'{panel}-{i:02d}';case=convert(h,name,ids,resources,rawhash)
            path=dest/(name+'.json');path.write_text(json.dumps(case,indent=2)+'\n',encoding='utf-8')
            np.savez_compressed(dest/(name+'.npz'),h=h,location=loc[ids],indices=ids)
            manifest.append(dict(name=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),indices=ids.tolist()))
    src=Path(dm.__file__).parent
    out=dict(parameters=p,shape=H.shape,seconds=time.perf_counter()-started,sha256=rawhash,noise_W=noise,cases=manifest,input_manifest_sha256=freeze_hash,
             generator_source_hashes={n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in ['construct_deepmimo.py','raytracing_v2.py','utils.py']},
             coordinate_disjointness=True,scope='new reserved rows201..300; no rejection of weak or zero channels')
    (dest/'generation.json').write_text(json.dumps(out,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x),indent=2))

if __name__=='__main__':main()
