"""Disclosed post-hoc sensitivity; never substitutes for frozen primary inference."""
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D/'confirmation'))
from nominal_analysis import primary
from nominal_reconcile import ledger

def main():
    rows=ledger(D/'confirmation/run-01-results')
    lookup={(r['panel'],r['index'],r['method']):r for r in rows if r['panel']!='gridcontrol'}
    pairs=[]
    for i in range(24):
        pair=[]
        for method in ['full','reference']:
            r=lookup['B',i,method]
            pair.append(None if r['status'].startswith('NOT_RUN') else int(r['certified_by_deadline'] is True and r['status']=='RETURNED'))
        pairs.append(pair)
    groups={}
    for r in rows:
        key=r['panel']+'_'+r['method']
        cross=groups.setdefault(key,{})
        category=r['status']+' / certificate='+str(r['certified_by_deadline'])
        cross[category]=cross.get(category,0)+1
    out=dict(label='POST_HOC_NORMAL_PROCESS_RETURN_SENSITIVITY',
             exact_rule="certified_by_deadline is True AND status == 'RETURNED'",
             interpretation='secondary diagnostic prompted by disclosed wording conflict; frozen primary remains unchanged',
             paired_sensitivity=primary(pairs),status_certificate_cross_tables=groups)
    dest=D/'campaign-run/strict-return-sensitivity.json'
    with dest.open('x',encoding='utf-8') as stream:json.dump(out,stream,indent=2)
    print(json.dumps(out['paired_sensitivity'],indent=2))

if __name__=='__main__':main()
