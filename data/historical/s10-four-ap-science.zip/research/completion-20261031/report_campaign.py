"""Descriptive tables and figures from the single frozen S04 campaign.

No solver, training, channel generation, parameter selection, or new hypothesis test.
Primary inference comes verbatim from the predeclared nominal_analysis function.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse, csv, hashlib, importlib.util, json, math, sys, time
import numpy as np

D=Path(__file__).resolve().parent
sys.path.insert(0,str(D/'confirmation'))
from nominal_analysis import primary, metrics
from nominal_reconcile import ledger

def quantiles(values):
    a=np.asarray([v for v in values if v is not None],float)
    if not len(a): return dict(N=0)
    return dict(N=len(a),mean=float(a.mean()),median=float(np.median(a)),
                q25=float(np.quantile(a,.25)),q75=float(np.quantile(a,.75)),
                minimum=float(a.min()),maximum=float(a.max()))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
    args=parser.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    started=time.perf_counter();results=D/'confirmation/run-01-results';inputs=D/'confirmation/run-01-inputs'
    raw=ledger(results);rows=[];provenance={}
    for item in raw:
        row={key:item.get(key) for key in ['panel','index','method','levels','cell','status','charged','external','elapsed_parent','peak_worker_RSS_bytes','certified_by_deadline']}
        row['worker_status']=None;row['eligible']=False
        for key in ['lower_nats','upper_nats','gap_nats','relative_gap','sumSE','radiated_W','minimum_user_SE','Jain_fairness','zero_rate_users','pricing_rows','pricing_total','assignments_visited','assignments_bound','nodes','eligible_elapsed','grid_IP_nats','grid_LP_nats','grid_IP_status','grid_LP_status']:
            row[key]=None
        snapshot=item.get('eligible_snapshot')
        if snapshot:
            row['eligible']=True;lo=F(snapshot['lower_nats']);hi=F(snapshot['upper_nats'])
            assert hi>=lo
            row.update(lower_nats=float(lo),upper_nats=float(hi),gap_nats=float(hi-lo),
                       relative_gap=float((hi-lo)/lo) if lo>0 else None,
                       eligible_elapsed=snapshot['parent_validated_persisted_elapsed'],
                       worker_status=snapshot.get('status'),pricing_rows=snapshot.get('priced_pairs'),
                       pricing_total=snapshot.get('total_pairs'),assignments_visited=snapshot.get('assignments_visited'),
                       assignments_bound=snapshot.get('assignments_bound'),nodes=snapshot.get('nodes'))
            assert row['eligible_elapsed']<=row['charged']
            casefile=inputs/f"{'B' if row['panel']=='gridcontrol' else row['panel']}-{row['index']:02d}.json"
            case=json.loads(casefile.read_text());row.update({k:v for k,v in metrics(case,snapshot).items() if k!='user_SE'})
            assert abs(row['sumSE']-row['lower_nats']/math.log(2))<1e-7
            grid=snapshot.get('grid_result',{})
            row.update(grid_IP_nats=grid.get('numerical_MILP_nats'),grid_LP_nats=grid.get('numerical_LP_nats'),
                       grid_IP_status=grid.get('MILP_status'),grid_LP_status=grid.get('LP_status'))
            provenance[str(casefile.relative_to(D))]=hashlib.sha256(casefile.read_bytes()).hexdigest()
        rows.append(row)
    keys=sorted(set().union(*(r.keys() for r in rows)))
    with (out/'all-cells.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=keys);writer.writeheader();writer.writerows(rows)
    lookup={(r['panel'],r['index'],r['method']):r for r in rows if r['panel']!='gridcontrol'}
    pairs=[]
    for i in range(24):
        pair=[]
        for method in ['full','reference']:
            r=lookup['B',i,method]
            pair.append(None if r['status'].startswith('NOT_RUN') else int(r['certified_by_deadline']))
        pairs.append(pair)
    summary=dict(primary=primary(pairs),groups={},paired_gap_diagnostic={},
                 scope='conditional on one fixed O1_60 scene; all secondary summaries descriptive',
                 exclusions='No new hypothesis test or post-outcome method selection')
    for panel in ['B','scale','gridcontrol']:
        identifiers=sorted(set((r['method'],len(r['levels'].split(',')) if panel=='gridcontrol' else 0) for r in rows if r['panel']==panel))
        for method,levels in identifiers:
            group=[r for r in rows if r['panel']==panel and r['method']==method and (not levels or len(r['levels'].split(','))==levels)]
            entry=dict(planned=len(group),eligible=sum(r['eligible'] for r in group),
                       certified=sum(r['certified_by_deadline'] is True for r in group),
                       undispatched=sum(r['status'].startswith('NOT_RUN') for r in group),
                       worker_errors=sum(r['worker_status']=='ERROR_FALLBACK_RETAINED' for r in group))
            for key in ['gap_nats','relative_gap','sumSE','minimum_user_SE','radiated_W','Jain_fairness','elapsed_parent','peak_worker_RSS_bytes']:
                entry[key]=quantiles([r[key] for r in group])
            summary['groups'][panel+'_'+method+('_L'+str(levels) if levels else '')]=entry
    for method in ['reference','curvature','grid','slsqp','iwmmse']:
        paired=[(lookup['B',i,'full'],lookup['B',i,method]) for i in range(24)]
        complete=[(a,b) for a,b in paired if a['eligible'] and b['eligible']]
        summary['paired_gap_diagnostic'][method]=dict(eligible_pairs=len(complete),planned=24,
            gap_full_minus_comparator=quantiles([a['gap_nats']-b['gap_nats'] for a,b in complete]),
            sumSE_full_minus_comparator=quantiles([a['sumSE']-b['sumSE'] for a,b in complete]),
            interpretation='selected valid-interval subset, descriptive; gaps bound regret, not measured regret')
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    (out/'all-cells.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(7.0,2.7),layout='constrained')
    methods=['reference','curvature','full'];labels=['Generic','Curvature','Full']
    success=[summary['groups']['B_'+m]['certified'] for m in methods]
    axes[0].bar(labels,success,color=['#7b8794','#2a8c9b','#2856a3'])
    axes[0].set(ylim=(0,24),ylabel='Certified networks / 24',title='Gap at most 0.01 nat by 20 s')
    for i,n in enumerate(success):axes[0].text(i,n+.35,str(n),ha='center')
    for m,label,style in zip(methods,labels,['o','s','^']):
        rr=[lookup['B',i,m] for i in range(24)];valid=[r for r in rr if r['eligible']]
        axes[1].scatter([r['index']+1 for r in valid],[max(r['gap_nats'],1e-12) for r in valid],s=18,label=label,marker=style,alpha=.85)
    axes[1].axhline(.01,color='black',linestyle='--',linewidth=.8)
    axes[1].set(yscale='log',xlabel='Prespecified network index',ylabel='Valid global gap (nat)',title='All timely eligible intervals')
    axes[1].legend(fontsize=7)
    fig.savefig(out/'certification.pdf');fig.savefig(out/'certification.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.7,2.5),layout='constrained')
    for m,label,style in [('grid_repair','Grid + complete pricing','o'),('slsqp','SLSQP','s'),('iwmmse','Adapted I-WMMSE','^')]:
        rr=[lookup['scale',i,m] for i in range(8)];valid=[r for r in rr if r['eligible'] and r['relative_gap'] is not None]
        ax.scatter([r['index']+1 for r in valid],[max(100*r['relative_gap'],1e-10) for r in valid],label=label,marker=style)
    ax.axhline(1,color='black',linestyle='--',linewidth=.8)
    ax.set(yscale='log',xlabel='Prespecified K=16 network index',ylabel='Valid relative gap (%)')
    ax.legend(fontsize=8);fig.savefig(out/'scale-gaps.pdf');fig.savefig(out/'scale-gaps.png',dpi=180);plt.close(fig)
    provenance['seconds']=time.perf_counter()-started
    provenance['reporter_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (out/'provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    print(json.dumps(summary['primary'],indent=2))

if __name__=='__main__':main()
