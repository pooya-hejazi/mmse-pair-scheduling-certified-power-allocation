"""One prospective campaign; run only after independent frozen-code preflight.

Uses separate absolute clock domains: forward CSI monotonic, nominal perf_counter.
Run with existing base Anaconda Python (psutil available). No retries or overwrites.
"""
import argparse, hashlib, json, os, subprocess, sys, time
from pathlib import Path
import psutil

D = Path(__file__).resolve().parent
ROOT = D.parents[1]
PY = Path('C:/ProgramData/anaconda3/envs/6g_project/python.exe')
NOMINAL_PY = Path('C:/ProgramData/anaconda3/python.exe')

def save(path, obj):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(obj, stream, indent=2)

def size(paths):
    return sum(p.stat().st_size for root in paths if root.exists()
               for p in root.rglob('*') if p.is_file())

def terminate_owned(process):
    try:
        owned = psutil.Process(process.pid)
        descendants = owned.children(recursive=True)
    except psutil.Error:
        descendants = []
    for child in reversed(descendants):
        try: child.kill()
        except psutil.Error: pass
    if process.poll() is None:
        process.kill()
    process.wait()

def guarded(name, cmd, cap, deadline, record, outputs, accounting=False):
    started = time.perf_counter()
    allowance = max(0., min(cap, deadline-started))
    if allowance <= 0:
        result = dict(status='NOT_RUN_RESOURCE_LIMIT', command=cmd)
        save(record/(name+'.json'), result)
        return result
    peak = 0; reason = None; last_disk = 0.
    with (record/(name+'.log')).open('xb') as log:
        process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        while process.poll() is None:
            now = time.perf_counter()
            try:
                own = psutil.Process(process.pid)
                members = [own]+own.children(recursive=True)
                rss = sum(member.memory_info().rss for member in members if member.is_running())
                peak = max(peak, rss)
            except psutil.Error:
                rss = 0
            if now-started >= allowance: reason = 'EXTERNAL_WATCHDOG'
            elif rss > 8*1024**3: reason = 'RAM_LIMIT'
            if now-last_disk >= 5 and not accounting:
                # Reserve 16 MiB of the total output allowance for recovery ledgers.
                if size(outputs) > 1024**3-16*1024**2: reason = 'OUTPUT_LIMIT'
                last_disk = now
            if reason:
                terminate_owned(process)
                break
            time.sleep(.1)
        elapsed = time.perf_counter()-started
    result = dict(status=reason or ('RETURNED' if process.returncode==0 else 'PROCESS_ERROR'),
                  command=cmd, returncode=process.returncode, seconds=elapsed,
                  allowance_seconds=allowance, peak_tree_RSS_bytes=peak)
    save(record/(name+'.json'), result)
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--approval', required=True)
    ap.add_argument('--source-manifest', required=True)
    args=ap.parse_args()
    # Root supplies an actual independent-review record; this entry point does not self-approve.
    approval=Path(args.approval).resolve()
    if not approval.is_file(): raise ValueError('Missing independent review record')
    manifest=json.loads(Path(args.source_manifest).read_text(encoding='utf-8'))
    for name,digest in manifest['files'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Source drift: '+name)
    record=D/'campaign-run';record.mkdir(exist_ok=False)
    csi=D/'csi-forward'/'run-01'
    inputs=D/'confirmation'/'run-01-inputs'
    results=D/'confirmation'/'run-01-results'
    if any(p.exists() for p in (csi,inputs,results)): raise FileExistsError('Prior campaign output')
    outputs=[record,csi,inputs,results]
    start=time.perf_counter();deadline=start+7200
    # Python3.9 Windows monotonic may use a different origin from Python3.12.
    # Read the child interpreter's clock explicitly; nominal uses shared Windows QPC.
    child_clock=float(subprocess.check_output([str(PY),'-c','import time; print(time.monotonic())'],text=True))
    csi_deadline=child_clock+max(0.,deadline-time.perf_counter())
    save(record/'lock.json',dict(approval=str(approval), approval_sha256=hashlib.sha256(approval.read_bytes()).hexdigest(),
         start_perf=start, deadline_perf=deadline, deadline_monotonic=csi_deadline,
         policy='one invocation; no retry; all missing and failed cells retained',source_manifest=manifest))
    go=record/'GO.txt';go.write_text('S04_PREFLIGHT_PASS_ROOT_GO',encoding='utf-8')
    csi_result=guarded('panel-a',[str(PY),'-B',str(D/'csi-forward'/'forward.py'),'run',
        '--frozen',str(D/'csi-forward'/'preflight-repair'),'--output',str(csi),
        '--approve-after-independent-preflight',str(approval),'--deadline',str(csi_deadline)],
        1230,deadline,record,outputs)
    csi_status='COMPLETE' if csi_result['status']=='RETURNED' else 'OUTER_INTERRUPTED'
    guarded('panel-a-accounting',[str(PY),'-B',str(D/'csi-forward'/'forward.py'),'reconcile',
        '--output',str(csi),'--reconcile-output',str(csi/'outer-reconciliation'),
        '--outer-status',csi_status,'--outer-reason',csi_result['status']],
        30,deadline,record,outputs,accounting=True)
    nominal_reason='NOT_RUN_PANEL_A_COORDINATES_UNAVAILABLE'
    if (csi/'channels.npz').exists():
        generated=guarded('panel-b-generation',[str(PY),'-B',str(D/'confirmation'/'nominal_generate.py'),
            '--go',str(go),'--output',str(inputs),'--prior-coordinates',str(ROOT/'research/reproduction/channels.npz'),
            '--panel-a-coordinates',str(csi/'channels.npz')],600,deadline,record,outputs)
        if generated['status']=='RETURNED' and (inputs/'generation.json').exists():
            nominal_result=guarded('panel-b',[str(NOMINAL_PY),'-B',str(D/'confirmation'/'nominal_campaign.py'),
                '--go',str(go),'--inputs',str(inputs),'--output',str(results),'--python',str(NOMINAL_PY),
                '--campaign-deadline',str(deadline-120)],7200,deadline-90,record,outputs)
            nominal_reason=nominal_result['status']
        else:
            nominal_reason='NOT_RUN_GENERATION_FAILURE'
            save(record/'panel-b-not-run.json',dict(status='NOT_RUN_GENERATION_FAILURE'))
    else:
        save(record/'panel-b-not-run.json',dict(status='NOT_RUN_PANEL_A_COORDINATES_UNAVAILABLE'))
    guarded('panel-b-accounting',[str(NOMINAL_PY),'-B',str(D/'confirmation'/'nominal_reconcile.py'),
        '--results',str(results),'--reason',nominal_reason],30,deadline,record,outputs,accounting=True)
    guarded('primary-analysis',[str(NOMINAL_PY),'-B',str(D/'confirmation'/'nominal_analysis.py'),
        '--results',str(results),'--output',str(record/'primary-analysis.json')],30,deadline,record,outputs,accounting=True)
    save(record/'complete.json',dict(seconds=time.perf_counter()-start,outputs_bytes=size(outputs),
         scope='execution accounting only, not independent scientific acceptance'))

if __name__=='__main__': main()
