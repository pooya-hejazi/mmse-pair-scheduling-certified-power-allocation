"""Read-only, portable S04 saved-artifact verification; no campaign imports/solvers.

Only this invocation's new --output JSON is written. NumPy is imported lazily for
small saved case NPZs. Saved global upper bounds are NOT independently reproved.
"""
import argparse,hashlib,json,math,sys,time
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext,ROUND_FLOOR,ROUND_CEILING
from itertools import combinations

class BudgetExceeded(Exception):pass
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def require(test,message):
    if not test:raise ValueError(message)
def safe_child(root,name):
    require(isinstance(name,str) and Path(name).name==name,'nonlocal evidence filename')
    return root/name
def log_interval(z):
    z=F(z);require(z>0,'nonpositive logarithm')
    if z==1:return F(0),F(0)
    with localcontext() as c:
        c.prec=60;c.rounding=ROUND_FLOOR;lo=Decimal(z.numerator)/Decimal(z.denominator)
        c.rounding=ROUND_CEILING;hi=Decimal(z.numerator)/Decimal(z.denominator)
        return F(Decimal(0) if lo==1 else lo.ln().next_minus()),F(Decimal(0) if hi==1 else hi.ln().next_plus())
def expected_cells():
    out=[]
    for i in range(24):
        for method in ['full','reference','grid','curvature','slsqp','iwmmse']:
            out.append(('B',i,method,3,20))
    for i in range(4):
        for levels in [3,7]:out.append(('gridcontrol',i,'grid',levels,29))
    for i in range(8):
        for method in ['grid_repair','slsqp','iwmmse']:out.append(('scale',i,method,3,60))
    return out
def cell_name(row):
    panel,i,method,levels,_=row;return f'{panel}-{i:02d}-{method}-L{levels}'

def validate_case(case,name):
    K=8 if name.startswith('B-') else 16;S=K//2
    require((case['K'],case['S'],case['M'])==(K,S,32),'case dimensions')
    low,high,budget=map(F,[case['pmin'],case['pmax'],case['budget']])
    require((low,high,budget)==(F(1,20),F(1,5),F(K,10)),'case registered power domain')
    expected={(u,v,s) for u,v in combinations(range(K),2) for s in range(S)};data={};gains={}
    for row in case['pairs']:
        u,v=row['users'];s=row['resource'];key=(u,v,s)
        require(key in expected and key not in data,'pair incidence or duplicate')
        a,b,r=map(F,[row['gain1'],row['gain2'],row['r']])
        require(a>=0 and b>=0 and 0<=r<=1,'channel rational domain')
        require((a>0 and b>0) or r==0,'zero-gain r convention')
        for i,g in [(u,a),(v,b)]:
            require((i,s) not in gains or gains[i,s]==g,'inconsistent user/resource gain')
            gains[i,s]=g
        data[key]=(a,b,r)
    require(set(data)==expected,'incomplete pair family')
    ceiling=sum(max(log_interval(1+gains[i,s]*high)[1] for s in range(S)) for i in range(K))
    return dict(case=case,data=data,gains=gains,ceiling=ceiling,low=low,high=high,budget=budget)

def schedule_check(info,snapshot):
    case=info['case'];K,S=case['K'],case['S'];users=set();resources=set();powers=[];lower=upper=F(0)
    require(len(snapshot['schedule'])==S,'schedule length')
    for row in snapshot['schedule']:
        u,v=row['users'];s=row['resource'];p,q=map(F,row['powers'])
        require(0<=u<v<K and 0<=s<S,'schedule labelled incidence')
        require(u not in users and v not in users and s not in resources,'duplicate schedule incidence')
        users.update([u,v]);resources.add(s);powers.extend([p,q])
        require(info['low']<=p<=info['high'] and info['low']<=q<=info['high'],'power box')
        a,b,r=info['data'][u,v,s];x,y=a*p,b*q;d=1+x+y+(1-r)*x*y
        dl,du=log_interval(d);xl,xu=log_interval(1+x);yl,yu=log_interval(1+y)
        lower+=2*dl-xu-yu;upper+=2*du-xl-yl
    require(users==set(range(K)) and resources==set(range(S)),'complete schedule incidence')
    require(sum(powers)<=info['budget'],'exact sum-power feasibility')
    saved_l,saved_u=F(snapshot['lower_nats']),F(snapshot['upper_nats'])
    require(snapshot['interval_valid'] is True and saved_l<=saved_u,'saved interval ordering')
    require(saved_l<=lower,'saved incumbent lower exceeds reproduced outward lower')
    require(saved_u>=lower,'saved global upper below feasible objective lower')
    require(saved_u<=info['ceiling'],'saved upper exceeds universal bound used by implementation')
    result=dict(power_W=str(sum(powers)),recomputed_objective_lower=str(lower),recomputed_objective_upper=str(upper),
                saved_lower_exact_reproduction=saved_l==lower,upper_checked='necessary consistency and universal ceiling only')
    rows=snapshot.get('pricing_rows',[]);keys=[]
    for row in rows:
        key=(*row['users'],row['resource']);require(key in info['data'],'pricing key outside family')
        require(F(row['lower'])<=F(row['upper']),'pricing interval ordering');keys.append(key)
    require(len(keys)==len(set(keys)),'duplicate pricing rows')
    if 'priced_pairs' in snapshot:require(snapshot['priced_pairs']==len(rows),'pricing row count')
    if 'total_pairs' in snapshot:require(snapshot['total_pairs']==len(info['data']),'pricing family count')
    result['pricing_rows_structurally_checked']=len(rows)
    if snapshot.get('pricing_complete'):
        require(set(keys)==set(info['data']),'claimed complete pricing omits rows')
        alpha=list(map(F,snapshot['alpha']));lam=F(snapshot['lambda_value'])
        require(len(alpha)==K and lam>=0,'dual coefficient dimensions/sign')
        beta=[max(F(row['upper'])-alpha[row['users'][0]]-alpha[row['users'][1]] for row in rows if row['resource']==s) for s in range(S)]
        require(beta==list(map(F,snapshot['beta'])),'saved repaired beta aggregation')
        aggregate=sum(alpha)+sum(beta)+lam*info['budget']
        require(saved_u<=aggregate,'saved upper exceeds complete repaired bound intersection')
        result['repaired_dual_aggregate']=str(aggregate)
        result['pricing_root_enclosures_reproved']=False
    if 'assignments_bound' in snapshot:
        total=math.factorial(K)//2**S
        require(snapshot['assignments_total']==total and 0<=snapshot['assignments_bound']<=total,'spatial coverage count')
        if snapshot.get('complete_assignment_coverage'):require(snapshot['assignments_bound']==total,'false complete spatial coverage count')
    return result

def receipt_check(results,name,row,snapshot):
    receipt_path=safe_child(results,snapshot['parent_receipt_file'])
    require(sha(receipt_path)==snapshot['parent_receipt_sha256'],'nominated receipt hash')
    receipt=read(receipt_path)
    require(receipt['schema']=='S04_PARENT_ELIGIBILITY_V1' and receipt['cell']==name,'receipt identity')
    attempt_path=safe_child(results,receipt['attempt_file']);candidate_path=safe_child(results,receipt['candidate_file'])
    require(attempt_path.name==name+'.attempt.json','attempt filename binding')
    require(candidate_path.name.startswith(name+'.eligible-'),'candidate filename binding')
    require(sha(attempt_path)==receipt['attempt_sha256'],'attempt hash binding')
    require(sha(candidate_path)==receipt['candidate_sha256'],'candidate hash binding')
    attempt=read(attempt_path);candidate=read(candidate_path)
    require(attempt['cell']==name and attempt['charged']==row[4],'attempt cell/deadline budget')
    start=attempt['started_perf_counter'];deadline=attempt['scientific_deadline_perf_counter'];completed=receipt['parent_validated_persisted_perf_counter']
    require(all(math.isfinite(z) for z in [start,deadline,completed]),'nonfinite parent clock')
    require(start<=completed<=deadline==receipt['scientific_deadline_perf_counter'],'actual parent deadline inequality')
    require(abs(deadline-start-row[4])<=1e-6,'attempt charged interval')
    elapsed=completed-start
    require(elapsed==receipt['parent_validated_persisted_elapsed']==snapshot['parent_validated_persisted_elapsed'],'parent elapsed binding')
    normalized={k:v for k,v in snapshot.items() if k not in ['parent_receipt_file','parent_receipt_sha256','parent_validated_persisted_elapsed']}
    require(normalized==candidate,'final eligible candidate differs from receipted immutable payload')
    return dict(receipt=receipt_path.name,receipt_sha256=sha(receipt_path),parent_elapsed=elapsed,deadline_qualified=True,
                worker_timestamp_used=False)

def geometry_check(np,path,info,guard):
    with np.load(path,allow_pickle=False) as archive:
        h=archive['h'];ids=archive['indices'];location=archive['location']
    case=info['case'];K,M,S=h.shape
    require((K,M,S)==(case['K'],32,case['S']) and np.isfinite(h).all(),'NPZ channel shape/finiteness')
    require(ids.tolist()==case['user_indices'] and len(set(ids.tolist()))==K,'NPZ selected user indices')
    require(location.shape[0]==K and np.isfinite(location).all(),'NPZ coordinates')
    vectors={};g={}
    for u in range(K):
        for s in range(S):
            vectors[u,s]=[(F(float(z.real)),F(float(z.imag))) for z in h[u,:,s]]
            g[u,s]=sum(a*a+b*b for a,b in vectors[u,s])
    for (u,v,s),(a,b,r) in info['data'].items():
        guard();require(a==g[u,s] and b==g[v,s],'exact NPZ rational gain mismatch')
        re=sum(x*z+y*w for (x,y),(z,w) in zip(vectors[u,s],vectors[v,s]))
        im=sum(x*w-y*z for (x,y),(z,w) in zip(vectors[u,s],vectors[v,s]))
        expected=(re*re+im*im)/(a*b) if a*b else F(0)
        require(r==expected,'exact NPZ squared normalized correlation mismatch')
    return dict(npz_sha256=sha(path),pairs_checked=len(info['data']),shape=list(h.shape),
                scope='saved binary64 physically whitened channel to rational optimization coefficients')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path);parser.add_argument('--geometry',choices=['all','sample'],default='all')
    parser.add_argument('--max-seconds',type=float,default=55.)
    args=parser.parse_args();root=args.root.resolve();output=args.output.resolve()
    base=root/'research/completion-20261031';inputs=base/'confirmation/run-01-inputs';results=base/'confirmation/run-01-results'
    require(not output.exists(),'refusing to overwrite existing output')
    require(not output.is_relative_to(inputs) and not output.is_relative_to(results),'output must be outside source input/result directories')
    started=time.perf_counter();errors=[];case_reports=[];cell_reports=[];geometry_reports=[];cases={}
    def guard():
        if time.perf_counter()-started>args.max_seconds:raise BudgetExceeded('bounded verification allowance reached')
    report=dict(status='INCOMPLETE',scope='independent saved-artifact structural, feasibility, objective, receipt and geometric checks',
                global_upper_bounds_independently_reproved=False,root=str(root),geometry_mode=args.geometry,
                expected_cells=176,expected_cases=32,case_checks=case_reports,cell_checks=cell_reports,geometry_checks=geometry_reports,errors=errors)
    try:
        generation=read(inputs/'generation.json');indexed={x['name']:x for x in generation['cases']}
        require(len(indexed)==32,'generation case manifest cardinality')
        noise=10**((-174+7-30)/10)*(50e6/32);require(generation['noise_W']==noise,'declared physical noise convention')
        for panel,N in [('B',24),('scale',8)]:
            for i in range(N):
                guard();name=f'{panel}-{i:02d}';path=inputs/(name+'.json');case=read(path)
                try:
                    require(sha(path)==indexed[name]['sha256'],'generation case hash')
                    require(case['input_sha256']==generation['sha256'],'raw source-hash declaration')
                    require(case['user_indices']==indexed[name]['indices'],'manifest sampled indices')
                    require(case['resources']==([0,8,16,24] if panel=='B' else list(range(0,32,4))),'registered resources')
                    cases[name]=validate_case(case,name);case_reports.append(dict(case=name,status='PASS',pairs=len(case['pairs']),sha256=sha(path)))
                except Exception as exc:errors.append(dict(case=name,error=repr(exc)))
        for row in expected_cells():
            guard();name=cell_name(row);out=dict(cell=name,status='FAIL');cell_reports.append(out)
            try:
                path=results/(name+'.json');final=read(path);out['record_sha256']=sha(path)
                out['execution_status']=final['status'];snapshot=final.get('eligible_snapshot')
                dispatch_artifacts=[p.name for p in results.glob(name+'.*') if p.is_file() and
                    any(tag in p.name for tag in ['.attempt.','.log','.snapshot.','.eligible','.receipt-'])]
                out['dispatch_artifacts_count']=len(dispatch_artifacts)
                if final['status'].startswith('NOT_RUN'):
                    require(final['certified_by_deadline'] is None and snapshot is None,'undispatched outcome misclassified')
                    require(not dispatch_artifacts,'NOT_RUN has persisted dispatch evidence')
                    out.update(status='PASS',eligibility='NOT_RUN');continue
                require(bool(dispatch_artifacts),'attempted final has no persisted dispatch evidence')
                if snapshot is None:
                    require(final['certified_by_deadline'] is False,'certificate without eligible snapshot')
                    out.update(status='PASS',eligibility='NO_ELIGIBLE_SNAPSHOT');continue
                case_name=f"{'B' if row[0]=='gridcontrol' else row[0]}-{row[1]:02d}"
                out['receipt']=receipt_check(results,name,row,snapshot)
                out['schedule']=schedule_check(cases[case_name],snapshot)
                certified=F(snapshot['upper_nats'])-F(snapshot['lower_nats'])<=F(1,100)
                require(final['certified_by_deadline'] is certified,'certificate flag differs from qualified gap')
                out.update(status='PASS',eligibility='PARENT_RECEIPT_VALID')
            except Exception as exc:errors.append(dict(cell=name,error=repr(exc)))
        # All final schedules/receipts take priority over the larger geometry loop.
        import numpy as np
        report['numpy_version']=np.__version__
        selected=sorted(cases) if args.geometry=='all' else [name for name in ['B-00','scale-00'] if name in cases]
        for name in selected:
            guard()
            try:geometry_reports.append(dict(case=name,status='PASS',**geometry_check(np,inputs/(name+'.npz'),cases[name],guard)))
            except BudgetExceeded:raise
            except Exception as exc:errors.append(dict(geometry_case=name,error=repr(exc)))
        report['status']='PASS' if not errors and len(case_reports)==32 and len(cell_reports)==176 and len(geometry_reports)==len(selected) else 'FAIL'
    except BudgetExceeded as exc:errors.append(dict(budget=str(exc)))
    except Exception as exc:errors.append(dict(fatal=repr(exc)));report['status']='FAIL'
    report['seconds']=time.perf_counter()-started
    report['geometry_pair_rows_checked']=sum(z['pairs_checked'] for z in geometry_reports)
    report['eligible_schedules_checked']=sum(z.get('eligibility')=='PARENT_RECEIPT_VALID' for z in cell_reports)
    report['limitations']=['No raw large DeepMIMO NPZ loading or physical ray-tracing regeneration.',
        'Physical scaling metadata checked; exact geometry reconstructed from small saved whitened NPZs.',
        'No fresh root isolation, spatial branch-tree reconstruction, solver execution, or global upper-bound proof.',
        'Saved upper validity additionally depends on independently audited frozen algorithm applicability and complete execution evidence.',
        'Receipt validation proves recorded parent evidence consistency, not independent remeasurement of historical elapsed time.']
    with output.open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps({k:report[k] for k in ['status','seconds','eligible_schedules_checked','geometry_pair_rows_checked']}))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':sys.exit(main())
