import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,json,time,math
import pilot_value as p
R=p.R;D=p.D

def paths(H,ids,mean,cov,noise,rng):
 x=np.exp(2j*np.pi*np.arange(4)[:,None]*np.arange(4)[None,:]/4)
 hat=[];actual=[];oracle=[];features=[]
 for ix in ids:
  h=H[ix];chunks=[]
  for _ in range(4):
   eps=(rng.normal(size=h.shape)+1j*rng.normal(size=h.shape))*np.sqrt(noise/2)
   chunks.append(x.conj().T@(x@h+eps)/4)
  hats=[];acts=[];fs=[]
  for t,k in enumerate([1,2,4]):
   ls=np.mean(chunks[:k],axis=0);filt=np.linalg.solve(cov+noise/p.TAU[t]*np.eye(64),cov).T
   he=(ls-mean)@filt+mean;truth=h.reshape(4,32,2);est=he.reshape(4,32,2)
   q=p.rewards(est,est,noise);hats.append(q);acts.append(p.rewards(truth,est,noise))
   gains=np.sum(abs(he)**2,axis=1);sortedq=np.sort(q)
   fs.append([q.max(),q.std(),sortedq[-1]-sortedq[-2],np.log1p(gains.min()/noise),np.log1p(gains.max()/noise),np.log1p(gains.mean()/noise),float(p.TAU[t])])
  hat.append(hats);actual.append(acts);features.append(fs);oracle.append(p.rewards(truth,truth,noise))
 return np.array(hat),np.array(actual),np.array(oracle),np.array(features)

def design(x,mean,sd):
 z=(x-mean)/sd
 return np.column_stack([np.ones(len(z)),z,z*z])

def ridge(x,y):return np.linalg.solve(x.T@x+np.eye(x.shape[1]),x.T@y)

def main():
 start=time.time();raw=np.load(D/'channels.npz');H=raw['H'].reshape(-1,64)/float(np.load(D/'normalization.npz')['train_rms']);loc=raw['location'];oldids=np.load(D/'split-indices.npz')
 train=H[oldids['train']].reshape(-1,64);mean=train.mean(0);z=train-mean;cov=z.T@z.conj()/len(z)
 order=np.lexsort((loc[:,0],loc[:,1]));n=len(H);pool=order[int(.55*n):int(.68*n)];shiftpool=order[int(.73*n):int(.83*n)]
 out=[];allrows=[];fitted=[]
 for context,noise in enumerate([.1,1.,10.]):
  rng=np.random.default_rng(72000+context)
  ids=np.concatenate([oldids['train'],np.array([rng.choice(pool if i<160 else shiftpool,4,replace=False) for i in range(200)])])
  hat,actual,oracle,feat=paths(H,ids,mean,cov,noise,rng)
  assert np.all(actual<=oracle[:,None,:]+1e-7)
  best=hat.argmax(2);sel=np.take_along_axis(actual,best[...,None],2)[...,0];V=oracle.max(1)
  fm=feat[:100,:2].reshape(-1,7).mean(0);fs=feat[:100,:2].reshape(-1,7).std(0)+1e-8
  xx=design(feat[:,:2].reshape(-1,7),fm,fs).reshape(400,2,-1)
  np.savez_compressed(R/f'learned-paths-{context}.npz',ids=ids,hat=hat,actual=actual,oracle=oracle,features=feat)
  qa=p.quantile(np.maximum(abs(oracle[200:280,None,:]-hat[200:280]),abs(actual[200:280]-hat[200:280])).max((1,2)))
  for T in [50,200,1000]:
   g=1-p.TAU/T;target=g[None,1:]*V[:,None]-g[None,:2]*sel[:,:2]
   w=ridge(xx[:100].reshape(-1,15),target[:100].ravel());pred=xx@w
   sw=ridge(xx[100:200].reshape(-1,15),np.abs(target[100:200]-pred[100:200]).ravel())
   scale=np.maximum(.05,xx@sw)
   q=p.quantile(((target[200:280]-pred[200:280])/scale[200:280]).max(1))
   rawpred=(g[1:]-g[:-1])*hat.max(2)[:,:2]
   qr=p.quantile((target[200:280]-rawpred[200:280]).max(1))
   fitted.append({'noise':noise,'T':T,'feature_mean':fm.tolist(),'feature_sd':fs.tolist(),'w':w.tolist(),'scale_w':sw.tolist(),'q':q,'raw_q':qr,'abs_q':qa})
   for split,indices in [('iid_development',range(280,360)),('shift_stress',range(360,400))]:
    for method in ['learned_contrast','raw_contrast','absolute']:
     rr=[]
     for i in indices:
      if method=='learned_contrast':
       bounds=pred[i]+q*scale[i];candidates=np.flatnonzero(bounds<=0);t=int(candidates[0]) if len(candidates) else 2
       ub=float(bounds[t]) if t<2 else None
      else:t,ub=p.policy(hat[i],qr if method=='raw_contrast' else qa,T,'contrast' if method=='raw_contrast' else 'absolute')
      row={'noise':noise,'T':T,'split':split,'method':method,'sample':i,'tau':int(p.TAU[t]),'net_se':float(g[t]*sel[i,t]),'certificate_upper':ub,'early':t<2,'false_certificate':bool(t<2 and target[i,t]>1e-8)}
      for j,tau in enumerate(p.TAU):row[f'fixed_{tau}']=float(g[j]*sel[i,j])
      rr.append(row);allrows.append(row)
     early=sum(r['early'] for r in rr);bad=sum(r['false_certificate'] for r in rr)
     out.append({'noise':noise,'T':T,'split':split,'method':method,'N':len(rr),'mean_tau':float(np.mean([r['tau'] for r in rr])),'mean_net_se':float(np.mean([r['net_se'] for r in rr])),'early_stops':early,'false_certificates':bad,'unconditional_false_rate':bad/len(rr),'conditional_false_rate':bad/early if early else None,'fixed_means':{str(tau):float(np.mean([r[f'fixed_{tau}'] for r in rr])) for tau in p.TAU}})
   print('done',noise,T,flush=True)
 (R/'learned-results.json').write_text(json.dumps({'seed_base':72000,'alpha':.05,'train_mean_model_networks':100,'train_scale_model_networks':100,'calibration_networks':80,'seconds':time.time()-start,'models':fitted,'summary':out,'rows':allrows,'scope':'second and final exploratory round; all methods fixed before new calibration; future test untouched'},indent=2))

if __name__=='__main__':main()
