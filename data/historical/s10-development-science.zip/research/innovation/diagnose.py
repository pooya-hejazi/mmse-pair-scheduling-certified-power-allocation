"""Post-hoc diagnostics of saved round-2 paths; no fitting or new data draws."""
from pathlib import Path
import json, numpy as np
R=Path(__file__).resolve().parent
rows=[]
for k,noise in enumerate([.1,1.,10.]):
    d=np.load(R/f'learned-paths-{k}.npz')
    hat,actual,oracle=(d[x][280:360] for x in ['hat','actual','oracle'])
    chosen=hat.argmax(2)
    realized=np.take_along_axis(actual,chosen[...,None],2)[...,0]
    perfect=oracle.max(1)
    for T in [50,200,1000]:
        g=1-np.array([4,8,16])/T
        net=realized*g
        fixed=net.mean(0);j=int(fixed.argmax())
        # This oracle knows future noise/true H: an upper bound, not a deployable policy.
        hindsight=net.max(1)
        r={'noise':noise,'T':T,'N':len(net),'best_fixed_tau':int([4,8,16][j]),
           'best_fixed_mean':float(fixed[j]),
           'hindsight_budget_mean':float(hindsight.mean()),
           'adaptation_headroom_upper':float((hindsight-net[:,j]).mean()),
           'hindsight_tau_counts':{str(t):int(np.sum(net.argmax(1)==i)) for i,t in enumerate([4,8,16])},
           'raw_decomposition':[]}
        for t,tau in enumerate([4,8,16]):
            allocation=actual[:,t].max(1)-realized[:,t]
            receiver=perfect-actual[:,t].max(1)
            assert np.all(allocation>=-1e-10) and np.all(receiver>=-1e-7)
            assert np.allclose(allocation+receiver,perfect-realized[:,t])
            r['raw_decomposition'].append({'tau':tau,'allocation_regret':float(allocation.mean()),
                'receiver_gap':float(receiver.mean()),'allocation_selection_error_fraction':float(np.mean(chosen[:,t]!=actual[:,t].argmax(1))),
                'perfect_action_spread':float(np.ptp(oracle,axis=1).mean())})
        rows.append(r)
(R/'diagnostics.json').write_text(json.dumps({'scope':'post-hoc descriptive upper bounds on same development paths; not confirmatory evidence','rows':rows},indent=2))
for r in rows:
    print(r['noise'],r['T'],'fixed',r['best_fixed_tau'],'headroom',round(r['adaptation_headroom_upper'],6),'allocation/receiver',[(round(z['allocation_regret'],5),round(z['receiver_gap'],5)) for z in r['raw_decomposition']])
