"""Deterministic replay/checks of saved discovery outputs, without new fitting/data."""
from pathlib import Path
import json, hashlib, math
import numpy as np
R=Path(__file__).resolve().parent;ROOT=R.parents[1]
def quantile(a):
    k=math.ceil((len(a)+1)*.95)
    return float(np.sort(a)[k-1]) if k<=len(a) else float('inf')
def close(a,b):assert np.allclose(a,b,rtol=1e-8,atol=1e-8),(a,b)
def design(x,m,s):
    z=(x-m)/s
    return np.concatenate([np.ones(z.shape[:-1]+(1,)),z,z*z],axis=-1)
old=np.load(R.parent/'reproduction/split-indices.npz')
report={'S02_unchanged':True,'round1_rows':0,'round2_rows':0,'checks':[]}
manifest=json.loads((R.parent/'reproduction/run-manifest.json').read_text())
for f in manifest['files']:
    assert hashlib.sha256((ROOT/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
tau=np.array([4,8,16])
for roundno,filename,prefix,cal,dev in [(1,'pilot-results.json','paths-noise',slice(0,80),slice(80,160)),(2,'learned-results.json','learned-paths-',slice(200,280),slice(280,360))]:
    result=json.loads((R/filename).read_text())
    for context,noise in enumerate([.1,1.,10.]):
        d=np.load(R/f'{prefix}{context}.npz');hat=d['hat'];actual=d['actual'];oracle=d['oracle'];ids=d['ids']
        assert not set(ids[cal].ravel())&set(old['train'].ravel())
        assert not set(ids[dev].ravel())&set(old['test'].ravel())
        assert np.all(actual<=oracle[:,None,:]+1e-7)
        selected=np.take_along_axis(actual,hat.argmax(2)[...,None],2)[...,0]
        qa=quantile(np.maximum(abs(oracle[cal,None,:]-hat[cal]),abs(actual[cal]-hat[cal])).max((1,2)))
        for T in [50,200,1000]:
            g=1-tau/T;target=g[None,1:]*oracle.max(1)[:,None]-g[None,:2]*selected[:,:2]
            raw=(g[1:]-g[:-1])*hat.max(2)[:,:2];qr=quantile((target[cal]-raw[cal]).max(1))
            if roundno==2:
                m=next(m for m in result['models'] if m['noise']==noise and m['T']==T)
                x=design(d['features'][:,:2],np.array(m['feature_mean']),np.array(m['feature_sd']))
                pred=x@np.array(m['w']);scale=np.maximum(.05,x@np.array(m['scale_w']))
                q=quantile(((target[cal]-pred[cal])/scale[cal]).max(1));close(q,m['q']);close(qr,m['raw_q']);close(qa,m['abs_q'])
                # Each prediction uses only that prefix's features; future alteration leaves it unchanged.
                f=d['features'][dev.start].copy();before=design(f[0],np.array(m['feature_mean']),np.array(m['feature_sd']))@np.array(m['w']);f[1:]=1e7
                close(before,design(f[0],np.array(m['feature_mean']),np.array(m['feature_sd']))@np.array(m['w']))
            for row in result['rows']:
                if row['noise']!=noise or row.get('T',row.get('coherence'))!=T:continue
                i=row['sample'];method=row['method'];t=2;ub=None
                for j in range(2):
                    v=hat[i,j].max()
                    bound=(pred[i,j]+q*scale[i,j]) if method=='learned_contrast' else ((g[j+1]-g[j])*v+qr if method in ['contrast','raw_contrast'] else g[j+1]*(v+qa)-g[j]*max(0,v-qa))
                    if bound<=0:t=j;ub=bound;break
                assert row['tau']==tau[t]
                close(row['net_se'],g[t]*selected[i,t])
                assert row['early']==(t<2)
                assert row['false_certificate']==bool(t<2 and target[i,t]>1e-8)
                if ub is not None:close(row['certificate_upper'],ub)
                for j,k in enumerate(tau):close(row[f'fixed_{k}'],g[j]*selected[i,j])
                report[f'round{roundno}_rows']+=1
    for s in result['summary']:
        rows=[r for r in result['rows'] if r['noise']==s['noise'] and r.get('T',r.get('coherence'))==s.get('T',s.get('coherence')) and r['method']==s['method'] and r['split']==s['split']]
        assert len(rows)==s['N'];close(s['mean_net_se'],np.mean([r['net_se'] for r in rows]));close(s['mean_tau'],np.mean([r['tau'] for r in rows]))
report['checks']=['all S02 manifest hashes unchanged','saved quantiles and selections replayed','all rate rows and summary means replayed','cal/train and development/old-test spatial disjointness','perfect-CSI receiver upper bound','prefix-local learned features']
report['limits']='author verification, not independent checkpoint audit; empirical replay is not proof of population coverage or novelty'
(R/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
