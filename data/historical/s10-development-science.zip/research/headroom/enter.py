from pathlib import Path
from datetime import datetime,timezone
import re,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'research/tools'));from bundle_tools import install
dst=R/'audit/staging/B026';dst.mkdir();stamp=datetime.now(timezone.utc).isoformat()
for n in ['plan.md','tasks.md','checkpoints.md']:
 s=(R/n).read_text(encoding='utf8').replace('Bundle-Revision: B025','Bundle-Revision: B026');s=re.sub(r'^Updated-At: .*','Updated-At: '+stamp,s,count=1,flags=re.M)
 if n=='plan.md':s+='\n## CR009 bounded alternate diagnostic\nUser explicitly authorized autonomous continuation and Astra decision support. /root/astra_research_decision (gpt-6-astra) reviewed completed CR008:213 completed/2 bounded timeouts, no clear selective-information gain, zero certificate stops. Astra recommends perfect-information headroom before more policy work. Prospective packet research/headroom/PROTOCOL.md, same32inputs/no tuning; existing REQ003/005/007/009 and T-A02..04. Classical oracle/no-acquisition bound is not novelty. Storage-only CR008 repair preserved previous source hashes and resumed no completed job; independent acceptance pending.\n'
 if n=='tasks.md':s+='\nProgress B026: deadline supervisor and continuous/I-WMMSE comparisons completed provisionally in research/comparison; all32informationcases and64timeouts recorded. T-G02 remains open for GPU instrumentation; T-G03 comparison evidence available but no self-verification. T-A02..04 now bounded headroom diagnostic per Astra; no new selector tuning.\n'
 if n=='checkpoints.md':s+='\n## resume B026\nCR008 finished, no process running. S03/S03G audit0/2unchanged; S04 locked. Astra consultation is not independent stage acceptance. Next authorized task: CR00910min oracle headroom diagnostic with all32priorinstances, exactgrid and separatecontinuousbounds. No original/test mutation or budget reset.\n'
 (dst/n).write_text(s,encoding='utf8')
print(install(dst))
