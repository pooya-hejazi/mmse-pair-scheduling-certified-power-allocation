from pathlib import Path
from datetime import datetime,timezone
import re,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'research/tools'));from bundle_tools import install
dst=R/'audit/staging/B027';dst.mkdir();stamp=datetime.now(timezone.utc).isoformat()
for n in ['plan.md','tasks.md','checkpoints.md']:
 s=(R/n).read_text(encoding='utf8').replace('Bundle-Revision: B026','Bundle-Revision: B027');s=re.sub(r'^Updated-At: .*','Updated-At: '+stamp,s,count=1,flags=re.M)
 if n=='plan.md':s+='\n## CR010 final decision-only diagnostic\nAstra follow-up: receiver-first89% attribution does not bound decision-only opportunity. Same32cases, frozen initial-estimate receiver mapping, exactgrid oracle and LP bound per research/headroom/FROZEN_RECEIVER_PROTOCOL.md;5s perworker,5min total, no newselector/no sampling. Existing T-A02..04 scope. CR009 completed32/32 with exactgrid opportunity6.224%, continuous6.154..18.075%; these are unattainable optimistic diagnostics, not gains.\n'
 if n=='tasks.md':s+='\nProgress B027: CR009 all32 checks passed provisionally, no new VERIFIED. T-A02..04 next CR010 frozen receiver mapping to test optimization-specific headroom; Astra remains consultant, not acceptance auditor.\n'
 if n=='checkpoints.md':s+='\n## resume B027\nCR009 finished; next CR010 bounded5min, samecases. Independent S03/S03G acceptance remains open, audit0/2each; S04 locked. Gate failure will stop this finite-grid selector route and shift to optimization structure/theory, without claiming a general impossibility.\n'
 (dst/n).write_text(s,encoding='utf8')
print(install(dst))
