from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import baselines as b

start=time.perf_counter()
counts={k:len(list(b.assignments(k))) for k in [4,6,8]}
assert counts=={4:6,6:90,8:2520}
for k in [4,6]:
    for sc in b.assignments(k):
        assert sorted(i for u,v,t in sc for i in [u,v])==list(range(k))
        assert sorted(t for u,v,t in sc)==list(range(k//2))
case={'K':4,'S':2,'pmin':'1/20','pmax':'1/5','budget':'2/5','pairs':[]}
for u in range(4):
    for v in range(u+1,4):
        for t in range(2):
            case['pairs'].append({'users':[u,v],'resource':t,'gain1':str(3+u),'gain2':str(3+v),'r':'0'})
results={m:b.solve(case,m,3) for m in ['grid','slsqp','iwmmse']}
assert all(r['status']=='ALL_ASSIGNMENTS_VISITED_LOCAL_ONLY' for m,r in results.items() if m!='grid')
assert abs(results['slsqp']['Q_nats']-results['iwmmse']['Q_nats'])<1e-7
for out in results.values():
    vals=[]
    for row in out['schedule']: vals.extend(map(b.F,row['powers']))
    assert sum(vals)<=b.F(case['budget']) and min(vals)>=b.F(case['pmin']) and max(vals)<=b.F(case['pmax'])
lookup={(0,1,0):(3.,5.,.7)}
p=np.array([.08,.12]); val,grad=b.value_gradient(p,[(0,1,0)],lookup)
for i in range(2):
    pp=p.copy();pm=p.copy();pp[i]+=1e-7;pm[i]-=1e-7
    fd=(b.value_gradient(pp,[(0,1,0)],lookup)[0]-b.value_gradient(pm,[(0,1,0)],lookup)[0])/2e-7
    assert abs(fd-grad[i])<1e-7
for r in [0.,.3,1.]:
    g1,g2=3.,5.;H=np.array([[np.sqrt(g1),np.sqrt(g2*r)],[0.,np.sqrt(g2*(1-r))]])
    U=np.linalg.solve(np.eye(2)+H@np.diag(p)@H.T,H@np.diag(np.sqrt(p)))
    gains=(U.T@H@np.diag(np.sqrt(p)))**2
    direct=sum(np.log1p(gains[i,i]/(gains[i,1-i]+sum(U[:,i]**2))) for i in range(2))
    algebra=b.value_gradient(p,[(0,1,0)],{(0,1,0):(g1,g2,r)})[0]
    assert abs(direct-algebra)<1e-12
for m in ['slsqp','iwmmse']:
    out=b.solve(case,m,0)
    assert out['status']=='TIME_LIMIT_LOCAL_INCUMBENT' and out['assignments_visited']==0
endpoint=dict(case,budget='1/5')
for m in ['slsqp','iwmmse']:
    out=b.solve(endpoint,m,3)
    assert out['radiated_power']=='1/5'
out={'status':'PASS_AUTHOR_CHECK','assignment_counts':counts,'orthogonal_results':results,
     'gradient_vs_finite_difference':True,'direct_MMSE_vs_formula':True,
     'zero_seconds_valid_incumbent':True,'singleton_budget_feasible':True,
     'seconds':time.perf_counter()-start}
dest=Path(__file__).with_name('results.json')
dest.write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='orthogonal_results'},indent=2))
