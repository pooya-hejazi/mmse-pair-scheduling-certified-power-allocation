from pathlib import Path
from fractions import Fraction as F
import os,sys,json,time
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
D=Path(__file__).resolve().parent
from network_global import Problem,solve as global_solve
from baselines import solve as baseline_solve
sys.path.insert(0,str(D.parent))
from rational_oracle import maximize

case_index=int(sys.argv[1]);method=sys.argv[2]
case=json.loads((D/'cases.json').read_text(encoding='utf-8'))[case_index]
outdir=D/'results';outdir.mkdir(exist_ok=True)
dest=outdir/f'{case_index}-{method}.json';assert not dest.exists()
started=time.perf_counter()
if method in ('grid','slsqp','iwmmse'):
    out=baseline_solve(case,method,seconds=20)
    p=Problem(case);s,powers=p.parse_schedule(out['schedule']);low,up=p.value(s,powers)
    out['validated_lower_nats']=str(low);out['validated_feasible_upper_nats']=str(up)
elif method=='repair':
    grid=json.loads((outdir/f'{case_index}-grid.json').read_text(encoding='utf-8'))
    if 'alpha' not in grid or 'lambda' not in grid:
        out=dict(status='NO_LP_PRICES',upper_nats=None)
    else:
        alpha=list(map(F,grid['alpha']));lam=max(F(0),F(grid['lambda']));beta=[None]*case['S'];rows=[]
        out=dict(status='TIME_LIMIT_INCOMPLETE_NO_CERTIFICATE',upper_nats=None)
        try:
            for row in case['pairs']:
                if time.perf_counter()-started>=25:break
                u,v=row['users'];s=row['resource'];g1,g2,r=map(F,(row['gain1'],row['gain2'],row['r']))
                lo,hi=F(case['pmin']),F(case['pmax'])
                z=maximize(r,lam/g1,lam/g2,(g1*lo,g1*hi,g2*lo,g2*hi),tolerance=F(1,10**7))
                b=z['upper']-alpha[u]-alpha[v];beta[s]=b if beta[s] is None else max(beta[s],b)
                rows.append(dict(users=[u,v],resource=s,upper=str(z['upper']),lower=str(z['lower']),root_digits=z['root_digits']))
            if len(rows)==len(case['pairs']):
                upper=sum(alpha)+sum(beta)+lam*F(case['budget'])
                assert upper>=F(grid['validated_lower_nats'])
                out=dict(status='CERTIFIED_CONTINUOUS_RELAXATION_UPPER',upper_nats=str(upper),alpha=list(map(str,alpha)),
                         beta=list(map(str,beta)),lambda_value=str(lam))
        except ArithmeticError as error:
            out=dict(status='ARITHMETIC_LIMIT_NO_CERTIFICATE',upper_nats=None,error=str(error))
        out['priced_pairs']=len(rows);out['total_pairs']=len(case['pairs']);out['pricing_rows']=rows
    out['seconds']=time.perf_counter()-started
else:
    assert method in ('reference','accelerated')
    grid=json.loads((outdir/f'{case_index}-grid.json').read_text(encoding='utf-8'))
    external=None
    if method=='accelerated':
        repairfile=outdir/f'{case_index}-repair.json'
        if repairfile.exists():external=json.loads(repairfile.read_text(encoding='utf-8')).get('upper_nats')
    out=global_solve(case,accelerated=method=='accelerated',seconds=20,initial=grid['schedule'],external_upper=external)
out['case']=case['name'];out['method']=method;out['worker_compute_seconds']=time.perf_counter()-started
out['input_sha256']=case['input_sha256']
dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k in ['case','method','status','gap_nats','seconds','assignments_completed','priced_pairs','curvature_pairs','all_pairs','setup_seconds']}))
