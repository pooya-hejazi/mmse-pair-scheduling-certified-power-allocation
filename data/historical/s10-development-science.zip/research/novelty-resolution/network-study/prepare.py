from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import hashlib,json
import numpy as np
D=Path(__file__).resolve().parent;R=D.parents[2]
source=R/'research/comparison/inputs/power-8.npz'
expected='fb56044c341f30aa5d0f6ed6596a29615892f7645eac1c54760bbd4b7ba86fa0'
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
h=np.load(source)['h'];assert h.shape[0]==8 and h.shape[2]==4
cases=[]
for K,budget in [(4,F(2,5)),(6,F(3,5)),(8,F(4,5)),(8,F(2,5)),(8,F(8,5))]:
    S=K//2;vectors={};g={};pairs=[]
    for u in range(K):
        for s in range(S):
            vectors[u,s]=[(F(float(z.real)),F(float(z.imag))) for z in h[u,:,s]]
            g[u,s]=sum(a*a+b*b for a,b in vectors[u,s])
    for u,v in combinations(range(K),2):
        for s in range(S):
            re=sum(a*c+b*d for (a,b),(c,d) in zip(vectors[u,s],vectors[v,s]))
            im=sum(a*d-b*c for (a,b),(c,d) in zip(vectors[u,s],vectors[v,s]))
            r=(re*re+im*im)/(g[u,s]*g[v,s])
            pairs.append(dict(users=[u,v],resource=s,gain1=str(g[u,s]),gain2=str(g[v,s]),r=str(r)))
    cases.append(dict(name=f'K{K}-P{float(budget):.1f}',K=K,S=S,M=h.shape[1],pmin='1/20',pmax='1/5',budget=str(budget),
                      pairs=pairs,input_sha256=expected,scope='overlapping development subset; perfect CSI'))
dest=D/'cases.json';assert not dest.exists();dest.write_text(json.dumps(cases,indent=2)+'\n',encoding='utf-8')
print(json.dumps([dict(name=c['name'],pairs=len(c['pairs']),K=c['K']) for c in cases]))
