from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import hashlib,json,numpy as np
D=Path(__file__).resolve().parent;R=D.parents[2]
p=R/'research/comparison/inputs/power-16.npz';expected='03d492cdd71a451355a3e444e470a90cd126f2e3d7d096bb7238e0ccc41e01f2'
assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
h=np.load(p)['h'];K,M,S=h.shape;assert (K,S)==(16,8)
vectors={};g={};pairs=[]
for u in range(K):
 for s in range(S):
  vectors[u,s]=[(F(float(z.real)),F(float(z.imag))) for z in h[u,:,s]]
  g[u,s]=sum(a*a+b*b for a,b in vectors[u,s])
for u,v in combinations(range(K),2):
 for s in range(S):
  re=sum(a*c+b*d for (a,b),(c,d) in zip(vectors[u,s],vectors[v,s]))
  im=sum(a*d-b*c for (a,b),(c,d) in zip(vectors[u,s],vectors[v,s]))
  pairs.append(dict(users=[u,v],resource=s,gain1=str(g[u,s]),gain2=str(g[v,s]),r=str((re*re+im*im)/(g[u,s]*g[v,s]))))
case=dict(name='K16-P1.6',K=K,M=M,S=S,pmin='1/20',pmax='1/5',budget='8/5',pairs=pairs,input_sha256=expected)
dest=D/'scale-case.json';assert not dest.exists();dest.write_text(json.dumps(case,indent=2)+'\n',encoding='utf-8')
print('Prepared 960 pair/resource entries from existing K16 input.')
