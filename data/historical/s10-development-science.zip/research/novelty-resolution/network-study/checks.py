from fractions import Fraction as F
from itertools import combinations,product
import json,time
from network_global import Problem,assignments,solve,affine_max

start=time.perf_counter()
assert [len(list(assignments(k))) for k in (4,6,8)]==[6,90,2520]
for k in (4,6,8):
    for s in assignments(k):assert sorted(u for pair in s for u in pair)==list(range(k))
def case(K,r,budget='2'):
    return dict(K=K,S=K//2,pmin='1/5',pmax='4/5',budget=budget,
                pairs=[dict(users=[u,v],resource=s,gain1='2',gain2='3',r=str(r)) for u,v in combinations(range(K),2) for s in range(K//2)])
count=0
for r in [F(0),F(1,5),F(293,1000),F(1,2),F(1)]:
    c=case(2,r,'1');p=Problem(c);sched=((0,1),)
    for acc in [False,True]:
        for lo,hi in [((F(1,5),)*2,(F(4,5),)*2),((F(2,5),)*2,(F(2,5),)*2)]:
            upper,tight,center=p.bound(sched,lo,hi,acc)
            for x,y in product([F(1,5),F(2,5),F(3,5),F(4,5)],repeat=2):
                if all(l<=v<=h for l,v,h in zip(lo,(x,y),hi)) and x+y<=p.budget:
                    assert p.value(sched,(x,y))[0]<=upper;count+=1
            assert p.value(sched,center)[0]<=upper
    out=solve(c,seconds=0);assert F(out['lower_nats'])<=F(out['upper_nats']) and out['complete_assignment_coverage']
singleton=case(4,F(1,2),'4/5')
for acc in [False,True]:
    out=solve(singleton,accelerated=acc,seconds=2)
    assert out['status']=='CERTIFIED' and out['assignments']==6
    p=Problem(singleton);s,powers=p.parse_schedule(out['schedule']);assert sum(powers)==F(4,5)
    assert p.value(s,powers)[0]==F(out['lower_nats'])
assert affine_max([F(2),F(-1)],F(3),(F(0),F(0)),(F(1),F(1)),F(1,2))==4
print(json.dumps(dict(result='PASS',pointwise_bound_checks=count,assignment_counts=[6,90,2520],seconds=time.perf_counter()-start)))
