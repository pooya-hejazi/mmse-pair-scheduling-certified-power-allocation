from pathlib import Path
from fractions import Fraction as F
import sys,json,math,csv,hashlib
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
from network_global import Problem
sys.path.insert(0,str(D.parent))
from rational_oracle import ln_point
cases=json.loads((D/'cases.json').read_text(encoding='utf-8'))
executions=json.loads((D/'executions.json').read_text(encoding='utf-8'))
assert len(executions)==30
timings={(e['case_index'],e['method']):e for e in executions}
ln2lo,ln2hi=ln_point(F(2));summary=[];table=[]
def display_lower(v):return str(math.floor(v*10**6)/10**6)
def display_upper(v):return str(math.ceil(v*10**6)/10**6)
for i,case in enumerate(cases):
    p=Problem(case);methods={};lowers=[];uppers=[]
    for method in ['grid','repair','slsqp','iwmmse','reference','accelerated']:
        path=D/'results'/f'{i}-{method}.json';execution=timings[i,method]
        if not path.exists():
            methods[method]=dict(status=execution['status'],wall_seconds=execution['wall_seconds']);continue
        z=json.loads(path.read_text(encoding='utf-8'));item=dict(status=z['status'],wall_seconds=execution['wall_seconds'])
        if 'schedule' in z:
            schedule,powers=p.parse_schedule(z['schedule']);l,u=p.value(schedule,powers)
            recorded=z.get('validated_lower_nats',z.get('lower_nats'))
            assert recorded is not None and F(recorded)==l
            lowers.append((l,method));item.update(lower_nats=str(l),sumSE_lower=display_lower(l/ln2hi),power_W=str(sum(powers)))
        if z.get('upper_nats') is not None:
            upper=F(z['upper_nats']);uppers.append((upper,method));item['upper_nats']=str(upper)
        for key in ['gap_nats','assignments_completed','assignments_total','complete_assignment_coverage','assignments','curvature_pairs','all_pairs','MILP_status','LP_status','numerical_solver_failures','finite_iteration_stops','setup_seconds','seconds']:
            if key in z:item[key]=z[key]
        methods[method]=item
    best,best_method=max(lowers);upper,upper_method=min(uppers);assert upper>=best
    assert all(u>=best for u,m in uppers)
    acc=methods['accelerated'];ref=methods['reference']
    for method,item in methods.items():
        if 'lower_nats' in item:item['a_posteriori_gap_nats']=float(upper-F(item['lower_nats']))
    combined=methods['grid']['wall_seconds']+methods['repair']['wall_seconds']+acc['wall_seconds']
    refcombined=methods['grid']['wall_seconds']+ref['wall_seconds']
    row=dict(case=case['name'],K=case['K'],S=case['S'],M=case['M'],budget_W=case['budget'],best_feasible_method=best_method,
             lower_nats=str(best),upper_nats=str(upper),sumSE_lower=display_lower(best/ln2hi),sumSE_upper=display_upper(upper/ln2lo),
             best_gap_nats=float(upper-best),relative_gap_upper=float((upper-best)/best),upper_method=upper_method,
             methods=methods,accelerated_pipeline_wall_seconds=combined,reference_pipeline_wall_seconds=refcombined)
    summary.append(row)
    table.append([case['name'],str(acc.get('assignments','?')),ref.get('status'),f"{ref.get('gap_nats',float('nan')):.6g}",
                  acc.get('status'),f"{acc.get('gap_nats',float('nan')):.6g}",f'{refcombined:.3f}',f'{combined:.3f}',
                  row['sumSE_lower']+'--'+row['sumSE_upper']])
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
header=['Case','Assignments','Reference status','Reference gap nat','Accelerated status','Accelerated gap nat','Reference pipeline s','Accelerated pipeline s','Joint optimum sumSE interval']
with (D/'summary.csv').open('w',encoding='utf-8',newline='') as f:
    writer=csv.writer(f);writer.writerow(header);writer.writerows(table)
lines=['# Complete-network development results','',
       'Coordinator analysis; independent review pending. Five overlapping cases from one existing development channel archive. No population inference, held-out validation, throughput-superiority claim or GPU result. Both references enumerate every assignment and branch on continuous powers; requested gap is .01 nat per network. All local methods share full schedule family, two starts and20-second budget; visited counts differ and are retained.','',
       '| '+' | '.join(header)+' |','|'+'|'.join(['---']*len(header))+'|']
lines+=['| '+' | '.join(map(str,row))+' |' for row in table]
lines+=['','Reference pipeline time includes grid seed and generic reference. Accelerated pipeline includes the same grid seed, separately executed exact dual repair, and accelerated search; interpreter/import/output time is included. These are single observations in fixed order, not runtime distributions or statistically established speedups. A reference TIME_LIMIT is censored at its cap and is not treated as a completed solution. The optimum interval column combines the best independently rechecked feasible candidate from all methods with the smallest valid global upper bound; it is not the accelerated arm alone.','',
        '## Feasible methods and actual schedule-search coverage','',
        '| Case | Method | Feasible sumSE lower | Completed assignments | Status | External seconds |','|---|---|---:|---:|---|---:|']
for row in summary:
    for method in ['grid','slsqp','iwmmse']:
        x=row['methods'][method]
        lines.append(f"| {row['case']} | {method} | {x.get('sumSE_lower','unavailable')} | {x.get('assignments_completed','native MILP')} | {x['status']} | {x['wall_seconds']:.3f} |")
lines+=['','The LP repair alone bounds a continuous configuration relaxation. The complete reference closes actual integral/power gaps; intersecting bounds is valid but does not turn the relaxation into an exact reformulation. The accelerated arm adds the sharp whole-pair curvature tangent when valid and the repaired dual. This combined test cannot assign all benefit to quintic pricing alone. Solver statuses and all rational powers/bounds are preserved in results/.','',
        'The numerical search barrier is addressed on these small networks. Stronger publication evidence still requires independent physical scenarios, contemporary compatible comparisons, repeated timing, uncertainty/CSI and GPU requirement disposition. None of those is fabricated or silently waived.']
(D/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines[:11]))
