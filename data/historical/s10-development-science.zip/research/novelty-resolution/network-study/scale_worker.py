from pathlib import Path
from fractions import Fraction as F
import json,sys,time
D=Path(__file__).resolve().parent
from baselines import solve
from network_global import Problem
sys.path.insert(0,str(D.parent))
from rational_oracle import maximize
case=json.loads((D/'scale-case.json').read_text(encoding='utf-8'));method=sys.argv[1]
dest=D/f'scale-{method}.json';assert not dest.exists();start=time.perf_counter()
if method in ['grid','slsqp']:
 out=solve(case,method,seconds=20);p=Problem(case);s,powers=p.parse_schedule(out['schedule'])
 lo,hi=p.value(s,powers);out['lower_nats']=str(lo);out['feasible_upper_nats']=str(hi)
else:
 assert method=='repair'
 grid=json.loads((D/'scale-grid.json').read_text(encoding='utf-8'))
 alpha=list(map(F,grid['alpha']));lam=max(F(0),F(grid['lambda']));beta=[None]*case['S'];rows=[]
 out=dict(status='TIME_LIMIT_INCOMPLETE_NO_CERTIFICATE',upper_nats=None)
 try:
  for row in case['pairs']:
   if time.perf_counter()-start>=120:break
   u,v=row['users'];s=row['resource'];g1,g2,r=map(F,(row['gain1'],row['gain2'],row['r']))
   lo,hi=F(case['pmin']),F(case['pmax'])
   z=maximize(r,lam/g1,lam/g2,(g1*lo,g1*hi,g2*lo,g2*hi),tolerance=F(1,10**7))
   b=z['upper']-alpha[u]-alpha[v];beta[s]=b if beta[s] is None else max(beta[s],b)
   rows.append(dict(users=[u,v],resource=s,upper=str(z['upper']),lower=str(z['lower']),root_digits=z['root_digits']))
  if len(rows)==len(case['pairs']):
   upper=sum(alpha)+sum(beta)+lam*F(case['budget']);lower=F(grid['lower_nats']);assert upper>=lower
   out=dict(status='CERTIFIED_CONTINUOUS_RELAXATION_UPPER',upper_nats=str(upper),lower_nats=str(lower),
            relative_gap_upper=float((upper-lower)/lower),target_one_percent_met=(upper-lower)<=lower/100,
            alpha=list(map(str,alpha)),beta=list(map(str,beta)),lambda_value=str(lam))
 except ArithmeticError as error:out=dict(status='ARITHMETIC_LIMIT_NO_CERTIFICATE',upper_nats=None,error=str(error))
 out['pricing_rows']=rows;out['priced_pairs']=len(rows);out['total_pairs']=len(case['pairs'])
out['seconds']=time.perf_counter()-start;out['case']=case['name'];out['method']=method
dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k in ['status','relative_gap_upper','target_one_percent_met','priced_pairs','seconds']}))
