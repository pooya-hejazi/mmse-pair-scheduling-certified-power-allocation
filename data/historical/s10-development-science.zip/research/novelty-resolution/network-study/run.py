from pathlib import Path
import sys,json,time,hashlib,platform
D=Path(__file__).resolve().parent;R=D.parents[2]
sys.path.insert(0,str(R/'research/gpu'))
from bounded_process import run_bounded
assert not (D/'executions.json').exists()
files=[*D.glob('*.py'),D/'cases.json',D/'PROTOCOL.md',D/'BOUND_PROOF.md',D/'BASELINES.md',D.parent/'rational_oracle.py',R/'research/gpu/bounded_process.py']
manifest=dict(created_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
              python=sys.executable,platform=platform.platform(),entries=[dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files])
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
executions=[];start=time.perf_counter()
for i in range(5):
    for method in ['grid','repair','slsqp','iwmmse','reference','accelerated']:
        if time.perf_counter()-start>850:raise TimeoutError('overall development guard')
        seconds=40 if method=='repair' else 30
        result=run_bounded([sys.executable,'-B',str(D/'worker.py'),str(i),method],seconds,D/'executions'/f'{i}-{method}')
        result.update(case_index=i,method=method);executions.append(result)
        (D/'executions.json').write_text(json.dumps(executions,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({k:result[k] for k in ['case_index','method','status','wall_seconds']}),flush=True)
        if method=='grid' and result['status']!='COMPLETED':raise RuntimeError('required grid seed failed; stop dependencies')
drift=[e['path'] for e in manifest['entries'] if hashlib.sha256((R/e['path']).read_bytes()).hexdigest()!=e['sha256']]
assert not drift,drift
(D/'completion.json').write_text(json.dumps(dict(status='COMPLETED',workers=len(executions),seconds=time.perf_counter()-start,source_drift=drift),indent=2)+'\n',encoding='utf-8')
