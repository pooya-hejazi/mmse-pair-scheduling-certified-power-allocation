from pathlib import Path
import sys,json,hashlib,time
D=Path(__file__).resolve().parent;R=D.parents[2]
sys.path.insert(0,str(R/'research/gpu'))
from bounded_process import run_bounded
assert not (D/'scale-executions.json').exists()
files=[D/n for n in ['SCALE_PROTOCOL.md','scale_prepare.py','scale_worker.py','scale_run.py','scale-case.json','baselines.py','network_global.py']]+[D.parent/'rational_oracle.py']
entries=[dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
(D/'scale-manifest.json').write_text(json.dumps(dict(entries=entries),indent=2)+'\n',encoding='utf-8')
results=[];start=time.perf_counter()
for method,limit in [('grid',30),('repair',140),('slsqp',30)]:
 result=run_bounded([sys.executable,'-B',str(D/'scale_worker.py'),method],limit,D/'executions'/f'scale-{method}')
 result['method']=method;results.append(result)
 (D/'scale-executions.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:result[k] for k in ['method','status','wall_seconds']}),flush=True)
 if method=='grid' and result['status']!='COMPLETED':break
assert all(hashlib.sha256((R/e['path']).read_bytes()).hexdigest()==e['sha256'] for e in entries)
