"""Exact diagnostic of unrestricted assignment versus disjoint user pairing.

Six rational unit channels, fixed equal normalized power, resource-invariant
linear-MMSE reception without SIC. No numerical optimization or performance run.
"""
from fractions import Fraction as F
from itertools import permutations
from functools import reduce
from operator import mul
from pathlib import Path
import hashlib
import json
import math


def matchings(vertices):
    if not vertices:
        yield ()
        return
    i = vertices[0]
    for j in vertices[1:]:
        rest = tuple(k for k in vertices if k not in (i, j))
        for tail in matchings(rest):
            yield ((i, j),) + tail


def product(xs):
    return reduce(mul, xs, F(1))


def main():
    eye = [tuple(F(i == j) for i in range(3)) for j in range(3)]
    q = [[F(6, 7), F(-2, 7), F(-3, 7)],
         [F(-2, 7), F(3, 7), F(-6, 7)],
         [F(-3, 7), F(-6, 7), F(-2, 7)]]
    channels = eye + [tuple(q[i][j] for i in range(3)) for j in range(3)]
    dot = lambda a, b: sum(x * y for x, y in zip(a, b))
    assert all(dot(h, h) == 1 for h in channels)
    assert all(dot(channels[i], channels[j]) == F(i == j)
               for group in (range(3), range(3, 6)) for i in group for j in group)
    rho = [[dot(a, b)**2 for b in channels] for a in channels]
    assert min(rho[i][j] for i in range(3) for j in range(3, 6)) == F(4, 49)
    # exp(q_ij(1,1)) = (4-rho_ij)^2/4. Assignment diagonal weight is zero.
    weights = [[F(1) if i == j else (4-rho[i][j])**2 / 4
                for j in range(6)] for i in range(6)]
    ms = list(matchings(tuple(range(6))))
    ps = list(permutations(range(6)))
    assert len(ms) == 15 and len(ps) == 720
    matching_values = [(product(weights[i][j] for i, j in m), m) for m in ms]
    assignment_values = [(product(weights[i][p[i]] for i in range(6)), p) for p in ps]
    best_m = max(matching_values)
    best_a = max(assignment_values)
    expected_m = F(16)*F(9216, 2401)
    assert best_m[0] == expected_m
    assert best_a[0] == 4**6
    assert best_a[0] > best_m[0]**2
    opt_ps = [p for val, p in assignment_values if val == best_a[0]]
    assert len(opt_ps) == 4
    assert all(any(p[p[i]] != i for i in range(6)) for p in opt_ps)
    first_half_valid = []
    for p in opt_ps:
        degrees = [0]*6
        for i in range(3):
            degrees[i] += 1
            degrees[p[i]] += 1
        first_half_valid.append(degrees == [1]*6)
    assert not any(first_half_valid)
    out = {
        'status': 'PASS_EXACT_COORDINATOR_CHECK_NOT_INDEPENDENT_AUDIT',
        'channels': [[str(v) for v in h] for h in channels],
        'squared_correlations': [[str(v) for v in row] for row in rho],
        'matching_count': len(ms), 'permutation_count': len(ps),
        'exp_best_matching_sum_nats': str(best_m[0]),
        'exp_best_assignment_sum_nats': str(best_a[0]),
        'best_matching_zero_based': best_m[1],
        'best_assignment_zero_based': best_a[1],
        'all_four_assignment_optima_fail_involution_and_first_half_rule': True,
        'exp_normalized_gap': str(F(49,48)**2),
        'illustrative_gap_nats': 2*math.log(49/48),
        'scope': 'Eq8 disjoint pairing versus unrestricted assignment; not Eq11 expanded schedule',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    dest = Path(__file__).with_name('pairing-assignment-check.json')
    dest.write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
