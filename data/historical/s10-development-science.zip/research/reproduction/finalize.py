# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,re,sys
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[2];D=R/'research/reproduction'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# Preserve author sources and pin artifacts. No reference data loaded via pickle.
original=json.loads((R/'research/code-review/new-source-manifest.json').read_text())
for e in original:assert sha(R/e['path'])==e['sha256'],e['path']
res=json.loads((D/'results.json').read_text());mimic=json.loads((D/'mimic-results.json').read_text())
files=[p for p in D.iterdir() if p.is_file() and p.suffix in ('.npz','.keras','.py','.json','.txt','.md') and p.name!='run-manifest.json']
(D/'run-manifest.json').write_text(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'original_source_hashes':'all unchanged','files':[{'path':p.relative_to(R).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in files]},indent=2))
summary='\n'.join(f'| {k} | {v["mean_net_se"]:.6f} | {v["mean_nmse"]:.6f} |' for k,v in res['summary'].items())
(D/'REPORT.md').write_text('''# گزارش بازتولید اصلاح‌شده S02

داده از مسیر اعلامی کاربر DeepMIMO_sena/O1_60 خوانده شد؛۴ AP و۱۸۱۰۰ موقعیت، کانال مختلط۳۲آنتن تجمیعی و۲ زیرحامل. داده مصنوعی جایگزین نشده؛ augmentation GAN صریحاً مصنوعی و فقط train است. محیط موجود با نسخه‌های ثبت‌شده، CPU و بدون نصب/تغییر استفاده شد. اصل کدها طبق SHA256 محفوظ است.

این اجرای محدود، بازپیاده‌سازی اصلاح‌شده است؛ منحنی‌ها و اعداد مقاله‌ها یا weights تاریخی بازتولید نشده‌اند. ابتدا API قدیمی بی‌اثر تشخیص داده شد؛ خروجی صحیح با assertions و کلیدهای واقعی دوباره تولید شد. پرونده params و source manifest مبناست. بسته داده/مدل/نتایج/تقسیم و نسخه‌ها ذخیره شده‌اند؛ همه روش‌ها آموزش واقعی داشته‌اند.

| روش/پایلوت | میانگین SE خالص | میانگین NMSE |
|---|---:|---:|
'''+summary+f'\n\nMLP accuracy روی۴۰شبکه مستقل از train: {mimic["accuracy"]:.4f}؛ همه خروجی‌ها از۶عمل شدنی انتخاب شدند. این accuracy معادل سود نرخ نیست؛ نرخ teacher/fixed/mimic در mimic-results.json است.\n'+'''
آزمون‌ها: LS بدون نویز، تعامد پایلوت، نرخ بسته تک‌کاربر، حساسیت نرخ به H واقعی، تطبیق MILP با enumeration، residual و LP bound پاس شدند. نتایج عددی تک‌سناریویی و توسعه‌ای‌اند؛ هیچ نتیجه آماری تعمیم‌پذیر، کالیبراسیون، پوشش outage یا ادعای نوآوری از آن‌ها گرفته نمی‌شود. GAN هزینه آموزش اضافه دارد و مقایسه هم‌هزینه کل نیست. جزئیات محدودیت/بودجه در PROTOCOL.md.

سقف oracle به همان فضای تصمیم/گیرنده و تعریف نرخ مربوط است. میانگین test برای تنظیم مجدد مدل استفاده نشده. مسیر بعد بررسی مستقل و سپس پروتکل آزمایش گسترده با seeds/scenarios جدا است؛ این داده تست نباید برای انتخاب مدل استفاده شود.
''',encoding='utf8')
sys.path.insert(0,str(R/'research/tools'));from bundle_tools import install
dst=R/'audit/staging/B010';dst.mkdir()
for n in ('plan.md','tasks.md','checkpoints.md'):
 s=(R/n).read_text(encoding='utf8').replace('Bundle-Revision: B009','Bundle-Revision: B010')
 s=re.sub(r'^Updated-At: .*',f'Updated-At: {datetime.now(timezone.utc).isoformat()}',s,count=1,flags=re.M) if False else s
 # same timestamp across bundle
 (dst/n).write_text(s,encoding='utf8')
stamp=datetime.now(timezone.utc).isoformat()
for n in ('plan.md','tasks.md','checkpoints.md'):
 s=(dst/n).read_text(encoding='utf8');s=re.sub(r'^Updated-At: .*',f'Updated-At: {stamp}',s,count=1,flags=re.M)
 if n=='tasks.md':
  for tid in ('T-R01','T-R02','T-R03','T-R04'):
   pat=r'(### '+tid+r' .*?)(?=\n### |\Z)'
   s=re.sub(pat,lambda m:re.sub(r'^Task-Status: .*','Task-Status: READY_FOR_AUDIT',m[0],flags=re.M),s,flags=re.S)
 if n=='checkpoints.md':
  a=s.index('### CP-S02');b=s.index('### CP-S03',a)
  s=s[:a]+s[a:b].replace('Stage-State: IN_PROGRESS','Stage-State: UNDER_AUDIT').replace('Implemented-Unverified: 0','Implemented-Unverified: 4')+s[b:]
  s+='\n## ادامه B010\nS02 چهار task آماده ممیزی هستند؛ dataset واقعی، baselineهای LS/LMMSE/CNN/CNN+GAN، solver و MLP اصلاح‌شده اجرا شدند. شواهد research/reproduction؛ task acceptance هنوز مستقل نشده. CP-S02-A01 اولین تلاش از۲؛ مرحله بعد قبل از PASS و گزارش ممنوع. هیچ ادعای بازتولید عددی مقاله/نوآوری وجود ندارد.\n'
 (dst/n).write_text(s,encoding='utf8')
print(install(dst));print(summary)
