"""Corrected bounded replication, not a reproduction of published numerical curves."""
import os
os.environ['CUDA_VISIBLE_DEVICES']='-1'
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
os.environ['TF_DETERMINISTIC_OPS']='1'
from pathlib import Path
import json,itertools,time,hashlib
import numpy as np
from scipy.optimize import milp,linprog,Bounds,LinearConstraint
import tensorflow as tf
R=Path(__file__).resolve().parent
SEED=20261030
np.random.seed(SEED);tf.random.set_seed(SEED)
tf.config.threading.set_intra_op_parallelism_threads(4)
tf.config.threading.set_inter_op_parallelism_threads(2)
rng=np.random.default_rng(SEED)
NOISE=0.1;COHERENCE=200;EPOCHS=30

def pilots(tau,u=4):
 return np.exp(2j*np.pi*np.arange(tau)[:,None]*np.arange(u)[None,:]/tau)

def observe(h,tau,noise,r):
 x=pilots(tau,h.shape[1])
 n=(r.normal(size=(len(h),tau,h.shape[2]))+1j*r.normal(size=(len(h),tau,h.shape[2])))*np.sqrt(noise/2)
 y=np.einsum('tu,nuf->ntf',x,h)+n
 return np.einsum('ut,ntf->nuf',np.linalg.pinv(x),y)

def features(h):return np.stack([h.real,h.imag],-1).astype('float32')
def complex_(x):return x[...,0]+1j*x[...,1]

def rates(h,hhat,users,s,noise=NOISE):
 # h shape users x antennas x resource. Combiner is fixed by estimated CSI.
 ht=h[list(users),:,s].T;he=hhat[list(users),:,s].T
 v=np.linalg.solve(he@he.conj().T+noise*np.eye(he.shape[0]),he)
 coupling=np.abs(v.conj().T@ht)**2
 signal=np.diag(coupling);den=coupling.sum(1)-signal+noise*np.sum(np.abs(v)**2,axis=0)
 return np.log2(1+np.divide(signal,den,out=np.zeros_like(signal),where=den>0))

GROUPS=[g for k in (1,2) for g in itertools.combinations(range(4),k)]
CAND=[(g,s) for s in range(2) for g in GROUPS]
A=np.zeros((6,len(CAND)))
for j,(g,s) in enumerate(CAND):A[list(g),j]=1;A[4+s,j]=1
LOW=np.array([1]*4+[0]*2);HIGH=np.ones(6)

def allocate(scores):
 integer=milp(-scores,integrality=np.ones(len(scores)),bounds=Bounds(0,1),constraints=LinearConstraint(A,LOW,HIGH),options={'time_limit':10,'mip_rel_gap':0})
 if integer.status!=0 or integer.x is None:raise RuntimeError(f'MILP uncertified: {integer.message}')
 d=np.rint(integer.x);assert np.max(np.abs(integer.x-d))<1e-6
 assert np.all(A@d>=LOW-1e-8) and np.all(A@d<=HIGH+1e-8)
 lp=linprog(-scores,A_ub=A[4:],b_ub=HIGH[4:],A_eq=A[:4],b_eq=HIGH[:4],bounds=(0,1),method='highs')
 assert lp.success and -lp.fun>=scores@d-1e-7
 return d,float(-lp.fun),float(integer.mip_gap)

def tests():
 h=np.array([[[1+2j,2-1j],[3j,1],[2,1j],[1-1j,3]]])
 assert np.allclose(observe(h,4,0,np.random.default_rng(1)),h)
 assert np.allclose(pilots(8).conj().T@pilots(8),8*np.eye(4))
 one=np.ones((1,1,1),complex)
 assert np.allclose(rates(one,one,(0,),0),np.log2(11))
 assert rates(one*2,one,(0,),0)>rates(one,one,(0,),0)
 q=np.arange(20,dtype=float)**2;d,ub,gap=allocate(q)
 exhaustive=max(q[i]+q[j] for i,(g,s) in enumerate(CAND) for j,(g2,s2) in enumerate(CAND) if s!=s2 and len(g)==len(g2)==2 and not set(g)&set(g2))
 assert abs(q@d-exhaustive)<1e-8
 return {'noiseless_LS':True,'pilot_orthogonality':True,'single_user_rate':True,'true_channel_affects_rate':True,'MILP_vs_enumeration':True,'residual_and_LP_bound':True}

def cnn():
 inp=tf.keras.Input((64,2));x=tf.keras.layers.Conv1D(16,3,padding='same',activation='relu')(inp)
 x=tf.keras.layers.Conv1D(16,3,padding='same',activation='relu')(x)
 correction=tf.keras.layers.Conv1D(2,1,padding='same',kernel_initializer='zeros')(x)
 model=tf.keras.Model(inp,inp+correction);model.compile(optimizer=tf.keras.optimizers.Adam(0.001),loss='mse');return model

def main():
 start=time.time();checks=tests();data=np.load(R/'channels.npz');h=data['H'];loc=data['location']
 assert h.shape[1:]==(4,8,2)
 h=h.reshape(len(h),32,2).reshape(len(h),64)
 order=np.lexsort((loc[:,0],loc[:,1]));n=len(order)
 bands={'train':(0,.50,800),'validation':(.55,.68,160),'calibration':(.73,.83,160),'test':(.88,1,160)}
 ids={}
 for name,(a,b,k) in bands.items():
  pool=order[int(n*a):int(n*b)];assert len(pool)>=k
  ids[name]=rng.choice(pool,k,replace=False).reshape(-1,4)
 assert len(set(np.concatenate([v.ravel() for v in ids.values()])))==sum(v.size for v in ids.values())
 scale=float(np.sqrt(np.mean(np.abs(h[ids['train']])**2)));assert scale>0
 hh={k:h[ix]/scale for k,ix in ids.items()}
 np.savez_compressed(R/'split-indices.npz',**ids)
 np.savez_compressed(R/'normalization.npz',train_rms=scale)
 train=hh['train'];val=hh['validation']
 taus_train=rng.choice([4,8],len(train));xtrain=np.concatenate([observe(train[i:i+1],int(t),NOISE,rng) for i,t in enumerate(taus_train)])
 xval=observe(val,4,NOISE,rng)
 X=features(xtrain).reshape(-1,64,2);Y=features(train).reshape(-1,64,2)
 V=features(xval).reshape(-1,64,2);T=features(val).reshape(-1,64,2)
 base=cnn();hist=base.fit(X,Y,validation_data=(V,T),epochs=EPOCHS,batch_size=32,verbose=0)
 base.save(R/'cnn.keras')
 # Unconditional channel GAN: train partition only. Generated H is the target;
 # its noisy pilot observation is regenerated, never labelled with mean H.
 gen=tf.keras.Sequential([tf.keras.layers.Input((16,)),tf.keras.layers.Dense(64,activation='relu'),tf.keras.layers.Dense(128)])
 disc=tf.keras.Sequential([tf.keras.layers.Input((128,)),tf.keras.layers.Dense(64,activation='relu'),tf.keras.layers.Dense(1)])
 og=tf.keras.optimizers.Adam(.0002);od=tf.keras.optimizers.Adam(.0002);bce=tf.keras.losses.BinaryCrossentropy(from_logits=True)
 for epoch in range(30):
  for _ in range(25):
   real=tf.convert_to_tensor(Y[rng.choice(len(Y),32)].reshape(32,128));z=tf.random.normal((32,16))
   with tf.GradientTape() as gd,tf.GradientTape() as dd:
    fake=gen(z);dr=disc(real);df=disc(fake);dl=bce(tf.ones_like(dr),dr)+bce(tf.zeros_like(df),df);gl=bce(tf.ones_like(df),df)
   od.apply_gradients(zip(dd.gradient(dl,disc.trainable_variables),disc.trainable_variables));og.apply_gradients(zip(gd.gradient(gl,gen.trainable_variables),gen.trainable_variables))
 generated=complex_(gen(tf.random.normal((400,16))).numpy().reshape(100,4,64,2))
 gx=observe(generated,4,NOISE,rng)
 # Equal 800 examples and equal training steps; 50% real / 50% GAN.
 augX=np.concatenate([X[:400],features(gx).reshape(-1,64,2)])
 augY=np.concatenate([Y[:400],features(generated).reshape(-1,64,2)])
 aug=cnn();ha=aug.fit(augX,augY,validation_data=(V,T),epochs=EPOCHS,batch_size=32,verbose=0)
 aug.save(R/'cnn_gan.keras');gen.save(R/'channel_gan.keras')
 flat=train.reshape(-1,64);mean=flat.mean(0);center=flat-mean
 cov=center.T@center.conj()/len(center)
 rows=[]
 for tau in (4,8):
  truth=hh['test'];obs=observe(truth,tau,NOISE,rng)
  filt=np.linalg.solve(cov+NOISE/tau*np.eye(64),cov).T
  lmmse=(obs-mean)@filt+mean
  estimates={'LS':obs,'LMMSE':lmmse,'CNN':complex_(base.predict(features(obs).reshape(-1,64,2),verbose=0)).reshape(obs.shape),'CNN_GAN':complex_(aug.predict(features(obs).reshape(-1,64,2),verbose=0)).reshape(obs.shape),'Oracle':truth}
  prelog=(COHERENCE-tau)/COHERENCE/2
  for name,est in estimates.items():
   for i,(ht,he) in enumerate(zip(truth,est)):
    ht=ht.reshape(4,32,2);he=he.reshape(4,32,2)
    before=time.perf_counter();scores=np.array([prelog*rates(he,he,g,s).sum() for g,s in CAND]);d,ub,gap=allocate(scores)
    user_rates=np.zeros(4)
    for j,(g,s) in enumerate(CAND):
     if d[j]:user_rates[list(g)]=prelog*rates(ht,he,g,s)
    rows.append({'method':name,'tau':tau,'network':i,'nmse':float(np.sum(abs(he-ht)**2)/max(np.sum(abs(ht)**2),1e-30)),'net_se':float(user_rates.sum()),'min_user_se':float(user_rates.min()),'user_rates':user_rates.tolist(),'nominal_objective':float(scores@d),'lp_upper':ub,'mip_gap':gap,'solver_and_rate_seconds':time.perf_counter()-before,'decision':d.tolist()})
 summary={f'{name}_tau{tau}':{'mean_net_se':float(np.mean([x['net_se'] for x in rows if x['method']==name and x['tau']==tau])),'mean_nmse':float(np.mean([x['nmse'] for x in rows if x['method']==name and x['tau']==tau]))} for name in estimates for tau in (4,8)}
 (R/'results.json').write_text(json.dumps({'checks':checks,'seed':SEED,'noise':NOISE,'coherence_symbols':COHERENCE,'train_only_scale':scale,'split_network_counts':{k:len(v) for k,v in ids.items()},'seconds':time.time()-start,'summary':summary,'rows':rows,'history_cnn':hist.history,'history_cnn_gan':ha.history,'scope':'bounded corrected replication; not published-curve reproduction; calibration reserved unused; no conformal guarantee; SE proxy not decoded goodput'},indent=2))
 print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
