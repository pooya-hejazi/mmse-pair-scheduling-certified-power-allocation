"""Pre-specify a new untouched confirmation sample; do not run that test here."""
from pathlib import Path
import json,math
import numpy as np
from scipy.stats import norm,t
R=Path(__file__).resolve().parent
rows=json.loads((R/'results.json').read_text())['rows']
a={r['network']:r['net_se'] for r in rows if r['tau']==4 and r['method']=='CNN'}
b={r['network']:r['net_se'] for r in rows if r['tau']==4 and r['method']=='LMMSE'}
delta=np.array([a[k]-b[k] for k in sorted(a)])
sd=float(delta.std(ddof=1));N=120
result={'protocol_id':'S02-FORWARD-1','status':'LOCKED_NOT_EXECUTED','primary':'paired mean net-SE CNN minus LMMSE at tau=4','N_networks':N,'alpha':.05,'confidence':.95,'alternative':'two-sided confidence interval, claim improvement only if lower limit > 0','practical_effect_threshold':0,'threshold_rationale':'break even in net-SE after identical explicitly modeled overhead and resource budgets; only MVP utility, not deployment utility','pilot_difference_sd':sd,'projected_CI_halfwidth':float(t.ppf(.975,N-1)*sd/math.sqrt(N)),'approx_MDE_at_80percent_power':float((norm.ppf(.975)+norm.ppf(.8))*sd/math.sqrt(N)),'sample_rule':'fixed120 independent networks within400-network budget including200train40validation40reserved calibration; no optional stopping; pilot variance is projection not guaranteed power','seed_network':20261101,'seed_noise':20261102,'held_out_rows':[101,200],'source_scenario':'O1_60','conditional_scope':'expected utility for independent location/noise draws on this fixed scene only'}
(R/'forward-design.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
