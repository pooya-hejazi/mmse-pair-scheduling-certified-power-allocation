"""Feasible categorical imitation baseline, sharing the frozen CNN and test observations."""
import baselines as b
import numpy as np,json,time
from pathlib import Path
R=b.R
data=np.load(R/'channels.npz')['H'].reshape(-1,64)
ids=np.load(R/'split-indices.npz');scale=float(np.load(R/'normalization.npz')['train_rms'])
old=json.loads((R/'results.json').read_text())
cnn=b.tf.keras.models.load_model(R/'cnn.keras',compile=False)
# Six complete feasible assignments; every user served once, two per resource.
actions=[]
for g in __import__('itertools').combinations(range(4),2):
 other=tuple(u for u in range(4) if u not in g);d=np.zeros(20)
 d[b.CAND.index((g,0))]=1;d[b.CAND.index((other,1))]=1;actions.append(d)
actions=np.array(actions);assert np.allclose(actions@b.A.T,np.ones((6,6)))
def prepare(split):
 truth=data[ids[split]]/scale
 obs=b.observe(truth,4,b.NOISE,np.random.default_rng(b.SEED+{'train':1,'validation':2,'test':3}[split]))
 est=b.complex_(cnn.predict(b.features(obs).reshape(-1,64,2),verbose=0)).reshape(obs.shape)
 scores=np.array([[sum(b.rates(h.reshape(4,32,2),h.reshape(4,32,2),g,s)) for g,s in b.CAND] for h in est])
 return truth,est,b.features(est).reshape(len(est),-1),np.argmax(scores@actions.T,axis=1)
ht,he,x,y=prepare('train');vt,ve,vx,vy=prepare('validation')
model=b.tf.keras.Sequential([b.tf.keras.layers.Input((512,)),b.tf.keras.layers.Dense(64,activation='relu'),b.tf.keras.layers.Dense(6)])
model.compile(optimizer='adam',loss=b.tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
history=model.fit(x,y,validation_data=(vx,vy),epochs=30,batch_size=32,verbose=0)
model.save(R/'mimic.keras')
truth,est,tx,ty=prepare('test');pred=np.argmax(model.predict(tx,verbose=0),axis=1)
rows=[]
for i,(h,e) in enumerate(zip(truth,est)):
 h=h.reshape(4,32,2);e=e.reshape(4,32,2)
 for method,a in [('Mimic',pred[i]),('Teacher',ty[i]),('Fixed',0)]:
  d=actions[a];rr=np.zeros(4)
  for j,(g,s) in enumerate(b.CAND):
   if d[j]:rr[list(g)]=(200-4)/200/2*b.rates(h,e,g,s)
  rows.append({'network':i,'method':method,'net_se':float(sum(rr)),'rates':rr.tolist(),'action':int(a)})
(R/'mimic-results.json').write_text(json.dumps({'seed':b.SEED,'tau':4,'independent_observation_stream':'shared within this comparison only; do not pair with results.json','accuracy':float(np.mean(pred==ty)),'all_decisions_feasible':True,'history':history.history,'rows':rows},indent=2))
print('mimic accuracy',float(np.mean(pred==ty)))
