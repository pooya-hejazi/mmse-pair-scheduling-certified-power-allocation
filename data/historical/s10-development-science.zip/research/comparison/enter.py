from pathlib import Path
from datetime import datetime,timezone
import re,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'research/tools'));from bundle_tools import install
dst=R/'audit/staging/B025';dst.mkdir();stamp=datetime.now(timezone.utc).isoformat()
for n in ['plan.md','tasks.md','checkpoints.md']:
 s=(R/n).read_text(encoding='utf8').replace('Bundle-Revision: B024','Bundle-Revision: B025');s=re.sub(r'^Updated-At: .*','Updated-At: '+stamp,s,count=1,flags=re.M)
 if n=='plan.md':s+='\n## CR-008 execution continuation\nUser explicitly requested deadline remediation and equal-budget continuous-power/I-WMMSE and information comparisons. Existing planned scope REQ003/005/006/009/011/012, T-G01..03 and T-A02..04; no new goal or accepted scientific claim. Bounded prospective packet research/comparison/PROTOCOL.md is authoritative for this new run only; older failed runs retained. Development comparisons may overlap S03/S03G; S04 stays locked. No installation or original-code changes.\n'
 if n=='tasks.md':
  s=s.replace('Components: research/gpu؛','Components: research/gpu و research/comparison؛')
  s+='\nProgress B025: new execution packet for existing remediation/continuous baseline tasks; T-G02 remains NEEDS_REWORK until evidence, no VERIFIED increment.\n'
 if n=='checkpoints.md':s+='\n## resume B025\nCR008 is a bounded execution packet within accepted CR007 scope, not a new planning checkpoint or reset of audit limits. S03/S03G independent audit each0/2; S04 locked. Next: implement process watchdog, correctness tests, then frozen protocol comparisons. No background job currently running.\n'
 (dst/n).write_text(s,encoding='utf8')
print(install(dst))
