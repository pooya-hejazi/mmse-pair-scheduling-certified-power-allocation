"""Render the completed observations without treating the interrupted case as successful."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent;d=json.loads((R/'results.json').read_text())
s='''# Measured power / rate / optimization results

One development instance per size, O1_60 rows1..100, four APs × eight antennas, known CSI, all UE pairs and nine power profiles. Original S02 files and future reserved test are unchanged. Units and excluded network features are in MODEL.md. These are author-checked results, not independently accepted research conclusions.

## Throughput under the same transmit-power budget

| UEs | Columns | Occupied MHz | Power budget W | Fixed-power optimum Mbps | Joint-power IP Mbps | Joint-power LP Mbps | LP−IP Mbps |
|---:|---:|---:|---:|---:|---:|---:|---:|
'''
for r in d['rows']:
 a=r['fixed_power_MILP']['rate_Mbps'];b=r['joint_power_MILP']['rate_Mbps'];c=r['joint_power_LP']['rate_Mbps']
 s+=f"|{r['users']}|{r['columns']}|{r['occupied_BW_MHz']:.2f}|{r['power_budget_W']:.2f}|{a:.6f}|{b:.6f}|{c:.6f}|{c-b:.6f}|\n"
s+='''
All displayed CPU IP/LP solves terminated optimally at the recorded numerical tolerances. The power-grid method did not improve throughput over fixed power in these three instances. At 32 users, the nonzero LP gap directly refutes universal exactness for this formulation; zero gaps in smaller examples are not a general theorem. Occupied bandwidth changes with network size, so the larger aggregate rates must not be interpreted as algorithmic gain across sizes.

## Minimum power at 95% of the fixed-power incumbent's throughput

| UEs | Target Mbps | Achieved Mbps | Reference W | Minimum grid-IP W | LP lower bound W | Transmit-power reduction |
|---:|---:|---:|---:|---:|---:|---:|
'''
for r in d['rows']:
 p=r['minimum_power_MILP'];l=r['minimum_power_LP'];base=r['fixed_power_MILP']['power_W']
 s+=f"|{r['users']}|{r['minimum_power_target_Mbps']:.6f}|{p['rate_Mbps']:.6f}|{base:.2f}|{p['power_W']:.2f}|{l['power_W']:.6f}|{100*(1-p['power_W']/base):.2f}%|\n"
s+='''
This is a rate–power tradeoff against an unoptimized fixed-power reference at a **lower requested rate**, not a 25% efficiency gain at identical throughput and not superiority over a power-control paper. Continuous uniform/fixed-schedule power control, WMMSE/SCA and grid-refinement baselines are still needed to identify any added value from joint decisions. Circuit/fronthaul/compute energy is not included.

## Solver timing and GPU behavior

| UEs | CPU joint LP s | CPU joint MILP s | GPU PDHG iteration/check s | GPU status | Maximum constraint violation |
|---:|---:|---:|---:|---|---:|
'''
for r in d['rows']:
 g=r['GPU_PDHG'];s+=f"|{r['users']}|{r['joint_power_LP']['solve_seconds']:.4f}|{r['joint_power_MILP']['solve_seconds']:.4f}|{g['iteration_and_check_seconds']:.4f}|{g['status']}|{g['violation']:.6g}|\n"
s+='''
The 8-user first sparse GPU execution included JIT/library startup not removed by the coefficient warmup. Its 54.1s time exceeded the nominal30s check budget before the first200-iteration check. It is not a valid steady-state speed comparison. At16 users the GPU met tolerance but was slower than CPU; at32 it failed to meet feasibility tolerance in30s. Its objective at an infeasible iterate is **not a feasible rate**. The dual upper bound remains a separate numerical bound. No GPU speedup or GPU exact-MILP claim is supported.

| UEs | CPU coefficient ms | GPU kernel ms | H2D+D2H ms | Max CPU/GPU coefficient difference |
|---:|---:|---:|---:|---:|
'''
for r in d['rows']:
 c=r['coefficients'];s+=f"|{r['users']}|{1000*c['CPU_seconds']:.4f}|{1000*c['GPU_kernel_seconds']:.4f}|{1000*(c['H2D_seconds']+c['D2H_seconds']):.4f}|{c['max_abs_error_SE']:.3g}|\n"
s+='''
CPU and GPU coefficients agreed well within1e−8. For32 users, GPU kernel time alone was slightly lower than CPU, but adding transfers removed that advantage; one timing sample is insufficient for a stable speed estimate.

## The 64-user run did not complete

The full family contains580,608 variables. The coordinator stopped its process after the aggregate run exceeded the expected per-call budget; no64-user objective was saved. Exact blocking stage is unknown because per-call logging was missing. Peak observed process working set was2,044,841,984 bytes, below the8GiB host cap; OOM was not observed. The run ended with exit1 and results.json remains an incremental artifact, not a successful full-run artifact. See interruption.json. Neither a64-user solution nor a runtime success is claimed.

The new bounded_process.py guard passes separate success, failure and wall-timeout tests, but is not yet integrated into a new solver worker. Historical benchmark code and pre-run hashes remain fixed. A future run must use isolated workers, checkpoint each call, warm sparse operations explicitly, persist LP primal/dual vectors, and compare equal tolerances. No failed size was rerun with a larger budget.

## Scientific decision

Do not write a positive performance paper from this pilot. Continue only the sharper candidate: uncertainty-aware joint scheduling/power decisions with instance-specific optimality or regret certificates and explicit information/compute costs. Matching and duality are established tools; the certificate in MODEL.md is not claimed novel by itself. The selective-information studies remain mostly negative, and the new maximum-rate power study is also negative. A defensible next experiment must test whether realistic AP/fronthaul restrictions, user geometry and QoS create useful decision uncertainty, without selecting a favorable scenario after seeing results. A traceable continuous-power baseline and independent network samples are mandatory before any publication claim.

S03 and S03G are not accepted; S04 confirmatory experiments remain locked. Planning acceptance is not scientific acceptance.
'''
(R/'REPORT.md').write_text(s,encoding='utf8')
print('Wrote REPORT.md from three completed sizes;64-user interruption retained')
