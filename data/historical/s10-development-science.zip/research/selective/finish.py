"""One-time coherent B017 progress update; no checkpoint acceptance."""
from pathlib import Path
from datetime import datetime,timezone
import json,re,hashlib,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[1]
h=json.loads((R/'headroom-results.json').read_text());p=json.loads((R/'prototype-results.json').read_text());v=json.loads((R/'verification.json').read_text())
lines=['# نتیجه بسته CR005 — مدل ترکیبی با محور بهینه‌سازی','',
'دو بخش درخواست اجرا شد: پیشینه و ظرفیت بهبود بررسی شد؛ سپس پس از gate مثبت، prototype پایلوت انتخابی با LMMSE ثابت و baselineهای هم‌بودجه ساخته و یک‌بار اجرا شد. هیچ کد اصلی تغییر نکرد و هیچ مدل تخمین تازه آموزش داده نشد.','',
'نتیجه اجرایی: سیاست joint در۶زمینه از۱۸زمینه نسبت به بهترینِ round-robin/random/weakest میانگین خام بالاتری داشت؛ در۱۲زمینه بهتر نبود. دامنه اختلاف حدود−۰٫۰۷۱۵ تا+۰٫۰۱۳۶bit/s/Hz بود. این اختلاف‌ها اکتشافی‌اند و معنی‌داری/تعمیم یا مزیت end-to-end را ثابت نمی‌کنند. افزایش training یا tuning این سیاست فعلاً توصیه نمی‌شود.','',
'## مرز ILP–LP','',
'در headroom از۷۲۰نمونه، %d نمونه شکاف مثبت بیش از۱e−7 داشت. شاهد ذخیره‌شده از دوآنتن/AP، کاربران نزدیک وnoise=.1:'%sum(x['positive_LP_gap_count'] for x in h['summary']),'',
'| مدل | مقدار هدف nominal |','|---|---|',
'| ILP / enumeration | %.9f |'%v['physical_witness']['ILP'],
'| LP عادی | %.9f |'%v['physical_witness']['ordinary_LP'],
'| LP با قیود مکمل دقیقِ چهارUE/دوRB | %.9f |'%v['physical_witness']['strengthened_LP'],'',
'شکاف۰٫۴۸۹۸ در تابع هدف nominal است، نه افزایش نرخ واقعی کاربران. تخمین مختلط، ids، امتیازها و جواب کسری درJSON موجودند. این شاهد عددی کانال‌مبنا از مثال abstract قبلی قوی‌تر است، اما اثبات symbolic سختی کل خانواده فیزیکی نیست.','',
'OPTIMIZATION.md دو نتیجه دقیق دامنه‌دار دارد: (۱) قیود مکمل برای چهارUE/دوRB hull شش تخصیص را می‌دهند؛ (۲) در خانواده کانال متعامد، هدف جمع‌پذیر و مسئله assignment LP دقیق است. برای حالت غیرمتعامد، loss زوجی از هندسه کانال محاسبه و gap با مجموع کران‌های interaction کنترل می‌شود. اجزای این استدلال استانداردند؛ novelty هنوز بررسی کامل نشده و حل عمومی NP-hard چندجمله‌ای ادعا نمی‌شود.','',
'## مقایسه هم‌بودجه','',
'هر سیاست۴سمبل پایه برای همهUE و۱سمبل/انرژی۱برایUEمنتخب می‌گیرد؛ مجموع انرژی۱۷. یک سمبل برای چهار پایلوت متعامد کم‌انرژی کافی نیست، بنابراین uniform به‌صورت round-robin یا randomUE با همان هزینه اجرا شد؛ نام uniform-energy با مشاهده غیرممکن استفاده نشد. weakest-channel baseline ساده سوم است. decision-only وreceiver-only ablation هستند. روش Kang توقف متغیر دارد و در این fixed-one-probe task به عنوان بازتولید هم‌بودجه معرفی نشده؛ نتایج probing ثابت قبلی مرجع جدا باقی‌اند.','',
'| آنتن/AP | چیدمان | نویز | joint−best baseline خام | زمان scoring میانه(ms) |','|---|---|---|---|---|']
for s in p['summary']:lines.append('| %s | %s | %s | %+.6f | %.2f |'%(s['ant'],s['geometry'],s['noise'],s['joint_minus_best_baseline_raw'],1000*s['score_seconds_median']))
lines+=['',
'همه روش‌ها همان prelog=(1−5/T) دارند؛ اختلاف‌های جدول برایT=200 در۰٫۹۷۵ ضرب می‌شوند. زمان scoring فقط بخش انتخاب اطلاعات است و شامل همه هزینه‌های سیستم نیست. برتری اندک باید هزینه اضافی را پوشش دهد: اگر نرخ خام روشr وbaseline برابرb باشد، با فرض زمانbaseline صفر، حداکثر تأخیر مجاز اضافی برحسب سمبل (T−5)(r−b)/r است. بدون نرخ سمبل مستند، تبدیل زمانCPU به این واحد و ادعای realtime مجاز نیست.','',
'تعداد داده:۷۲۰مسیر برایheadroom و۷۲۰مسیر تازه برایprototype؛۴۳۲۰outcome سیاست روی۷۲۰مسیر مشترک. تعداد۱۸زمینه از۳آنتن×۲هندسه×۳نویز است. Tها فقط prelogهای مختلف همان مسیرند و نمونه مستقل جدید نیستند. انتخاب نزدیک‌ترینUE فقط با مکان انجام شد، نه با هدف واقعی. همه داده‌ها ازpooldevelopment همان نقشه‌اند؛ آزمون رزرو۱۰۱..۲۰۰ استفاده نشد.','',
'## پیشینه و فایل‌های لازم','',
'LITERATURE.md نشان می‌دهد joint probing/scheduling و pairing چندجمله‌ای در زیرکلاس‌ها پیشینه دارند. دو متن کامل برای ممیزی دقیق لازم است که دریافت مستقیم آن‌ها موفق نبود:','',
'1. [Scalable Cell-Free Massive MIMO System: Joint Optimal Pilot and Access Point Assignment](https://doi.org/10.1109/ACCESS.2025.3638655)، اولویت۱: مقایسه relaxation،BCD و ادعای polynomial.','2. [Optimal User Pairing for Multiuser MIMO، ISSSTA2008](https://engit.monash.edu/profiles/wp-content/uploads/2017/09/isssta08b.pdf)، اولویت۲: مقایسه دقیق matching/assignment وگیرندهMMSE.','',
'برای این دو متن هنوز equivalence یا novelty ادعا نمی‌شود. کار محاسباتی مستقل از دریافت آن‌ها انجام شده؛ فایلPDF قابل افزودن بهdocs است.','',
'## شواهد و تصمیم ادامه','',
'verify_optimization.py: MILP/enumeration/LPتقویت‌شده روی۱۰۰هدف تصادفی وwitness، replay۴۳۲۰outcome، هم‌ارزی updateLMMSE با sufficient statistic، هویت interaction loss وکران آن روی۱۰۰کانال تصادفی ویک حالت متعامد؛ همهPASS. check_portable.py بدون داده خارجی۱۰۱هدف را بررسی کرد. این author verification است و جای ممیز مستقل را نمی‌گیرد. hashهایS02 همگی ثابت‌اند.','',
'تصمیم: prototype اطلاعات انتخابی فعلاً candidate مقاله برتر نیست؛ توسعه تخمین‌گر متوقف می‌ماند. ادامه موجه روی سه موضوع متمرکز شود: مطالعهPDFهای نزدیک، بسط ساختار دقیق/کران شکاف به مدل کاربردی بزرگ‌تر، و سیاست انتخاب میان LP/حل صحیح/اطلاعات بیشتر بر اساس همان گواه. اگر ساختار/سازوکار جدیدی نسبت بهpriorart پیدا نشود، novelty ادعا نشود.','',
'S03 هنوزIN_PROGRESS؛ چهارtask آن پذیرفته نشده‌اند، CP-S03=۰/۲. خروجی‌ها reviewable هستند ولی مرحله پایان نیافته وS04باز نشده است. محدودیت‌های باقی:گواه آماری سیاست جدید، solver timeout/infeasible درمقیاس بزرگ، پروفایل کامل هزینه و fulltext novelty. انتشار در شاخه پژوهشی مخزن صرفاً نگهداری پیشرفت است، نه پذیرش علمی یا انتشار مقاله.']
(R/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
(ROOT/'research/ROADMAP.md').write_text('# Research progress\n\nThis branch preserves the original code and adds a separate exploratory study. Start with [the selective study](selective/README.md), [results](selective/REPORT.md), [optimization model and exactness conditions](selective/OPTIMIZATION.md), and [prior-art ledger](selective/LITERATURE.md).\n\nS01 mathematical baseline and S02 corrected bounded reproduction were accepted locally. S03 is IN_PROGRESS, not independently accepted; S04 confirmatory experiments have not started. Current results do not establish a publishable novelty or a general polynomial-time ILP solver. The estimator is fixed; next work is optimization structure, integrality/gap bounds, and the value of information within the combined model. Full local planning/audit history remains in the project workspace.\n',encoding='utf8')
sys.path.insert(0,str(ROOT/'research/tools'));from bundle_tools import install
dst=ROOT/'audit/staging/B017';dst.mkdir();stamp=datetime.now(timezone.utc).isoformat()
for name in ['plan.md','tasks.md','checkpoints.md']:
 s=(ROOT/name).read_text(encoding='utf8').replace('Bundle-Revision: B016','Bundle-Revision: B017');s=re.sub(r'^Updated-At: .*',f'Updated-At: {stamp}',s,count=1,flags=re.M)
 if name=='plan.md':s+='\nCR005نتیجه:headroomمثبت؛prototypeهم‌بودجه یکبار اجرا و مزیت پایدار نداشت. مطالعه کانال جدید وtrainingانجام نشد. مدلLPعادی روی کانال‌مبناgapمثبت، LPتقویت‌شده۴UEدقیق و زیرکلاس متعامد/کرانinteractionدرOPTIMIZATION.md؛ noveltyمعلق تاfulltext. دستور میانی کاربر مجوز قرار دادن مراحل درمخزنpooya-hejazi/6g-project و اختیارrename داد. مخزن طبقAPIاکنونprivateاست؛ نام فعلاًثابت، snapshotسبک کد/گزارش/summary درbranchجدیدresearch/selective-information-lp بدونویرایشmainیااصل‌ها منتشرشود؛ rawbinary/docsکاربر آپلودنمی‌شوند. این مجوز نگهداری پژوهش است، نه ادعای پذیرش علمی.\n'
 if name=='tasks.md':s+='\nProgress-B017: T-A02 شاهدgapفیزیکی، hullدقیق۴UE و boundinteraction؛ T-A03prototypeشش‌سیاست هم‌بودجه اجرا؛ T-A04priorartو دوPDFدرانتظار؛ T-A01هیچ تضمینcalibrationقبلی به سیاست تازه منتقل نشده. هرچهارtaskIN_PROGRESS؛ هیچVERIFIEDجدیدبدونممیزی.\n'
 if name=='checkpoints.md':s+='\n## resume B017\nCR005P2/P3پایان؛headroom۷۲۰وprototype۷۲۰،نتیجهبدونبرتریپایدار؛ CPU۳٫۷و۲۱٫۷ثانیهداخلmain، همهauthorchecksPASS. S03جاری۰/۲؛scope/gatesبدونکاهش؛۱۵/۲۵پذیرفتهقبلی. هیچprocessعلمی فعال یاoutcomeنامعلوم نیست. repoاپلودbranchپژوهشی طبق دستورکاربرمجاز ودرحالآماده‌سازی؛ receiptجدا ثبتشود. قدمبعد مطالعهPDFهای نزدیک و بسطمرزLP–ILP،بدونحلقهtraining. دوPDFدرREPORT.md؛ S04قفل.\n'
 (dst/name).write_text(s,encoding='utf8')
print(install(dst))
files=[x for x in R.iterdir() if x.is_file() and x.name not in ['RUN_MANIFEST.json','publish-payload.json','github-receipt.json']]
files += [ROOT/'research/reproduction'/n for n in ['channels.npz','split-indices.npz','normalization.npz']]
(R/'RUN_MANIFEST.json').write_text(json.dumps({'utc':stamp,'bundle':'B017','status':'AUTHOR_CHECKED_NOT_STAGE_ACCEPTED','files':[{'path':x.relative_to(ROOT).as_posix(),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted(files)]},indent=2))
