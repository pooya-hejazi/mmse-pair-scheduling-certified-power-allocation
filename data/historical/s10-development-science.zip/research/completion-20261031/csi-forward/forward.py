"""Prospective S02-FORWARD-1. Authoring/preflight is not execution approval.

preflight uses OLD development data only. run requires explicit approval token.
All output directories are new and immutable after an invocation.
"""
import os
os.environ.update(CUDA_VISIBLE_DEVICES='-1', TF_CPP_MIN_LOG_LEVEL='2',
                  TF_DETERMINISTIC_OPS='1', OMP_NUM_THREADS='1',
                  OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
import argparse, hashlib, itertools, json, math, subprocess, sys, time, traceback
import importlib.metadata as metadata
from pathlib import Path
import numpy as np
from scipy.optimize import linprog, milp, Bounds, LinearConstraint
from scipy.stats import t

HERE = Path(__file__).resolve().parent
DEFAULT_ROOT = HERE.parents[2]
N = 120
NOISE = .1
GROUPS = [g for k in (1, 2) for g in itertools.combinations(range(4), k)]
CAND = [(g, s) for s in range(2) for g in GROUPS]
A = np.zeros((6, 20))
for j, (g, s) in enumerate(CAND):
    A[list(g), j] = 1
    A[4+s, j] = 1
ACTIONS = np.zeros((6, 20))
for i, g in enumerate(itertools.combinations(range(4), 2)):
    other = tuple(u for u in range(4) if u not in g)
    ACTIONS[i, CAND.index((g, 0))] = 1
    ACTIONS[i, CAND.index((other, 1))] = 1
METHODS = ['LS', 'LMMSE', 'CNN', 'CNN_GAN', 'Oracle']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def array_sha(x):
    x = np.ascontiguousarray(x)
    return hashlib.sha256(str(x.dtype).encode()+str(x.shape).encode()+x.tobytes()).hexdigest()

def write_json(path, value):
    """Atomic, write-once checkpoint (single writer per destination)."""
    path = Path(path)
    if path.exists():
        raise FileExistsError(path)
    temporary = path.with_suffix(path.suffix+'.partial')
    with temporary.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    if path.exists():
        raise FileExistsError(path)
    temporary.rename(path)

def feature(h):
    return np.stack([h.real, h.imag], -1).astype('float32')

def complex_(x):
    return x[..., 0]+1j*x[..., 1]

def observe(h, tau, rng):
    x = np.exp(2j*np.pi*np.arange(tau)[:, None]*np.arange(4)[None, :]/tau)
    noise = (rng.normal(size=(len(h), tau, 64)) +
             1j*rng.normal(size=(len(h), tau, 64)))*np.sqrt(NOISE/2)
    y = np.einsum('tu,nuf->ntf', x, h)+noise
    return np.einsum('ut,ntf->nuf', np.linalg.pinv(x), y)

def rates(h, est, users, resource):
    ht = h[list(users), :, resource].T
    he = est[list(users), :, resource].T
    v = np.linalg.solve(he@he.conj().T+NOISE*np.eye(he.shape[0]), he)
    c = np.abs(v.conj().T@ht)**2
    signal = np.diag(c)
    den = c.sum(1)-signal+NOISE*np.sum(np.abs(v)**2, axis=0)
    return np.log2(1+np.divide(signal, den, out=np.zeros_like(signal), where=den>0))

def load_models(repro):
    import tensorflow as tf
    tf.config.threading.set_intra_op_parallelism_threads(4)
    tf.config.threading.set_inter_op_parallelism_threads(1)
    tf.random.set_seed(20261030)
    models = {name: tf.keras.models.load_model(repro/(name+'.keras'), compile=False)
              for name in ('cnn', 'cnn_gan', 'mimic')}
    return tf, models

def predict(model, x):
    # Inference mode only: no fit, optimizer updates, or retraining.
    return model(x, training=False).numpy()

def old_prior(repro):
    with np.load(repro/'channels.npz') as z:
        old_h = z['H'].reshape(-1, 64)
    with np.load(repro/'split-indices.npz') as z:
        train_ids = z['train']
    scale = float(np.load(repro/'normalization.npz')['train_rms'])
    flat = (old_h[train_ids]/scale).reshape(-1, 64)
    mean = flat.mean(0)
    center = flat-mean
    covariance = center.T@center.conj()/len(center)
    return scale, mean, covariance, old_h[train_ids[:1]]/scale

def frozen_files(root):
    repro = root/'research/reproduction'
    names = ['channels.npz', 'split-indices.npz', 'normalization.npz', 'cnn.keras',
             'cnn_gan.keras', 'channel_gan.keras', 'mimic.keras', 'baselines.py',
             'mimic.py', 'prepare_data.py', 'FORWARD_PROTOCOL.md', 'forward-design.json',
             'PROTOCOL.md', 'data-source.json', 'generation-parameters.json','environment.json']
    paths = [repro/n for n in names] + [Path(__file__).resolve(), HERE/'PROTOCOL.md']
    return {str(p.relative_to(root)).replace('\\', '/'): sha(p) for p in paths}

def preflight(root, output):
    start = time.monotonic()
    output.mkdir(parents=True, exist_ok=False)
    repro = root/'research/reproduction'
    scale, mean, cov, tiny = old_prior(repro)
    assert np.all(ACTIONS@A.T == 1)
    q = np.arange(20, dtype=float)**2
    integer = milp(-q, integrality=np.ones(20), bounds=Bounds(0, 1),
                   constraints=LinearConstraint(A, [1]*4+[0]*2, np.ones(6)),
                   options={'time_limit': 2, 'mip_rel_gap': 0})
    lp = linprog(-q, A_ub=A[4:], b_ub=np.ones(2), A_eq=A[:4],
                 b_eq=np.ones(4), bounds=(0, 1), method='highs')
    assert integer.success and lp.success
    exact = float(np.max(ACTIONS@q))
    assert abs(exact+integer.fun)<1e-8 and -lp.fun >= exact-1e-8
    one = np.ones((1, 1, 1), complex)
    assert np.allclose(rates(one, one, (0,), 0), np.log2(11))
    assert rates(2*one, one, (0,), 0)>rates(one, one, (0,), 0)
    tf, models = load_models(repro)
    obs = observe(tiny, 4, np.random.default_rng(917))
    probes = {}
    cnn_probe = None
    for name in ('cnn', 'cnn_gan'):
        y = predict(models[name], feature(obs).reshape(-1, 64, 2))
        assert y.shape == (4, 64, 2) and np.isfinite(y).all()
        if name=='cnn': cnn_probe=y
        probes[name] = {'input_shape': [4,64,2], 'output_shape': list(y.shape), 'finite': True}
    y = predict(models['mimic'], feature(complex_(cnn_probe).reshape(1,4,64)).reshape(1,512))
    assert y.shape == (1,6) and np.isfinite(y).all()
    probes['mimic'] = {'input_shape':[1,512], 'output_shape':list(y.shape), 'finite':True}
    source = json.loads((repro/'data-source.json').read_text())
    source_checks = []
    for item in source:
        path = root/'DeepMIMO_sena/O1_60'/Path(item['path']).name
        actual = sha(path)
        assert actual == item['sha256'], str(path)
        source_checks.append({'relative_path':str(path.relative_to(root)), 'sha256':actual})
    np.savez_compressed(output/'frozen-prior.npz', train_rms=scale, mean=mean, covariance=cov)
    manifest = {'protocol_id':'S02-FORWARD-1', 'status':'AUTHOR_PREFLIGHT_NOT_INDEPENDENT_AUDIT',
                'files':frozen_files(root), 'sources':source_checks,
                'prior_file_sha256':sha(output/'frozen-prior.npz'),
                'train_rms':scale, 'mean_sha256':array_sha(mean), 'covariance_sha256':array_sha(cov),
                'covariance_construction':'old normalized train(200,4,64); center.T @ center.conj()/800',
                'python':sys.version, 'tensorflow':tf.__version__, 'numpy':np.__version__,
                'packages':{name:metadata.version(name) for name in ('numpy','scipy','tensorflow','keras','DeepMIMOv3')},
                'model_compatibility':probes, 'analytic_fixture':{'enumeration_objective':exact,
                    'milp_objective':float(-integer.fun), 'lp_upper':float(-lp.fun)},
                'heldout_accessed':False, 'seconds':time.monotonic()-start}
    write_json(output/'manifest.json', manifest)
    print(json.dumps(manifest, indent=2))

def verify(root, frozen):
    manifest = json.loads((frozen/'manifest.json').read_text())
    assert manifest['files'] == frozen_files(root), 'Frozen inputs/code changed'
    assert manifest['prior_file_sha256'] == sha(frozen/'frozen-prior.npz')
    assert manifest['packages'] == {name:metadata.version(name) for name in manifest['packages']}
    for item in manifest['sources']:
        assert sha(root/item['relative_path']) == item['sha256']
    return manifest

def generate(root, out):
    import DeepMIMOv3 as dm
    p = dm.default_params()
    p['dataset_folder'] = str(root/'DeepMIMO_sena')
    p['scenario'] = 'O1_60'
    p['active_BS'] = np.arange(1,5)
    p['num_paths'] = 10
    p['user_rows'] = np.arange(101,201)
    p['enable_BS2BS'] = 0
    p['bs_antenna']['shape'] = np.array([1,8,1])
    p['ue_antenna']['shape'] = np.array([1,1,1])
    p['OFDM']['bandwidth'] = .05
    p['OFDM']['subcarriers'] = 32
    p['OFDM']['selected_subcarriers'] = np.array([0,16])
    parameters=json.loads(json.dumps(p,default=lambda v:v.tolist() if hasattr(v,'tolist') else str(v)))
    old_parameters=json.loads((root/'research/reproduction/generation-parameters.json').read_text())
    for key in set(parameters)|set(old_parameters):
        if key not in ('user_rows','dataset_folder'):
            assert parameters.get(key)==old_parameters.get(key), 'Generation parameter changed: '+key
    write_json(out/'generation-parameters.json', parameters)
    d = dm.generate_data(p)
    H = np.stack([v['user']['channel'][:,0,:,:] for v in d], axis=1)
    loc = np.asarray(d[0]['user']['location'])
    assert all(np.array_equal(loc, np.asarray(v['user']['location'])) for v in d)
    assert H.shape[1:] == (4,8,2) and len(H)>181 and np.isfinite(H).all()
    with np.load(root/'research/reproduction/channels.npz') as z:
        oldloc = z['location']
    old_coordinates = set(map(tuple, oldloc.tolist()))
    overlap = sum(tuple(x) in old_coordinates for x in loc.tolist())
    write_json(out/'coordinate-disjointness.json', {'old_rows':[1,100], 'new_rows':[101,200],
        'old_locations':len(oldloc), 'new_locations':len(loc), 'coordinate_overlap':overlap,
        'rule':'exact coordinate tuples, all old locations; abort entire panel on any overlap'})
    assert overlap == 0, 'Coordinate leakage: entire panel aborted, no selective removal'
    with (out/'channels.npz.partial').open('xb') as f:
        np.savez_compressed(f, H=H, location=loc)
    (out/'channels.npz.partial').rename(out/'channels.npz')
    write_json(out/'generation-complete.json', {'shape':list(H.shape),
        'sha256':sha(out/'channels.npz'), 'weak_and_zero_retained':True})

def expected():
    return [(tau, method, i) for tau in (4,8) for method in METHODS for i in range(N)]+[
        (4, method, i) for method in ('Mimic','Fixed') for i in range(N)]

def cellpath(out, tau, method, network):
    return out/'rows'/f'tau{tau}_{method}_{network:03d}.json'

def dispatchpath(out, tau, method, network):
    return out/'dispatch'/f'tau{tau}_{method}_{network:03d}.json'

def evaluate(root, frozen, out, deadline):
    start = time.monotonic()
    (out/'dispatch').mkdir(exist_ok=True)
    tf, models = load_models(root/'research/reproduction')
    z = np.load(frozen/'frozen-prior.npz')
    scale, mean, covariance = float(z['train_rms']), z['mean'], z['covariance']
    h = np.load(out/'channels.npz')['H'].reshape(-1,64)
    location_rng = np.random.default_rng(20261101)
    ids = np.stack([location_rng.choice(len(h), 4, replace=False) for _ in range(N)])
    with (out/'network-indices.npy').open('xb') as f:
        np.save(f, ids)
    truth = h[ids]/scale
    noise_rng = np.random.default_rng(20261102)
    write_json(out/'sampling.json', {'network_seed':20261101, 'noise_seed':20261102,
        'N':N, 'distinct_users_per_network':4, 'network_replacement':True,
        'truth_sha256':array_sha(truth), 'indices_sha256':array_sha(ids),
        'zero_channels':int(np.count_nonzero(np.sum(abs(truth)**2,axis=2)==0))})
    for tau in (4,8):
        obs = observe(truth, tau, noise_rng)
        filt = np.linalg.solve(covariance+NOISE/tau*np.eye(64), covariance).T
        estimates = {'LS':obs, 'LMMSE':(obs-mean)@filt+mean, 'Oracle':truth}
        prediction_seconds = {}
        for name, model in [('CNN','cnn'), ('CNN_GAN','cnn_gan')]:
            before = time.monotonic()
            estimates[name] = complex_(predict(models[model], feature(obs).reshape(-1,64,2))).reshape(obs.shape)
            prediction_seconds[name] = time.monotonic()-before
        if tau == 4:
            before = time.monotonic()
            mimic_actions = np.argmax(predict(models['mimic'],feature(estimates['CNN']).reshape(N,512)),axis=1)
            prediction_seconds['Mimic'] = time.monotonic()-before
        write_json(out/f'observations-tau{tau}.json', {'sha256':array_sha(obs),
            'paired_same_observation':True, 'prediction_batch_seconds':prediction_seconds})
        prelog = (200-tau)/200/2
        for i in range(N):
            for method in METHODS + (['Mimic','Fixed'] if tau==4 else []):
                if time.monotonic() >= deadline:
                    raise TimeoutError('CSI worker scientific deadline reached')
                before = time.monotonic()
                # Fsync + atomic rename completes BEFORE any cell computation.
                # An outer tree kill can then distinguish attempted from pending.
                write_json(dispatchpath(out,tau,method,i), {'network':i,'tau':tau,
                    'method':method,'status':'DISPATCHED','pid':os.getpid(),
                    'dispatch_monotonic':before,'parent_scientific_deadline':deadline})
                row = {'network':i,'tau':tau,'method':method,'status':'OK'}
                try:
                    ht = truth[i].reshape(4,32,2)
                    he = estimates['CNN' if method in ('Mimic','Fixed') else method][i].reshape(4,32,2)
                    scores = np.array([prelog*rates(he,he,g,s).sum() for g,s in CAND])
                    assert np.isfinite(scores).all()
                    action = int(mimic_actions[i]) if method=='Mimic' else (0 if method=='Fixed' else int(np.argmax(ACTIONS@scores)))
                    decision = ACTIONS[action]
                    # LP is descriptive; never substitutes for true-H evaluation.
                    remaining = deadline-time.monotonic()
                    if remaining <= 0: raise TimeoutError('before LP')
                    lp = linprog(-scores,A_ub=A[4:],b_ub=np.ones(2),A_eq=A[:4],b_eq=np.ones(4),
                                 bounds=(0,1),method='highs',options={'time_limit':min(2.,remaining)})
                    if not lp.success: raise RuntimeError('LP failure: '+lp.message)
                    assert -lp.fun >= np.max(ACTIONS@scores)-1e-7
                    user_rates = np.zeros(4)
                    for j,(g,s) in enumerate(CAND):
                        if decision[j]: user_rates[list(g)] = prelog*rates(ht,he,g,s)
                    row.update(net_se=float(user_rates.sum()), min_user_se=float(user_rates.min()),
                        user_rates=user_rates.tolist(),nmse=float(np.sum(abs(he-ht)**2)/max(np.sum(abs(ht)**2),1e-30)),
                        action=action,decision=decision.tolist(),nominal_objective=float(scores@decision),
                        exact_nominal_upper=float(np.max(ACTIONS@scores)),lp_upper=float(-lp.fun),
                        allocation_method='six-schedule enumeration' if method not in ('Mimic','Fixed') else method,
                        seconds=time.monotonic()-before)
                    if time.monotonic() >= deadline: row['status']='LATE'
                except Exception as error:
                    row.update(status='FAILED',error=repr(error),traceback=traceback.format_exc(),seconds=time.monotonic()-before)
                write_json(cellpath(out,tau,method,i),row)
    write_json(out/'evaluation-complete.json', {'seconds':time.monotonic()-start,'N':N})

def collect_rows(out, interruption_reason):
    """Read checkpoints only; do not mutate raw results or infer nonexistent success."""
    rows = []
    for tau,method,i in expected():
        p = cellpath(out,tau,method,i)
        marker = dispatchpath(out,tau,method,i)
        row = None
        if p.exists():
            try:
                row = json.loads(p.read_text())
                assert (row['tau'],row['method'],row['network'])==(tau,method,i)
            except Exception as error:
                row = {'tau':tau,'method':method,'network':i,'status':'INVALID_RESULT_RECORD',
                       'reason':repr(error),'result_path':str(p),'result_sha256':sha(p)}
        # A previous inner reconciliation may have emitted a pending placeholder.
        # A durable dispatch marker takes precedence over that placeholder only.
        if row is None or (row.get('status')=='NOT_RUN' and marker.exists()):
            row = {'tau':tau,'method':method,'network':i,
                   'status':'DISPATCHED_INTERRUPTED' if marker.exists() else 'NOT_RUN',
                   'reason':interruption_reason}
            if marker.exists():
                row['dispatch_record_sha256']=sha(marker)
                try: row['dispatch_record']=json.loads(marker.read_text())
                except Exception as error: row['dispatch_record_read_error']=repr(error)
        rows.append(row)
    return rows

def summarize_rows(out, stage_status, rows):
    good = {(r['tau'],r['method'],r['network']):r for r in rows if r['status']=='OK'}
    pairs = [good[4,'CNN',i]['net_se']-good[4,'LMMSE',i]['net_se'] for i in range(N)
             if (4,'CNN',i) in good and (4,'LMMSE',i) in good]
    failures = [r for r in rows if r['status']!='OK']
    analysis = {'protocol_id':'S02-FORWARD-1','primary':'CNN minus LMMSE, tau4',
                'units':'bit/s/Hz; pilot prelog and average over two active subcarriers',
                'planned_N':N,'complete_pairs':len(pairs),'expected_cells':len(rows),
                'failure_cells':len(failures),'stage_status':stage_status,
                'status_counts':{status:sum(r['status']==status for r in rows)
                                 for status in sorted(set(r['status'] for r in rows))},
                'confirmatory_superiority':False,'conditional_scope':'IID draws conditional on O1_60 fixed scene',
                'limitations':'No deployment, decoded-goodput, independent-scene, or new algorithmic novelty claim.'}
    if len(pairs)==N:
        x=np.asarray(pairs);se=float(x.std(ddof=1)/np.sqrt(N));mu=float(x.mean())
        half=float(t.ppf(.975,N-1)*se)
        boot_rng=np.random.default_rng(20261103)
        boot=x[boot_rng.integers(0,N,size=(10000,N))].mean(axis=1)
        analysis.update(mean=mu,sd=float(x.std(ddof=1)),se=se,df=N-1,
            student_t_CI95=[mu-half,mu+half],paired_bootstrap_CI95=np.quantile(boot,[.025,.975]).tolist(),
            bootstrap_seed=20261103,bootstrap_replicates=10000,
            confirmatory_superiority=bool(mu-half>0 and not failures and stage_status=='COMPLETE'))
    else:
        analysis['primary_analysis']='UNAVAILABLE: incomplete planned sample; no complete-case superiority test'
    analysis['secondary_descriptive']={}
    for tau in (4,8):
        for method in METHODS+(['Mimic','Fixed'] if tau==4 else []):
            rr=[r for r in rows if r['tau']==tau and r['method']==method and r['status']=='OK']
            analysis['secondary_descriptive'][f'{method}_tau{tau}']={'successful_N':len(rr),
                'planned_N':N,'mean_net_se_successes_only':float(np.mean([r['net_se'] for r in rr])) if rr else None,
                'mean_nmse_successes_only':float(np.mean([r['nmse'] for r in rr])) if rr else None,
                'mean_min_user_se_successes_only':float(np.mean([r['min_user_se'] for r in rr])) if rr else None}
    write_json(out/'analysis.json',analysis)
    write_json(out/'all-rows.json',rows)
    write_json(out/'failures.json',failures)

def summarize(out, stage_status):
    rows=collect_rows(out,stage_status)
    for row in rows:
        path=cellpath(out,row['tau'],row['method'],row['network'])
        if not path.exists(): write_json(path,row)
    summarize_rows(out,stage_status,rows)

def reconcile(out, destination, outer_status, outer_reason):
    """Outer-owned recovery; works even if the inner parent never summarized.

    Must run after the guard has reaped the entire CSI tree. No heldout arrays,
    model, solver, generation, training or experiment retry is accessed here.
    Completed raw records remain byte-for-byte unchanged.
    """
    destination.mkdir(parents=True,exist_ok=False)
    provenance={'outer_status':outer_status,'outer_reason':outer_reason,
                'raw_directory':str(out),'invoked_after_process_tree_reaped':True,
                'completion_records':{},'raw_checkpoint_sha256':{}}
    complete = outer_status=='COMPLETE'
    for name in ('run-complete.json','generate-status.json','evaluate-status.json'):
        p=out/name
        try:
            record=json.loads(p.read_text())
            provenance['completion_records'][name]={'sha256':sha(p),'record':record}
            if name=='run-complete.json': complete = complete and record.get('status')=='COMPLETE'
            else:
                complete = complete and record.get('returncode')==0 and not record.get('late',True)
        except Exception as error:
            complete=False
            provenance['completion_records'][name]={'unavailable':repr(error)}
    stage_status='COMPLETE' if complete else 'OUTER_RECONCILED_INCOMPLETE'
    reason=outer_reason or outer_status
    rows=collect_rows(out,reason)
    for subdirectory in ('rows','dispatch'):
        for p in sorted((out/subdirectory).glob('*.json')):
            provenance['raw_checkpoint_sha256'][str(p.relative_to(out))]=sha(p)
    summarize_rows(destination,stage_status,rows)
    write_json(destination/'reconciliation.json',provenance)

def run(root, frozen, out, approval, campaign_deadline):
    if not approval: raise ValueError('Explicit independent-preflight approval token required')
    # Root coordinates serial CPU use and shared two-hour campaign deadline.
    write_json(HERE/'execution-claimed.json', {'approval_reference':approval,
        'output':str(out),'policy':'one prospective invocation only; no automatic rerun'})
    out.mkdir(parents=True,exist_ok=False)
    (out/'rows').mkdir()
    start=time.monotonic()
    write_json(out/'run-lock.json',{'approval_reference':approval,'start_monotonic':start,
        'campaign_deadline':campaign_deadline,'policy':'one run, no overwrite, no optional stopping'})
    stage_status='COMPLETE'
    try:
        manifest=verify(root,frozen)
        write_json(out/'frozen-inputs.json',manifest)
        for stage in ('generate','evaluate'):
            remaining=min(600.,campaign_deadline-time.monotonic())
            if remaining<=0: raise TimeoutError('campaign budget exhausted')
            stage_start=time.monotonic();deadline=stage_start+remaining
            command=[sys.executable,'-B',str(Path(__file__).resolve()),stage,
                     '--root',str(root),'--frozen',str(frozen),'--output',str(out),
                     '--deadline',str(deadline)]
            with (out/(stage+'.stdout.log')).open('xb') as stdout, (out/(stage+'.stderr.log')).open('xb') as stderr:
                child=subprocess.Popen(command,stdout=stdout,stderr=stderr)
                try:
                    rc=child.wait(timeout=max(.001,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:
                    child.kill();child.wait();rc='TIMEOUT'
            elapsed=time.monotonic()-stage_start
            write_json(out/(stage+'-status.json'),{'returncode':rc,'elapsed_seconds':elapsed,
                'cap_seconds':remaining,'late':elapsed>remaining})
            if rc!=0 or elapsed>remaining:
                stage_status=stage.upper()+'_FAILED_OR_TIMEOUT'
                break
    except Exception as error:
        stage_status='CAMPAIGN_FAILED'
        write_json(out/'fatal-error.json',{'error':repr(error),'traceback':traceback.format_exc()})
    summarize(out,stage_status)
    write_json(out/'run-complete.json',{'status':stage_status,'seconds':time.monotonic()-start})

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('command',choices=['preflight','run','generate','evaluate','reconcile'])
    p.add_argument('--root',type=Path,default=DEFAULT_ROOT)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--frozen',type=Path,default=HERE/'preflight')
    p.add_argument('--approve-after-independent-preflight',default='')
    p.add_argument('--deadline',type=float,default=0)
    p.add_argument('--reconcile-output',type=Path)
    p.add_argument('--outer-status',choices=['COMPLETE','OUTER_INTERRUPTED','OUTER_FAILED'])
    p.add_argument('--outer-reason',default='')
    args=p.parse_args()
    # All authored outputs stay inside this packet; original data are read-only.
    args.output.resolve().relative_to(HERE)
    args.frozen.resolve().relative_to(HERE)
    if args.command=='preflight': preflight(args.root.resolve(),args.output.resolve())
    elif args.command=='reconcile':
        if args.reconcile_output is None or args.outer_status is None:
            p.error('reconcile requires --reconcile-output and --outer-status')
        args.reconcile_output.resolve().relative_to(HERE)
        reconcile(args.output.resolve(),args.reconcile_output.resolve(),args.outer_status,args.outer_reason)
    elif args.command=='run':
        if args.deadline<=0: p.error('run requires parent campaign monotonic --deadline')
        run(args.root.resolve(),args.frozen.resolve(),args.output.resolve(),
            args.approve_after_independent_preflight,args.deadline)
    else:
        if not (args.output/'run-lock.json').exists() or not (HERE/'execution-claimed.json').exists():
            p.error('Internal worker requires parent run lock and execution claim')
        if args.deadline<=time.monotonic(): p.error('Worker deadline absent or elapsed')
        if args.command=='generate': generate(args.root.resolve(),args.output.resolve())
        else: evaluate(args.root.resolve(),args.frozen.resolve(),args.output.resolve(),args.deadline)
