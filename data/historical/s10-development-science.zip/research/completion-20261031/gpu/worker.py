"""Bounded engineering GPU remediation; historical code imported read-only."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'): os.environ[k]='1'
import sys,time,json,ctypes,platform,itertools
from pathlib import Path
import numpy as np
import scipy
from scipy import sparse
from scipy.optimize import linprog
R=Path(__file__).resolve().parent
ROOT=R.parents[2]
sys.path.insert(0,str(ROOT/'research/gpu'))
import benchmark as old

def save_json(p,d):
    tmp=p.with_suffix('.pending'); tmp.write_text(json.dumps(d,indent=2),encoding='utf-8'); tmp.replace(p)

def save_npz(p,**d):
    tmp=p.with_suffix('.pending')
    with tmp.open('wb') as f: np.savez_compressed(f,**d)
    tmp.replace(p)

def inputs(n):
    z=np.load(ROOT/f'research/gpu/instance-{n}.npz')
    edges,A,power,slot,pidx=old.matrices(n)
    assert np.array_equal(power,z['power'])
    return z,edges,A,power

def cpu(n):
    z,edges,A,power=inputs(n); q=z['q']; budget=.1*n
    save_json(R/f'cpu-{n}.json',{'stage':'solver_started','users':n})
    start=time.perf_counter()
    sol=linprog(-q,A_eq=A,b_eq=np.ones(A.shape[0]),A_ub=power[None,:],b_ub=[budget],bounds=(0,1),method='highs',options={'time_limit':30,'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8})
    sec=time.perf_counter()-start
    out={'stage':'finished','users':n,'status':int(sol.status),'message':sol.message,'solve_seconds':sec,'peak_host_bytes':old.peak_host_bytes(),'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'executable':sys.executable}}
    if sol.x is not None:
        lam=-sol.eqlin.marginals; mu=-float(sol.ineqlin.marginals[0])
        save_npz(R/f'cpu-{n}-vectors.npz',x=sol.x,lam=lam,mu=mu)
        out['primal_objective_Mbps']=float(q@sol.x)
    save_json(R/f'cpu-{n}.json',out)

def init_gpu():
    os.environ['CUPY_CACHE_DIR']=str(R/'cache')
    lib=Path(sys.prefix)/'Library/bin'; handles=[]
    if os.name=='nt':
        handles.append(os.add_dll_directory(str(lib))); os.environ['PATH']=str(lib)+os.pathsep+os.environ['PATH']
        dll=lib/'nvrtc-builtins64_128.dll'
        if dll.exists(): handles.append(ctypes.WinDLL(str(dll)))
    import cupy as cp
    cp.get_default_memory_pool().set_limit(size=4*1024**3)
    return cp,handles

def gpu(n):
    beginning=time.perf_counter(); cp,handles=init_gpu()
    from cupyx.scipy import sparse as cs
    z,edges,A,power=inputs(n); q=z['q']; budget=.1*n
    H=np.load(ROOT/'research/gpu/channels32.npz')['H']
    h=(np.sqrt(32)*H[z['ids']]).reshape(n,32,32)[:,:,:n//2].astype(np.complex128); del H
    K=sparse.vstack([A,sparse.csr_matrix(power[None,:])],format='csr')
    rhs=np.r_[np.ones(A.shape[0]),budget]; scale=np.sqrt(np.asarray(K.multiply(K).sum(1)).ravel())
    K=sparse.diags(1/scale)@K; rhs=rhs/scale; qscale=float(q.max())
    t=time.perf_counter(); kd=cs.csr_matrix(K); kt=kd.T.tocsr(); b=cp.asarray(rhs); c=cp.asarray(q/qscale)
    x=cp.zeros(len(q)); xb=x.copy(); y=cp.zeros(len(rhs)); avg=x.copy(); step=.9/np.sqrt(len(rhs))
    cp.cuda.Stream.null.synchronize(); setup=time.perf_counter()-t
    t=time.perf_counter(); old.rates(cp.asarray(h),edges,cp)
    for _ in range(10):
        y+=step*(kd@xb-b); y[-1]=cp.maximum(y[-1],0)
        xn=cp.clip(x+step*(c-kt@y),0,1); xb=2*xn-x; x=xn; avg+=(x-avg)/10
    cp.cuda.Stream.null.synchronize(); warm=time.perf_counter()-t
    timings=[]; error=0.
    for rep in range(5):
        # Alternation only changes timing order; input and kernels remain identical.
        def ct():
            t=time.perf_counter(); v=old.rates(h,edges,np); return v,time.perf_counter()-t
        def gt():
            t=time.perf_counter(); hg=cp.asarray(h); cp.cuda.Stream.null.synchronize(); h2d=time.perf_counter()-t
            t=time.perf_counter(); vg=old.rates(hg,edges,cp); cp.cuda.Stream.null.synchronize(); kernel=time.perf_counter()-t
            t=time.perf_counter(); vg=cp.asnumpy(vg); cp.cuda.Stream.null.synchronize(); d2h=time.perf_counter()-t
            return vg,h2d,kernel,d2h
        if rep%2: vg,h2d,kernel,d2h=gt(); v,cs0=ct()
        else: v,cs0=ct(); vg,h2d,kernel,d2h=gt()
        assert np.allclose(v,vg,rtol=1e-8,atol=1e-8)
        assert np.allclose(q,v.ravel()*old.BW*(1-n/200)/1e6,rtol=1e-12,atol=1e-12)
        error=max(error,float(abs(v-vg).max()))
        timings.append({'repeat':rep,'order':'GPU_CPU' if rep%2 else 'CPU_GPU','cpu_seconds':cs0,'H2D_seconds':h2d,'kernel_seconds':kernel,'D2H_seconds':d2h})
    # Reset every iterate after warmup: no accidental warm-start advantage.
    x.fill(0); xb.fill(0); y.fill(0); avg.fill(0); cp.cuda.Stream.null.synchronize()
    props=cp.cuda.runtime.getDeviceProperties(0)
    out={'stage':'iteration_started','users':n,'columns':len(q),'host_gpu_setup_seconds':setup,'explicit_warmup_seconds':warm,'pre_iteration_seconds':time.perf_counter()-beginning,'coefficient_timings':timings,'max_abs_coefficient_error_SE':error,'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'cupy':cp.__version__,'gpu':str(props['name']),'executable':sys.executable},'scope':'finite-grid LP; warm-cache startup; development instances'}
    save_json(R/f'gpu-{n}.json',out)
    best=float('inf'); by=y.copy(); bx=x.copy(); ba=avg.copy(); converged=False; checks=0; saved=0.; snapshot_seconds=0.
    start=time.perf_counter()
    for it in range(1,1000001):
        y+=step*(kd@xb-b); y[-1]=cp.maximum(y[-1],0)
        xn=cp.clip(x+step*(c-kt@y),0,1); xb=2*xn-x; x=xn; avg+=(x-avg)/it
        if it%100: continue
        checks+=1
        d=float((b@y+cp.maximum(0,c-kt@y).sum()).get())*qscale
        if d<best: best=d; by=y.copy()
        rec=[]
        for xx,label in [(x,'last'),(avg,'average')]:
            res=cp.asnumpy(kd@xx-b)*scale
            viol=max(float(np.max(abs(res[:-1]))),max(0,float(res[-1])))
            val=float((c@xx).get())*qscale
            rec.append({'iterate':label,'violation':viol,'objective_Mbps_not_feasible_bound':val,'dual_minus_primal_Mbps':best-val})
        chosen=min(rec,key=lambda r:r['violation'])
        converged=chosen['violation']<=1e-6 and abs(chosen['dual_minus_primal_Mbps'])<=1e-6*max(1,abs(best))
        elapsed=time.perf_counter()-start
        stop=converged or elapsed>=30
        if elapsed-saved>=1 or stop or checks==1:
            t=time.perf_counter()
            save_npz(R/f'gpu-{n}-vectors.npz',last=cp.asnumpy(x),average=cp.asnumpy(avg),lam=cp.asnumpy(by[:-1])*qscale/scale[:-1],mu=cp.asnumpy(by[-1])*qscale/scale[-1])
            snapshot_seconds+=time.perf_counter()-t; saved=time.perf_counter()-start
            out.update({'stage':'finished' if stop else 'iteration_checkpoint','status':'TOLERANCE_MET' if converged else ('TIME_LIMIT_NOT_CONVERGED' if stop else 'RUNNING'),'iterations':it,'checks':checks,'iteration_check_and_checkpoint_seconds':saved,'checkpoint_seconds_included':snapshot_seconds,'dual_upper_Mbps_float':best,'candidates':rec,'GPU_pool_bytes':int(cp.get_default_memory_pool().total_bytes()),'peak_host_bytes':old.peak_host_bytes()})
            save_json(R/f'gpu-{n}.json',out)
            assert out['GPU_pool_bytes']<4*1024**3
            assert out['peak_host_bytes']<8*1024**3
        if stop: break

if __name__=='__main__':
    method,n=sys.argv[1],int(sys.argv[2]); (cpu if method=='cpu' else gpu)(n)
