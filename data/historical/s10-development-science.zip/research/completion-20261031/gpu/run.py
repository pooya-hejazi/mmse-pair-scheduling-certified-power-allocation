"""Serial external process deadlines; no detached/background worker survives."""
import os,sys,time,json,hashlib,subprocess,shutil
from pathlib import Path
R=Path(__file__).resolve().parent; ROOT=R.parents[2]
PY=Path('C:/ProgramData/anaconda3/envs/tf-gpu/python.exe')

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def bounded(cmd,seconds,label):
    t=time.perf_counter()
    with (R/f'{label}.stdout.txt').open('w') as so,(R/f'{label}.stderr.txt').open('w') as se:
        p=subprocess.Popen(cmd,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        timeout=False
        try: code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired: timeout=True;p.kill();code=p.wait(timeout=5)
    record={'command':cmd,'PID':p.pid,'limit_seconds':seconds,'wall_seconds':time.perf_counter()-t,'status':'WALL_TIMEOUT' if timeout else ('COMPLETED' if code==0 else 'FAILED'),'exit_code':code}
    (R/f'{label}.execution.json').write_text(json.dumps(record,indent=2));return record

def main():
    started=time.perf_counter()
    assert not (R/'manifest.json').exists(),'write-once run'
    old=[ROOT/'research/gpu'/p for p in ['benchmark.py','MODEL_PROTOCOL.md','RUN_CONFIG.json','results.json','channels32.npz','instance-8.npz','instance-16.npz','instance-32.npz']]
    old+=list((ROOT/'research/gpu/cache').glob('*'))
    cache=R/'cache';cache.mkdir(exist_ok=True)
    for p in (ROOT/'research/gpu/cache').glob('*'):
        if p.is_file():shutil.copy2(p,cache/p.name)
    manifest={'old':{str(p.relative_to(ROOT)):digest(p) for p in old if p.is_file()},'code':{p.name:digest(p) for p in R.glob('*.py')},'protocol_sha256':digest(R/'PROTOCOL.md'),'python':str(PY),'limits':{'aggregate_seconds':720,'external_worker_seconds':40,'internal_LP_seconds':30,'RAM_GiB':8,'GPU_pool_GiB':4},'scope':'existing development inputs only; cached GPU binary provenance retained'}
    (R/'manifest.json').write_text(json.dumps(manifest,indent=2))
    # Parent behavior, including checkpoint survival on forced termination.
    a=bounded([str(PY),'-B','-c','print(7)'],3,'check-success')
    b=bounded([str(PY),'-B','-c','raise SystemExit(3)'],3,'check-failure')
    flag=R/'forced-checkpoint.txt'
    c=bounded([str(PY),'-B','-c',f'from pathlib import Path; import time; Path({str(flag)!r}).write_text("retained"); time.sleep(4)'],1,'check-timeout')
    assert a['status']=='COMPLETED' and b['status']=='FAILED' and c['status']=='WALL_TIMEOUT' and flag.read_text()=='retained'
    rows=[]
    for n in [8,16,32]:
        for method in ['cpu','gpu']:
            assert time.perf_counter()-started<660
            r=bounded([str(PY),'-B',str(R/'worker.py'),method,str(n)],40,f'{method}-{n}');rows.append(r)
            print(method,n,r['status'],round(r['wall_seconds'],3),flush=True)
            if r['status']=='FAILED': break
        if rows[-1]['status']=='FAILED':break
    unchanged=all(digest(ROOT/p)==h for p,h in manifest['old'].items())
    result={'executions':rows,'wall_seconds':time.perf_counter()-started,'old_inputs_unchanged':unchanged,'parent_checks':'PASS'}
    (R/'completion.json').write_text(json.dumps(result,indent=2));assert unchanged

if __name__=='__main__':main()
