"""CPU-only verification of the sole CSR repair execution; not independent audit."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
R=Path(__file__).resolve().parent;ROOT=R.parents[2];D=R/'csr-repair'
sys.path.insert(0,str(R));import checks
from scipy import sparse

def main():
    rows=[]
    for n in [8,16,32]:
        data=np.load(ROOT/f'research/gpu/instance-{n}.npz');q=data['q'];power=data['power']
        edges,A,e,slot,pidx=checks.old.matrices(n);assert np.array_equal(power,e)
        K=sparse.vstack([A,sparse.csr_matrix(power[None,:])],format='csr')
        scale=np.sqrt(np.asarray(K.multiply(K).sum(1)).ravel());before=sparse.diags(1/scale)@K;after=before.copy()
        after.sum_duplicates();after.sort_indices()
        assert before.nnz==after.nnz and (before-after).nnz==0 and after.has_canonical_format
        gpu=np.load(D/f'gpu-{n}-vectors.npz');cpu=np.load(R/f'cpu-{n}-vectors.npz')
        cu=checks.evaluate(cpu['x'],cpu['lam'],float(cpu['mu']),A,q,power,.1*n)
        gs={key:checks.evaluate(gpu[key],gpu['lam'],float(gpu['mu']),A,q,power,.1*n) for key in ['last','average']}
        for g in gs.values():assert g['dual_upper_plus_margin_Mbps']>=cu['objective_Mbps_not_necessarily_feasible']-1e-6
        info=json.loads((D/f'gpu-{n}.json').read_text());ex=json.loads((R/f'csr-repair-{n}.execution.json').read_text())
        assert ex['status']=='COMPLETED' and ex['wall_seconds']<=40.5
        assert info['CSR_exact_host_equality'] and info['GPU_CPU_deterministic_SpMV_checks']
        assert info['max_abs_coefficient_error_SE']<1e-8 and len(info['coefficient_timings'])==5
        feasible=[v for v in gs.values() if v['feasible_at_1e-6']]
        if info['status']=='TOLERANCE_MET':assert any(abs(v['dual_minus_primal_Mbps'])<=1e-6*max(1,abs(v['dual_upper_raw_Mbps'])) for v in feasible)
        assert info['peak_host_bytes']<8*1024**3 and info['GPU_pool_bytes']<4*1024**3
        tt=info['coefficient_timings']
        def stat(values):return {'median':float(np.median(values)),'min':float(min(values)),'max':float(max(values))}
        timings={'CPU_seconds':stat([v['cpu_seconds'] for v in tt]),'GPU_kernel_seconds':stat([v['kernel_seconds'] for v in tt]),'GPU_transfers_seconds':stat([v['H2D_seconds']+v['D2H_seconds'] for v in tt]),'GPU_total_seconds':stat([v['kernel_seconds']+v['H2D_seconds']+v['D2H_seconds'] for v in tt])}
        rows.append({'users':n,'CSR_exact_equal':True,'CPU':cu,'GPU_candidates':gs,'GPU_status':info['status'],'GPU_iterations':info['iterations'],'GPU_total_external_seconds':ex['wall_seconds'],'GPU_iteration_check_checkpoint_seconds':info['iteration_check_and_checkpoint_seconds'],'GPU_sparse_setup_seconds':info['host_gpu_setup_seconds'],'GPU_explicit_warmup_seconds':info['explicit_warmup_seconds'],'GPU_checkpoint_seconds_included':info['checkpoint_seconds_included'],'CPU_GPU_coefficient_max_error_SE':info['max_abs_coefficient_error_SE'],'coefficient_timing_statistics':timings,'host_peak_bytes':info['peak_host_bytes'],'GPU_pool_bytes':info['GPU_pool_bytes']})
    m=json.loads((R/'manifest.json').read_text());unchanged=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in m['old'].items());assert unchanged
    out={'result':'PASS','scope':'author CPU recomputation; not independent stage acceptance','old_inputs_unchanged':unchanged,'rows':rows}
    (D/'verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({'result':'PASS','users':[r['users'] for r in rows],'GPU_statuses':[r['GPU_status'] for r in rows],'originals_unchanged':unchanged}))
if __name__=='__main__':main()
