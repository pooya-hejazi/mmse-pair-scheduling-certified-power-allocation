"""Independent CPU recomputation of stored vectors, not an independent audit."""
from pathlib import Path
import sys,json,itertools,hashlib
import numpy as np
R=Path(__file__).resolve().parent; ROOT=R.parents[2]
sys.path.insert(0,str(ROOT/'research/gpu'))
import benchmark as old

def evaluate(x,lam,mu,A,q,power,budget):
    eq=float(np.max(abs(A@x-1))); box=float(max(0.,-x.min(),x.max()-1)); powv=float(max(0.,power@x-budget))
    objective=float(q@x)
    # Every nonnegative mu and unrestricted lambda gives a box dual bound.
    assert mu>=-1e-12 and np.all(np.isfinite(lam)) and np.all(np.isfinite(x))
    mu=max(0.,mu)
    term=q-A.T@lam-mu*power
    raw=float(lam.sum()+budget*mu+np.maximum(0,term).sum())
    margin=1e-8*max(1.,abs(raw))
    return {'equality_residual':eq,'box_residual':box,'power_violation_W':powv,'feasible_at_1e-6':max(eq,box,powv)<=1e-6,'objective_Mbps_not_necessarily_feasible':objective,'dual_upper_raw_Mbps':raw,'numerical_margin_Mbps':margin,'dual_upper_plus_margin_Mbps':raw+margin,'dual_minus_primal_Mbps':raw-objective,'max_violation':max(eq,box,powv)}

def preliminary():
    rng=np.random.default_rng(126000);h=(rng.normal(size=(4,5,2))+1j*rng.normal(size=(4,5,2)))*np.sqrt(old.NOISE)
    edges,A,power,slot,pidx=old.matrices(4);v=old.rates(h,edges,np)
    count=0
    for j,(u,w) in enumerate(edges):
      for s in range(2):
       for k,(pu,pv) in enumerate(itertools.product(old.GRID,repeat=2)):
        a=h[u,:,s];b=h[w,:,s]; eye=old.NOISE*np.eye(5)
        gu=pu*np.vdot(a,np.linalg.solve(eye+pv*np.outer(b,b.conj()),a)).real
        gv=pv*np.vdot(b,np.linalg.solve(eye+pu*np.outer(a,a.conj()),b)).real
        assert np.isclose(v[j,s,k],np.log2(1+gu)+np.log2(1+gv),rtol=1e-10,atol=1e-10);count+=1
    q=v.ravel();lam=rng.normal(size=A.shape[0]);mu=.2
    bound=lam.sum()+.4*mu+np.maximum(0,q-A.T@lam-mu*power).sum()
    schedules=0
    for m in old.matchings(list(range(4))):
      for slots in itertools.permutations(range(2)):
       for ps in itertools.product(range(9),repeat=2):
        ix=[(edges.index(e)*2+s)*9+p for e,s,p in zip(m,slots,ps)]
        if power[ix].sum()<=.4+1e-12:
         assert q[ix].sum()<=bound+1e-10;schedules+=1
    (R/'prechecks.json').write_text(json.dumps({'result':'PASS','direct_MMSE_points':count,'feasible_enumerated_schedules':schedules,'arbitrary_dual_bound_checked':True},indent=2))

def post():
    rows=[]; historical=json.loads((ROOT/'research/gpu/results.json').read_text())
    for n in [8,16,32]:
        z=np.load(ROOT/f'research/gpu/instance-{n}.npz'); q=z['q'];power=z['power'];edges,A,ep,slot,pidx=old.matrices(n);assert np.array_equal(power,ep)
        cpu=np.load(R/f'cpu-{n}-vectors.npz');cu=evaluate(cpu['x'],cpu['lam'],float(cpu['mu']),A,q,power,.1*n)
        assert cu['feasible_at_1e-6'] and abs(cu['dual_minus_primal_Mbps'])<=1e-6*max(1,cu['dual_upper_raw_Mbps'])
        gp=R/f'gpu-{n}-vectors.npz';info=json.loads((R/f'gpu-{n}.json').read_text()) if (R/f'gpu-{n}.json').exists() else {}
        candidates={}
        if gp.exists():
            g=np.load(gp)
            for key in ['last','average']:
                e=evaluate(g[key],g['lam'],float(g['mu']),A,q,power,.1*n);candidates[key]=e
                assert e['dual_upper_plus_margin_Mbps']>=cu['objective_Mbps_not_necessarily_feasible']-1e-6
            if info.get('status')=='TOLERANCE_MET':
                assert any(e['feasible_at_1e-6'] and abs(e['dual_minus_primal_Mbps'])<=1e-6*max(1,e['dual_upper_raw_Mbps']) for e in candidates.values())
        oldrow=next(r for r in historical['rows'] if r['users']==n)
        mins=oldrow['minimum_power_MILP']; ix=mins['selected'];xx=np.zeros(len(q));xx[ix]=1
        target=oldrow['minimum_power_target_Mbps']; achieved=float(q@xx); watts=float(power@xx)
        assert np.max(abs(A@xx-1))==0 and achieved>=target-1e-6 and abs(watts-mins['power_W'])<1e-10
        assert oldrow['minimum_power_LP']['power_W']<=watts+1e-8
        rows.append({'users':n,'CPU':cu,'GPU_status':info.get('status','NO_RESULT'),'GPU_candidates':candidates,'historical_min_power':{'incumbent_feasible':True,'target_Mbps':target,'achieved_Mbps':achieved,'power_W':watts,'old_LP_lower_W_numerical_only':oldrow['minimum_power_LP']['power_W'],'caution':'Target is 95% of fixed-power incumbent; not equal-throughput savings, not a continuous lower bound'}})
    manifest=json.loads((R/'manifest.json').read_text()); unchanged=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in manifest['old'].items())
    assert unchanged
    (R/'checks.json').write_text(json.dumps({'result':'PASS','scope':'author-side CPU recomputation, not independent checkpoint','old_inputs_unchanged':unchanged,'rows':rows},indent=2))
if __name__=='__main__': (preliminary if sys.argv[1]=='pre' else post)()
