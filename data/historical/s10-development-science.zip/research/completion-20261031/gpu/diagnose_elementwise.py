import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='1'
import time,json,sys
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import worker as w
import numpy as np
from scipy import sparse
start=time.perf_counter(); current=None
record={'packet':'DIAG-ELEMENTWISE-01','purpose':'startup diagnosis only; no solver','stages':[]}
def before(name):
    global current
    current={'name':name,'started_seconds':time.perf_counter()-start,'state':'ENTERED'}
    record['stages'].append(current); w.save_json(R/'diag-elementwise-01.json',record)
def after():
    current['finished_seconds']=time.perf_counter()-start
    current['elapsed_seconds']=current['finished_seconds']-current['started_seconds'];current['state']='FINISHED'
    w.save_json(R/'diag-elementwise-01.json',record)
before('CuPy_CUDA_initialization');cp,handles=w.init_gpu();cp.cuda.Stream.null.synchronize();after()
props=cp.cuda.runtime.getDeviceProperties(0)
record['device']={'name':str(props['name']),'driver_version':cp.cuda.runtime.driverGetVersion(),'runtime_version':cp.cuda.runtime.runtimeGetVersion(),'cupy':cp.__version__}
before('channel_loading'); z,edges,A,power=w.inputs(8)
H=np.load(w.ROOT/'research/gpu/channels32.npz')['H']
h=(np.sqrt(32)*H[z['ids']]).reshape(8,32,32)[:,:,:4].astype(np.complex128);del H;after()
before('host_incidence_preparation');K=sparse.vstack([A,sparse.csr_matrix(power[None,:])],format='csr')
scale=np.sqrt(np.asarray(K.multiply(K).sum(1)).ravel());K=sparse.diags(1/scale)@K
rhs=np.r_[np.ones(A.shape[0]),.8]/scale;after()
before('H2D_channel');hg=cp.asarray(h);cp.cuda.Stream.null.synchronize();after()
before('single_coefficient_construction_and_sync');vg=w.old.rates(hg,edges,cp);cp.cuda.Stream.null.synchronize();after()
before('D2H_coefficient');v=cp.asnumpy(vg);cp.cuda.Stream.null.synchronize();after()
reference=w.old.rates(h,edges,np);record['coefficient_max_abs_error_SE']=float(np.max(abs(v-reference)));assert np.allclose(v,reference,rtol=1e-8,atol=1e-8)
before('sparse_module_import');from cupyx.scipy import sparse as cs;after()
before('CSR_sparse_construction');kd=cs.csr_matrix(K);x=cp.ones(K.shape[1]);cp.cuda.Stream.null.synchronize();after()
before('single_forward_SpMV_and_sync');y=kd@x;cp.cuda.Stream.null.synchronize();after()
before('transpose_CSR_construction');kt=kd.T.tocsr();cp.cuda.Stream.null.synchronize();after()
before('single_transpose_SpMV_and_sync');zz=kt@y;cp.cuda.Stream.null.synchronize();after()
assert np.allclose(cp.asnumpy(y),K@np.ones(K.shape[1]),rtol=1e-10,atol=1e-10)
assert np.allclose(cp.asnumpy(zz),K.T@(K@np.ones(K.shape[1])),rtol=1e-10,atol=1e-10)
before('update_vector_initialization')
x=cp.zeros(K.shape[1]);xb=x.copy();y=cp.zeros(K.shape[0]);avg=x.copy();b=cp.asarray(rhs);c=cp.asarray(z['q']/float(z['q'].max()));step=.9/np.sqrt(len(rhs));cp.cuda.Stream.null.synchronize();after()
before('dual_vector_update_y_plus_equals');y+=step*(kd@xb-b);cp.cuda.Stream.null.synchronize();after()
before('dual_scalar_index_read');last=y[-1];cp.cuda.Stream.null.synchronize();after()
before('dual_scalar_maximum');projected=cp.maximum(last,0);cp.cuda.Stream.null.synchronize();after()
before('dual_scalar_index_write');y[-1]=projected;cp.cuda.Stream.null.synchronize();after()
before('primal_gradient');proposal=x+step*(c-kt@y);cp.cuda.Stream.null.synchronize();after()
before('primal_clip');xn=cp.clip(proposal,0,1);cp.cuda.Stream.null.synchronize();after()
before('primal_extrapolation');xb=2*xn-x;x=xn;cp.cuda.Stream.null.synchronize();after()
before('average_update');avg+=(x-avg)/10;cp.cuda.Stream.null.synchronize();after()
yc=-step*rhs;yc[-1]=max(yc[-1],0);xc=np.clip(step*(z['q']/float(z['q'].max())-K.T@yc),0,1)
assert np.allclose(cp.asnumpy(y),yc,rtol=1e-10,atol=1e-10)
assert np.allclose(cp.asnumpy(x),xc,rtol=1e-10,atol=1e-10)
record['one_update_CPU_agreement']=True
record.update({'status':'COMPLETED_DIAGNOSIS','host_peak_bytes':w.old.peak_host_bytes(),'GPU_pool_bytes_at_end':int(cp.get_default_memory_pool().total_bytes()),'total_seconds':time.perf_counter()-start})
assert record['host_peak_bytes']<8*1024**3 and record['GPU_pool_bytes_at_end']<4*1024**3
w.save_json(R/'diag-elementwise-01.json',record)
