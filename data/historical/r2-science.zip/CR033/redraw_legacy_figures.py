"""All-case paired displays from unchanged accepted R1 data."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent
csvpath=R/'research/reviewer-request-20261102/revision/all-cells.csv';rows=list(csv.DictReader(csvpath.open()))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':8.5,'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
out=W/'source-r2/images';out.mkdir(exist_ok=True);exports=[]
def save(fig,name):
 for ext in ('pdf','svg','png'):
  p=out/(name+'.'+ext);fig.savefig(p,bbox_inches='tight',dpi=190);exports.append(dict(path=str(p.relative_to(W)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 plt.close(fig)
def lookup(panel,scene):
 chosen=[r for r in rows if r['panel']==panel and r['scene']==scene];return {(int(r['index']),r['method']):r for r in chosen}
colors=['#176A88','#C16322']
fig,axs=plt.subplots(1,3,figsize=(6.6,2.15),sharey=True)
for j,(left,right,label) in enumerate([('full','joint','Full − matching WMMSE'),('grid','joint','Grid − matching WMMSE'),('full','grid','Full − Grid')]):
 ax=axs[j]
 for si,scene in enumerate(['o1','asu']):
  tab=lookup('main',scene);values=np.array([float(tab[i,left]['SE'])-float(tab[i,right]['SE']) for i in range(12)])
  x=si+np.linspace(-.20,.20,12);ax.scatter(x,values,s=13,alpha=.82,color=colors[si],edgecolor='white',linewidth=.3)
  ax.plot([si-.23,si+.23],[values.mean()]*2,color=colors[si],lw=1.6)
 ax.axhline(0,color='.35',lw=.65);ax.set_xticks([0,1],['O1','ASU']);ax.set_title(label);ax.grid(axis='y',alpha=.16)
axs[0].set_ylabel('Paired SE difference (bit/s/Hz)');fig.tight_layout(w_pad=1);save(fig,'r2-legacy-rate-paired')
fig,axs=plt.subplots(1,3,figsize=(6.6,2.2))
for si,scene in enumerate(['o1','asu']):
 tab=lookup('main',scene);a=np.array([float(tab[i,'full']['relative_gap'])*100 for i in range(12)]);axs[0].scatter(si+np.linspace(-.18,.18,12),a,s=12,color=colors[si]);axs[0].plot([si-.22,si+.22],[a.mean()]*2,color=colors[si],lw=1.4)
axs[0].set_xticks([0,1],['O1','ASU']);axs[0].set_ylabel('Verified gap / lower value (%)');axs[0].set_title('Eight users: Full bounds');axs[0].set_ylim(bottom=0)
for si,scene in enumerate(['o1','asu']):
 tab=lookup('scale',scene)
 methods=sorted(set(r['method'] for r in rows if r['panel']=='scale'))
 priced='full' if (0,'full') in tab else 'pricing'
 for i in range(4):
  xx=np.array([si*2.5,si*2.5+1])+np.linspace(-.3,.3,4)[i];yy=[100*float(tab[i,m]['relative_gap']) for m in ('grid',priced)]
  axs[1].plot(xx,yy,'o-',ms=3.4,lw=.7,color=colors[si],alpha=.8)
  axs[1].annotate(str(i),(xx[1]+.04,yy[1]),fontsize=6,color=colors[si])
  delta=float(tab[i,priced]['SE'])-float(tab[i,'grid']['SE']);axs[2].scatter(si+np.linspace(-.20,.20,4)[i],delta,s=18,color=colors[si]);axs[2].annotate(str(i),(si+np.linspace(-.20,.20,4)[i],delta),xytext=(0,5 if i%2==0 else -10),textcoords='offset points',ha='center',fontsize=6,color=colors[si])
axs[1].set_xticks([0,1,2.5,3.5],['O1\nGrid','Pricing','ASU\nGrid','Pricing']);axs[1].set_title('16 users: fallback → pricing');axs[1].set_ylabel('Verified gap / lower value (%)');axs[1].set_ylim(bottom=0)
axs[2].axhline(0,color='.5',lw=.65);axs[2].set_xticks([0,1],['O1','ASU']);axs[2].set_ylim(-.03,.03);axs[2].set_ylabel('Pricing − Grid SE (bit/s/Hz)');axs[2].set_title('All eight rates unchanged')
for ax in axs:ax.grid(axis='y',alpha=.14)
fig.tight_layout(w_pad=1);save(fig,'r2-legacy-certificates')
fig,ax=plt.subplots(figsize=(3.15,2.05));tab=lookup('main','asu')
for i in range(12):
 x=[float(tab[i,m]['SE']) for m in ('joint','full')];y=[float(tab[i,m]['min_user_SE']) for m in ('joint','full')]
 ax.plot(x,y,color='.72',lw=.7,zorder=1)
 ax.scatter(x[0],y[0],s=17,facecolor='white',edgecolor=colors[0],linewidth=.8,zorder=2,label='Matching WMMSE' if i==0 else None)
 ax.scatter(x[1],y[1],s=15,color=colors[1],marker='s',zorder=3,label='Full' if i==0 else None)
ax.set_xlabel('Sum SE (bit/s/Hz)');ax.set_ylabel('Minimum-user SE (bit/s/Hz)');ax.set_title('ASU: 12 matched allocations');ax.legend(frameon=False,loc='upper left',fontsize=6.8);ax.grid(alpha=.14);fig.tight_layout();save(fig,'r2-legacy-fairness')
(W/'editorial/LEGACY_FIGURE_MANIFEST.json').write_text(json.dumps(dict(input_csv_sha256=hashlib.sha256(csvpath.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='All24 main and8 scale unchanged saved cases; horizontal offsets only; no new inferential endpoint',exports=exports),indent=2))
print(json.dumps({'exports':len(exports),'cases_preserved':32}))
