"""Saved-data registered secondary Grid contrast and descriptive accounting.

Written during holdout; no new endpoint, solver, selection or replacement.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,math,csv
import numpy as np
W=Path(__file__).parent
sys.path.insert(0,str(W/'method/controller'))
from analyze_study import group_summary
from io_utils import publish
out=W/'study/analysis/holdout'
summary=json.loads((out/'SUMMARY.json').read_text());assert summary['complete']
inputs=json.loads((W/'study/holdout-INPUTS.json').read_text())['inputs']
rows=list(csv.DictReader((out/'all-cells.csv').open(newline='',encoding='utf-8')))
contrasts=[];diagnostics={a:[] for a in ('T','W','S','FU_SCA','THU_IDE')}
for inp in inputs:
 common=json.loads((W/'study/common'/inp['id']/'result.json').read_text())
 t=next(r for r in rows if r['case_id']==inp['id'] and r['arm']=='T')
 contrasts.append(dict(case_id=inp['id'],seed=inp['seed'],T_minus_common_Grid=float(t['SE'])-float(F(common['lower_nats']))/(4*math.log(2))))
 for a in diagnostics:
  r=json.loads((W/'study/cells'/f'{inp["id"]}-{a}'/'result.json').read_text());d=(r.get('worker_status') or {}).get('diagnostics',{})
  diagnostics[a].append(dict(case_id=inp['id'],status=r['status'],verification_timeouts=len(r.get('verification_timeouts',[])),late_candidates=len(r.get('late_candidates',[])),receipts=len(r['receipts']),**{k:d.get(k) for k in ('starts_started','starts_completed','exchange_candidates','exchange_accepted','neighborhoods_completed','stopped_phase')}))
seeds=sorted({r['seed'] for r in contrasts})
groups=[float(np.mean([r['T_minus_common_Grid'] for r in contrasts if r['seed']==s])) for s in seeds]
descriptive={}
for a in diagnostics:
 rr=[r for r in rows if r['arm']==a]
 descriptive[a]={k:dict(mean=float(np.mean([float(r[k]) for r in rr])),minimum=min(float(r[k]) for r in rr),maximum=max(float(r[k]) for r in rr)) for k in ('SE','charged_actual','minimum_user_SE','Jain','power_W')}
publish(out/'SECONDARY.json',dict(scope='Registered secondary T-commonGrid; descriptive all-arm cost/fairness/coverage. No primary change.',grid_effect=group_summary(groups),grid_cases=contrasts,descriptive=descriptive,diagnostics=diagnostics,peak_memory='Unavailable: primary Python lacked psutil; recorded zero is missing sampling, not zero memory.'))
print(json.dumps(dict(grid_effect=group_summary(groups),descriptive=descriptive),indent=2))
