"""Prospective complete-cohort displays; no filtering by observed gain."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
W=Path(__file__).parent;A=W/'study/analysis/holdout';P=W/'source-r2/images'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':8.5,'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
regimes=['snr0_narrow','snr0_broad','snr30_narrow','snr30_broad'];regime_labels=['0 dB / narrow','0 dB / broad','30 dB / narrow','30 dB / broad'];colors=['#16637C','#D17A25','#6B4792','#42865D'];exports=[]
def save(fig,name):
 for ext in ('pdf','svg','png'):
  p=P/(name+'.'+ext);fig.savefig(p,bbox_inches='tight',dpi=190);exports.append({'path':str(p.relative_to(W)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 plt.close(fig)
summary=json.loads((A/'SUMMARY.json').read_text());contrasts=json.loads((A/'CONTRASTS.json').read_text());rows=list(csv.DictReader((A/'all-cells.csv').open()));assert len(contrasts)==44 and summary['complete']
fig,axes=plt.subplots(1,3,figsize=(6.6,2.65),gridspec_kw={'width_ratios':[1.65,1,1]})
keys=['T_minus_FU_SCA','T_minus_THU_IDE','T_minus_W','T_minus_S'];labels=['Fu-SCA\n2026*','Thu-IDE\n2026*','Matching\nWMMSE','SLSQP']
for j,key in enumerate(keys):
 for ri,regime in enumerate(regimes):
  vals=[r[key] for r in contrasts if r['regime']==regime];xx=j+np.linspace(-.24,.24,11)+(.025*(ri-1.5));axes[0].scatter(xx,vals,color=colors[ri],s=7.5,alpha=.67,marker=['o','s','^','d'][ri],label=regime_labels[ri] if j==0 else None)
 effect=summary['effects'][key];axes[0].plot([j-.26,j+.26],[effect['mean']]*2,color='black',lw=1.2)
axes[0].set_xticks(range(4),labels);axes[0].set_ylabel('T − comparator SE (bit/s/Hz)');axes[0].set_title('All 44 cases per contrast');axes[0].axhline(0,color='.35',lw=.7);axes[0].legend(frameon=False,ncol=2,loc='upper center',bbox_to_anchor=(.5,-.28),columnspacing=.7,handletextpad=.3,fontsize=6.2)
for ax,metric,scale,threshold,title,ylabel in [(axes[1],'absolute',1,.1,'Absolute primary effect','SE difference (bit/s/Hz)'),(axes[2],'relative',100,5,'Relative primary effect','Relative difference (%)')]:
 for j,envelope in enumerate(['modern','all']):
  e=summary['effects'][metric+'_'+envelope];mean=e['mean']*scale;lo,hi=np.array(e['interval95'])*scale
  groups=np.array(e['group_effects'])*scale;ax.scatter(j+np.linspace(-.18,.18,11),groups,s=10,color='#35758A',alpha=.65)
  ax.errorbar(j,mean,yerr=[[mean-lo],[hi-mean]],fmt='D',color='black',capsize=3,ms=4,lw=1.2)
 ax.axhline(0,color='.45',lw=.6);ax.axhline(threshold,color='#A32F38',ls='--',lw=.8);ax.set_xticks([0,1],['Modern\nenvelope','All four\nbaselines']);ax.set_ylabel(ylabel);ax.set_title(title)
for ax in axes:ax.grid(axis='y',alpha=.14)
fig.tight_layout(w_pad=1.1);fig.subplots_adjust(bottom=.31);save(fig,'r2-modern-comparison')
arms=['T','W','S','FU_SCA','THU_IDE'];arm_labels=['Transfer T','Matching WMMSE','SLSQP','Fu-SCA (adapted)','Thu-IDE (adapted)'];arm_colors=['#113B5E','#417D54','#8E5292','#D47729','#B14240']
fig,axes=plt.subplots(1,2,figsize=(6.6,2.4))
for j,arm in enumerate(arms):
 selected=[r for r in rows if r['arm']==arm];times=[float(r['charged_actual']) for r in selected];minimum=[float(r['minimum_user_SE']) for r in selected]
 axes[0].scatter(j+np.linspace(-.2,.2,len(times)),times,s=7,color=arm_colors[j],alpha=.6);axes[0].plot([j-.23,j+.23],[np.mean(times)]*2,color=arm_colors[j],lw=1.4)
 axes[1].scatter(j+np.linspace(-.2,.2,len(minimum)),minimum,s=7,color=arm_colors[j],alpha=.6)
for ax in axes:ax.set_xticks(range(5),['T','W','S','Fu*','Thu*']);ax.grid(axis='y',alpha=.15)
axes[0].axhline(20,color='.4',ls='--',lw=.8);axes[0].set_ylabel('Charged time (s)');axes[0].set_title('All cells;20-s allowance');axes[1].set_ylabel('Minimum-user SE (bit/s/Hz)');axes[1].set_title('All cells;no fairness objective');fig.tight_layout();save(fig,'r2-modern-cost-fairness')
# True checked-incumbent histories, using completed receipt timestamps. Before
# the virtual common4s no value is shown; after that retain the last timely value.
grid=np.linspace(4,20,65);fig,axes=plt.subplots(2,2,figsize=(6.6,4),sharex=True)
inputs=json.loads((W/'study/holdout-INPUTS.json').read_text())['inputs']
for ri,regime in enumerate(regimes):
 ax=axes.flat[ri]
 for ai,arm in enumerate(arms):
  histories=[]
  for inp in inputs:
   if inp['regime']!=regime:continue
   directory=W/'study/cells'/f'{inp["id"]}-{arm}';result=json.loads((directory/'result.json').read_text());points=[]
   for receipt in result['receipts']:
    if not receipt['timely']:continue
    check=json.loads((directory/receipt['file']).read_text());value=float(__import__('fractions').Fraction(check['verification']['lower_nats']))/(4*np.log(2));t=4+receipt['completed_at']-result['started_at'];points.append((t,value))
   points.sort();base=points[0][1];trajectory=[]
   for t in grid:
    eligible=[v for tt,v in points if tt<=t];trajectory.append(max(eligible)-base if eligible else np.nan)
   histories.append(trajectory)
  with np.errstate(invalid='ignore'):mean=np.nanmean(histories,axis=0)
  ax.plot(grid,mean,label=arm_labels[ai],color=arm_colors[ai],lw=1.2)
 ax.set_title(regime_labels[ri]);ax.grid(alpha=.15);ax.set_ylabel('Gain over common anchor\n(bit/s/Hz)')
for ax in axes[-1]:ax.set_xlabel('Charged receipt-completion time (s)')
axes.flat[0].legend(frameon=False,fontsize=6.2);fig.tight_layout();save(fig,'r2-checked-histories')
manifest={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'summary_sha256':hashlib.sha256((A/'SUMMARY.json').read_bytes()).hexdigest(),'contrasts_sha256':hashlib.sha256((A/'CONTRASTS.json').read_bytes()).hexdigest(),'all_44_cases':True,'all_11_seed_groups':True,'diagnostic_labels':'Fu/Thu optimization-component adapters;*TCOM2026, Thu acceptedv1','exports':exports}
(W/'editorial/MODERN_FIGURE_MANIFEST.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'exports':len(exports),'primary_success':summary['substantial_primary'],'broad_success':summary['broad_substantial']}))
