from pathlib import Path
import sys,platform,json,hashlib,importlib.metadata,winreg
from datetime import datetime,timezone
W=Path(__file__).parent
versions={name:importlib.metadata.version(name) for name in ('numpy','scipy','sympy','matplotlib','psutil')}
with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:cpu=winreg.QueryValueEx(key,'ProcessorNameString')[0]
metadata=[]
for name in versions:
 dist=importlib.metadata.distribution(name)
 for f in dist.files or []:
  if str(f).endswith('.dist-info/METADATA'):
   p=dist.locate_file(f);metadata.append({'package':name,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});break
result={'recorded_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'cpu':cpu,'packages':versions,'distribution_metadata':metadata,'timing_scope':'Supplementary package/host record captured afterpilot and beforelegacy/holdout. NumPy/Pythongeneratorversions were recorded beforeeachgeneratedcohort; no installations or environment changes occurred. Do not label this broader capture as pre-pilot.'}
(W/'study/ENVIRONMENT.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
