"""Regression for both independent-audit blockers and lossless diagnostics."""
import time
START=time.monotonic()
from pathlib import Path
import sys,json,copy,shutil,gzip,hashlib
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];sys.path.insert(0,str(HERE))
from io_utils import publish,digest,publish_diagnostics,operational_failure
import run_study as runner
import analyze_study as analysis
out=W/'study/a02-repair-fixtures';out.mkdir(exist_ok=False);checks={}
fixture=W/'study/controller-fixtures/case.json';row=dict(id='controller-deterministic',path=str(fixture),sha256=digest(fixture),solver_seed=1,ordinal=0)
broken=dict(valid=True,status='RETURNED',returncode=0,errors=[],worker_status=dict(normal=False,status='WORKER_ERROR'),schedule=[])
fake=out/'common-error';(fake/'study').mkdir(parents=True);publish(fake/'study/pilot-INPUTS.json',{'inputs':[row]});calls=[]
def injected(*args,**kwargs):calls.append(args[1]);return broken
with patch.object(runner,'W',fake),patch.object(runner,'gate',lambda name:None),patch.object(runner,'approved_sources',lambda phase:None),patch.object(runner,'launch',injected):
 try:runner.run('pilot');checks['F01_halts_before_arm']=False
 except RuntimeError:checks['F01_halts_before_arm']=calls==['COMMON_GRID']
checks['explicit_worker_failure_rejected']=operational_failure(broken)
timeout=dict(valid=True,status='DEADLINE_KILL',returncode=1,errors=[],worker_status=None)
checks['legitimate_timeout_allowed']=not operational_failure(timeout)
checks['unexpected_exit_rejected']=operational_failure(dict(timeout,status='RETURNED',returncode=1))
# Use real checked reference records unchanged as the baseline. One failed worker
# must make an otherwise complete/valid set ineligible without deleting its rate.
ref='orthogonal-2026113601';inp=json.loads((W/'study/reference-dev-INPUTS.json').read_text())['inputs'][0]
fake=out/'analysis';(fake/'study').mkdir(parents=True);(fake/'protocol-v2').mkdir();shutil.copyfile(W/'protocol-v2/PROTOCOL.json',fake/'protocol-v2/PROTOCOL.json');publish(fake/'study/pilot-INPUTS.json',{'inputs':[inp]})
for arm in runner.ARMS:
 src=W/'study/references'/ref/arm;dest=fake/'study/cells'/f'{ref}-{arm}';shutil.copytree(src,dest)
with patch.object(analysis,'W',fake):
 before=analysis.analyze('pilot')
 checks['real_receipt_baseline_complete']=before['complete']
 bad=fake/'study/cells'/f'{ref}-T'/'result.json';obj=json.loads(bad.read_text());obj['worker_status']['normal']=False;obj['worker_status']['status']='WORKER_ERROR';bad.write_text(json.dumps(obj))
 # A new directory retains the good analysis; no result overwriting.
 shutil.copyfile(fake/'study/pilot-INPUTS.json',fake/'study/legacy-INPUTS.json');after=analysis.analyze('legacy')
 checks['F02_one_failed_worker_withholds_complete_and_primary']=not after['complete'] and not after['primary_evaluable'] and not after['substantial_primary']
 retained=list(__import__('csv').DictReader((fake/'study/analysis/legacy/all-cells.csv').open()))
 checks['failed_worker_rate_retained']=len(retained)==5 and all(x.get('SE') for x in retained)
 good=json.loads((W/'study/references'/ref/'S/result.json').read_text());goodinp=dict(inp)
 checks['valid_receipt_chain']=analysis.retained_receipt_errors(W/'study/references'/ref/'S',good,goodinp,'S')==[]
 altered=copy.deepcopy(good);altered['lower_nats']='999';checks['lower_receipt_mismatch_rejected']=bool(analysis.retained_receipt_errors(W/'study/references'/ref/'S',altered,goodinp,'S'))
 altered=copy.deepcopy(good);altered['receipts'][0]['completed_at']=altered['deadline']+1
 # Find and corrupt the retained receipt, not an unrelated earlier record.
 for r in altered['receipts']:
  if r['file']==altered['best_receipt']:r['completed_at']=altered['deadline']+1
 checks['late_retained_receipt_rejected']=bool(analysis.retained_receipt_errors(W/'study/references'/ref/'S',altered,goodinp,'S'))
payload={'phase_records':[{'evaluations':i,'status':'deadline'} for i in range(100)],'errors':[]};sidecar=publish_diagnostics(out/'roundtrip.json.gz',payload)
checks['lossless_diagnostics']=json.loads(gzip.decompress((out/'roundtrip.json.gz').read_bytes()))==payload and digest(out/'roundtrip.json.gz')==sidecar['sha256']
anchor={'schedule':json.loads((W/'study/controller-fixtures/common/result.json').read_text())['schedule']}
r=runner.launch(row,'T',out/'serialized-T',anchor,actual_seconds=2,search_seconds=1,virtual_seconds=0)
checks['new_worker_serialization_integrated']=not operational_failure(r) and bool((r.get('worker_status') or {}).get('diagnostics_sidecar')) and analysis.retained_receipt_errors(out/'serialized-T',r,row,'T')==[]
result=dict(checks=checks,passed=all(checks.values()),seconds=time.monotonic()-START,scope='Correctness/control-flow fixtures only; synthetic error injection and copied reference outcomes never performance evidence')
publish(out/'RESULT.json',result);print(json.dumps(result));assert result['passed']
