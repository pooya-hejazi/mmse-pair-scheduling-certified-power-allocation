"""Serial matched-budget campaign with immutable independent receipts."""
from pathlib import Path
import os,sys,time,json,subprocess,argparse,hashlib
from fractions import Fraction as F
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];R=W.parents[1]
sys.path[:0]=[str(HERE),str(W/'baseline-code')]
import verify_upper
from io_utils import publish,digest,universal,Ledger,utc,operational_failure
PYTHON=Path('C:/ProgramData/anaconda3/python.exe')
ARMS=['T','W','S','FU_SCA','THU_IDE']
END_UTC='2026-11-03T07:41:57+00:00'

def ensure_time():
 from datetime import datetime
 if datetime.fromisoformat(utc())>=datetime.fromisoformat(END_UTC):raise RuntimeError('whole-phase wall cap reached')
def gate(name):
 for attempt in ('A02','A01'):
  p=R/'audit/reviews'/f'{name}-{attempt}'/'DECISION.json'
  if p.exists():
   if json.loads(p.read_text(encoding='utf-8-sig')).get('verdict')=='PASS':return
   raise RuntimeError(name+' newest verdict not PASS')
 raise RuntimeError(name+' no independent decision')

def launch(row,method,out,anchor=None,actual_seconds=16,search_seconds=11,virtual_seconds=4):
 ensure_time();out=Path(out);out.mkdir(parents=True,exist_ok=False)
 start=time.monotonic();deadline=start+actual_seconds;search_deadline=start+search_seconds
 case_path=Path(row['path']);case=json.loads(case_path.read_text());assert digest(case_path)==row['sha256']
 attempt=dict(case_id=row['id'],method=method,case_sha256=row['sha256'],started_at=start,deadline=deadline,search_deadline=search_deadline,virtual_seconds=virtual_seconds,charged_allowance=actual_seconds+virtual_seconds,utc=utc(),solver_seed=row.get('solver_seed',0))
 publish(out/'attempt.json',attempt);verify_upper.clear_caches()
 best=None;receipts=[];errors=[];late=[];verification_timeouts=[];seen=set();proc=None;status='RETURNED';peak=0;verify_seconds=0
 try:import psutil
 except ImportError:psutil=None
 def accept(path):
  nonlocal best,verify_seconds
  if time.monotonic()>=deadline:late.append(path.name);return
  payload=json.loads(path.read_text());proof=universal(case)
  before=time.monotonic()
  checked=verify_upper.verify(case,{'proof':proof,'schedule':payload['schedule']},seconds=max(0,deadline-time.monotonic()))
  verify_seconds+=time.monotonic()-before
  if time.monotonic()>=deadline:late.append(path.name);return
  rec=dict(candidate_file=path.name,candidate_sha256=digest(path),case_sha256=row['sha256'],attempt_sha256=digest(out/'attempt.json'),validated_at=time.monotonic(),verification=checked)
  name=f'receipt-{len(receipts):06d}.json';pub=publish(out/name,rec);timely=pub['completed_at']<=deadline
  receipts.append(dict(file=name,sha256=pub['sha256'],completed_at=pub['completed_at'],timely=timely))
  if timely and (best is None or F(checked['lower_nats'])>F(best['verification']['lower_nats'])):
   best=dict(schedule=payload['schedule'],verification=checked,receipt=name,completed_at=pub['completed_at'])
 if anchor is None:
  p=min(F(case['pmax']),F(case['budget'])/case['K']);initial=[dict(users=[2*s,2*s+1],resource=s,powers=[str(p),str(p)]) for s in range(case['S'])]
 else:initial=anchor['schedule']
 publish(out/'fallback.json',dict(schedule=initial,status='CHECKED_COMMON_ANCHOR' if anchor else 'UNIFORM'))
 try:accept(out/'fallback.json')
 except Exception as e:errors.append(dict(stage='fallback',error=repr(e)))
 if best is None:
  result=dict(attempt,status='MISSING_CHECKED_FALLBACK',errors=errors,receipts=receipts,elapsed=time.monotonic()-start,valid=False)
  publish(out/'result.json',result);return result
 command=[str(PYTHON),'-B',str(HERE/'worker.py'),'--case',str(case_path),'--output',str(out),'--method',method,'--search-deadline',str(search_deadline),'--seed',str(row.get('solver_seed',0))]
 if anchor is not None:
  publish(out/'anchor.json',anchor);command+=['--anchor',str(out/'anchor.json')]
 with (out/'worker.log').open('xb') as log:
  try:
   if time.monotonic()<search_deadline:
    proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    procinfo=psutil.Process(proc.pid) if psutil else None
    while True:
     for path in sorted(out.glob('candidate-*.json')):
      if path.name in seen:continue
      seen.add(path.name)
      try:accept(path)
      except TimeoutError:verification_timeouts.append(path.name)
      except Exception as e:errors.append(dict(stage='candidate_check',file=path.name,error=repr(e)))
     if procinfo:
      try:peak=max(peak,procinfo.memory_info().rss)
      except psutil.Error:pass
     if proc.poll() is not None:
      # Close exit-after-directory-scan race.
      for path in sorted(out.glob('candidate-*.json')):
       if path.name not in seen:
        seen.add(path.name)
        try:accept(path)
        except TimeoutError:verification_timeouts.append(path.name)
        except Exception as e:errors.append(dict(stage='exit_check',file=path.name,error=repr(e)))
      break
     if time.monotonic()>=deadline:
      status='DEADLINE_KILL';proc.kill();proc.wait();break
     time.sleep(.01)
   else:status='NO_SEARCH_TIME'
  finally:
   if proc is not None and proc.poll() is None:proc.kill();proc.wait()
 worker_path=out/'worker-status.json';worker=json.loads(worker_path.read_text()) if worker_path.exists() else None
 result=dict(attempt,status=status,valid=True,schedule=best['schedule'],lower_nats=best['verification']['lower_nats'],upper_nats=best['verification']['upper_nats'],incumbent_upper_nats=best['verification']['incumbent_upper_nats'],best_receipt=best['receipt'],receipts=receipts,errors=errors,late_candidates=late,verification_timeouts=verification_timeouts,worker_status=worker,returncode=proc.returncode if proc else None,elapsed=time.monotonic()-start,charged_actual=virtual_seconds+time.monotonic()-start,verification_seconds=verify_seconds,peak_RSS_bytes=peak,all_seen_candidates=sorted(seen))
 publish(out/'result.json',result);return result

def source_manifest():
 rows=[]
 for p in sorted((W/'method').rglob('*.py')):
  if '__pycache__' not in p.parts:rows.append(dict(path=p.relative_to(W).as_posix(),sha256=digest(p)))
 return rows

def approved_sources(phase):
 marker=json.loads((W/'study'/('APPROVED_HOLDOUT.json' if phase=='holdout' else 'APPROVED_METHOD.json')).read_text())
 for row in marker['files']:
  p=W/row['path'];assert digest(p)==row['sha256'],'source drift: '+row['path']
 assert marker['verdict']=='PASS'
 return marker

def run(phase):
 gate('CP-METHOD-CR033')
 if phase=='holdout':gate('CP-PILOT-CR033')
 approved_sources(phase)
 inputs=json.loads((W/'study'/f'{phase}-INPUTS.json').read_text())['inputs']
 ledger=Ledger(W/'study/RESOURCE_LEDGER.jsonl');results=[]
 for row in inputs:
  ensure_time();common_id='common-'+row['id'];common_dir=W/'study/common'/row['id']
  ledger.reserve(common_id,4,bucket='shared',input_sha256=row['sha256'])
  begin=time.monotonic();common=launch(row,'COMMON_GRID',common_dir,actual_seconds=4,search_seconds=3,virtual_seconds=0);ledger.finish(common_id,time.monotonic()-begin)
  if operational_failure(common):raise RuntimeError('Common preprocessing missing fallback or unexpected worker/checker failure: halt before any arm')
  anchor=dict(schedule=common['schedule'],case_sha256=row['sha256'],common_result_sha256=digest(common_dir/'result.json'),common_receipt=common['best_receipt'])
  order=ARMS[row['ordinal']%5:]+ARMS[:row['ordinal']%5]
  for arm in order:
   ident=row['id']+'-'+arm;ledger.reserve(ident,20,bucket='cells',input_sha256=row['sha256'],arm=arm)
   begin=time.monotonic();result=launch(row,arm,W/'study/cells'/ident,anchor);ledger.finish(ident,4+time.monotonic()-begin)
   results.append(dict(case_id=row['id'],arm=arm,result=result))
   print(json.dumps({'case':row['id'],'arm':arm,'valid':result['valid'],'status':result['status'],'seconds':result['elapsed'],'ledger_reserved_or_actual':ledger.charged()}),flush=True)
   if operational_failure(result):raise RuntimeError('Invalid/missing/check-failed or worker-bug cell: halt without resampling')
  if phase=='legacy':
   guard=json.loads((W/'study/LEGACY_UPPER_GUARD.json').read_text())
   bound=guard[row['id']];assert bound['input_sha256']==row['sha256']
   for arm in ARMS:
    rr=json.loads((W/'study/cells'/f'{row["id"]}-{arm}'/'result.json').read_text())
    if F(rr['lower_nats'])>F(bound['upper_nats']):raise RuntimeError('New lower above old verified upper: integrity halt')
 approved_sources(phase)
 publish(W/'study'/f'{phase}-RUN_COMPLETE.json',{'phase':phase,'cells':len(results),'source_files':source_manifest(),'utc':utc(),'all_valid':all(x['result']['valid'] for x in results)})

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['pilot','legacy','holdout']);run(ap.parse_args().phase)
