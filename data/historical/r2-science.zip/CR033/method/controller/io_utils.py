"""Immutable JSON publication and parent-only resource accounting."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,time,uuid,gzip

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def object_digest(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def publish(path,obj):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists():raise FileExistsError(path)
 data=(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
 tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.partial')
 with tmp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.link(tmp,path);tmp.unlink()
 return {'sha256':hashlib.sha256(data).hexdigest(),'completed_at':time.monotonic(),'bytes':len(data)}
def universal(case):return {'schema':'MMSE_PARTITION_PROOF_V1','case_sha256':object_digest(case),'universal':True,'dual':None,'spatial':None}
def utc():return datetime.now(timezone.utc).isoformat()

def operational_failure(result):
 """An available feasible fallback does not conceal an unexpected worker bug."""
 if not result.get('valid') or result.get('errors'):return True
 worker=result.get('worker_status')
 if worker is not None and (worker.get('normal') is False or worker.get('status') in ('error','WORKER_ERROR')):return True
 if result.get('status')=='RETURNED':
  return result.get('returncode')!=0 or worker is None or worker.get('normal') is not True
 return result.get('status') not in ('DEADLINE_KILL','NO_SEARCH_TIME')

def publish_diagnostics(path,obj):
 """Lossless compact sidecar, with original diagnostics fully retained."""
 path=Path(path)
 if path.exists():raise FileExistsError(path)
 encoded=json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
 data=gzip.compress(encoded,compresslevel=6,mtime=0);tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.partial')
 with tmp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.link(tmp,path);tmp.unlink()
 return {'file':path.name,'sha256':hashlib.sha256(data).hexdigest(),'uncompressed_sha256':hashlib.sha256(encoded).hexdigest(),'bytes':len(data),'uncompressed_bytes':len(encoded),'completed_at':time.monotonic()}

class Ledger:
 """One controller writer; worker test budgets are separately reserved leases."""
 caps={'correctness':480,'references':480,'generation_analysis':180,'shared':208,'cells':5200,'contingency':300}
 def __init__(self,path,limit=7200):self.path=Path(path);self.limit=limit;self.path.parent.mkdir(parents=True,exist_ok=True)
 def rows(self):return [json.loads(s) for s in self.path.read_text().splitlines()] if self.path.exists() else []
 def charged(self):
  records=self.rows();reserve={r['id']:r['seconds'] for r in records if r['event']=='reserve'}
  actual={r['id']:r['seconds'] for r in records if r['event']=='finish'}
  return sum(max(v,actual.get(k,0)) for k,v in reserve.items())
 def append(self,row):
  row['utc']=utc()
  with self.path.open('a',encoding='utf-8') as f:f.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
 def reserve(self,ident,seconds,bucket,**metadata):
  assert not any(r.get('id')==ident for r in self.rows()),'immutable task ID already reserved'
  assert bucket in self.caps
  assert sum(r['seconds'] for r in self.rows() if r['event']=='reserve' and r['bucket']==bucket)+seconds<=self.caps[bucket],'fixed category allocation'
  assert self.charged()+seconds<=self.limit,'scientific resource cap'
  self.append(dict(event='reserve',id=ident,seconds=seconds,bucket=bucket,**metadata))
 def finish(self,ident,seconds,**metadata):
  assert any(r.get('id')==ident and r['event']=='reserve' for r in self.rows())
  assert not any(r.get('id')==ident and r['event']=='finish' for r in self.rows())
  self.append(dict(event='finish',id=ident,seconds=seconds,**metadata))
  assert self.charged()<=self.limit,'actual overrun crossed global cap: stop'
  reserves={r['id']:r for r in self.rows() if r['event']=='reserve'}
  excess=sum(max(0,r['seconds']-reserves[r['id']]['seconds']) for r in self.rows() if r['event']=='finish')
  contingency_used=sum(r['seconds'] for r in reserves.values() if r['bucket']=='contingency')
  assert excess+contingency_used<=self.caps['contingency'],'cleanup/overrun contingency exhausted'
