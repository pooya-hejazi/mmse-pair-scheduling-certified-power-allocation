"""Prespecified eight orthogonal references; no efficacy pooling."""
from pathlib import Path
from fractions import Fraction as F
import sys,time,json,subprocess,argparse
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];sys.path.insert(0,str(HERE))
from io_utils import Ledger,publish,digest
from run_study import launch,gate,ensure_time,ARMS,PYTHON

def run(phase):
 gate('CP-PLAN-CR033')
 if phase=='reference-holdout':gate('CP-PILOT-CR033')
 manifest=json.loads((W/'study'/f'{phase}-INPUTS.json').read_text());ledger=Ledger(W/'study/RESOURCE_LEDGER.jsonl');allrows=[]
 for inp in manifest['inputs']:
  ensure_time();ident=inp['id'];ledger.reserve(ident,60,bucket='references',scope='orthogonal correctness only');start=time.monotonic();deadline=start+60
  out=W/'study/references'/ident;out.mkdir(parents=True,exist_ok=False)
  result=subprocess.run([str(PYTHON),'-B',str(HERE/'reference_worker.py'),'--case',inp['path'],'--output',str(out/'reference.json'),'--deadline',str(start+20)],capture_output=True,text=True,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  publish(out/'reference-log.json',dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
  assert result.returncode==0
  ref=json.loads((out/'reference.json').read_text());assert ref['status']=='certified' and ref['assignments_completed']==6 and F(ref['upper_nats'])-F(ref['lower_nats'])<=F(1,10**6)
  case=json.loads(Path(inp['path']).read_text());p=min(F(case['pmax']),F(case['budget'])/case['K']);anchor={'schedule':[dict(users=[2*s,2*s+1],resource=s,powers=[str(p),str(p)]) for s in range(case['S'])]}
  arms=[]
  for index,arm in enumerate(ARMS):
   rr=launch(dict(inp,solver_seed=inp['seed']),arm,out/arm,anchor,actual_seconds=6,search_seconds=5,virtual_seconds=0)
   assert rr['valid'] and not rr['errors'] and (rr.get('worker_status') or {}).get('normal') is not False
   assert F(rr['lower_nats'])<=F(ref['upper_nats']),'heuristic exceeds independent upper'
   arms.append(dict(arm=arm,lower_nats=rr['lower_nats'],reference_upper_nats=ref['upper_nats'],deficit_upper_nats=float(F(ref['upper_nats'])-F(rr['lower_nats'])),status=rr['status']))
  elapsed=time.monotonic()-start;assert elapsed<60
  checked=dict(case_id=ident,reference=ref,arms=arms,elapsed=elapsed,scope='orthogonal subclass global reference;6-second diagnostic arms, not20-second performance')
  publish(out/'CHECKED.json',checked);ledger.finish(ident,time.monotonic()-start);allrows.append(checked);print(json.dumps({'id':ident,'elapsed':elapsed,'gap':ref['gap_nats']}),flush=True)
 publish(W/'study'/f'{phase}-COMPLETE.json',dict(phase=phase,references=allrows,passed=True))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['reference-dev','reference-holdout']);run(ap.parse_args().phase)
