import time
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import sys,json,argparse
HERE=Path(__file__).resolve().parent;sys.path[:0]=[str(HERE),str(HERE.parent/'core')]
from io_utils import publish
from reference_orthogonal import solve
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--output',required=True);ap.add_argument('--deadline',type=float,required=True);a=ap.parse_args();result=solve(json.loads(Path(a.case).read_text()),a.deadline);publish(a.output,result)
