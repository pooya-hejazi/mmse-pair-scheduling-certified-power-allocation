"""Frozen all-case analysis; no solver or outcome-dependent case selection."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,csv,math,argparse,time,hashlib
import numpy as np
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];sys.path.insert(0,str(HERE))
from io_utils import publish,digest,operational_failure
ARMS=['T','W','S','FU_SCA','THU_IDE']

def rates(case,schedule):
 lookup={(x['users'][0],x['users'][1],x['resource']):tuple(map(F,(x['gain1'],x['gain2'],x['r']))) for x in case['pairs']};r=[0.]*case['K'];p=[F(0)]*case['K']
 for row in schedule:
  u,v=row['users'];s=row['resource'];p[u],p[v]=map(F,row['powers']);g,h,rho=lookup[u,v,s];x,y=g*p[u],h*p[v]
  r[u]=math.log1p(float(x*((1-rho)+rho/(1+y))))/math.log(2)/case['S'];r[v]=math.log1p(float(y*((1-rho)+rho/(1+x))))/math.log(2)/case['S']
 assert sorted(i for x in schedule for i in x['users'])==list(range(case['K']))
 assert all(F(case['pmin'])<=q<=F(case['pmax']) for q in p) and sum(p)<=F(case['budget'])
 den=sum(x*x for x in r);jain=(sum(r)**2/(len(r)*den)) if den>0 else None
 return dict(user_SE=r,Jain=jain,minimum_user_SE=min(r),power_W=float(sum(p)),budget_slack_W=float(F(case['budget'])-sum(p)))

def group_summary(values,seed=2026110399):
 values=np.asarray(values,float);rng=np.random.Generator(np.random.PCG64(seed));index=rng.integers(0,len(values),size=(20000,len(values)));means=values[index].mean(axis=1)
 return dict(mean=float(values.mean()),interval95=np.quantile(means,[.025,.975]).tolist(),group_effects=values.tolist(),leave_one_group_out=[float(np.delete(values,i).mean()) for i in range(len(values))],bootstrap_seed=seed,replicates=20000)

def retained_receipt_errors(directory,result,inp,arm):
 """Check immutable retained-value provenance without trusting valid=True."""
 errors=[]
 try:
  directory=Path(directory);receipt_name=result['best_receipt'];assert Path(receipt_name).name==receipt_name
  descriptor=next(x for x in result['receipts'] if x['file']==receipt_name)
  receipt_path=directory/receipt_name;assert digest(receipt_path)==descriptor['sha256']
  assert descriptor['timely'] and descriptor['completed_at']<=result['deadline']
  receipt=json.loads(receipt_path.read_text());attempt_path=directory/'attempt.json';attempt=json.loads(attempt_path.read_text())
  assert digest(attempt_path)==receipt['attempt_sha256']
  assert result['case_id']==inp['id'] and result['method']==arm and attempt['method']==arm
  assert result['case_sha256']==inp['sha256']==receipt['case_sha256']==attempt['case_sha256']
  assert attempt['started_at']==result['started_at'] and attempt['deadline']==result['deadline']
  assert attempt['started_at']<=receipt['validated_at']<=descriptor['completed_at']<=attempt['deadline']
  name=receipt['candidate_file'];assert Path(name).name==name
  candidate_path=directory/name;assert digest(candidate_path)==receipt['candidate_sha256']
  candidate=json.loads(candidate_path.read_text());verification=receipt['verification']
  assert verification['valid'] and candidate['schedule']==result['schedule']
  for field in ('lower_nats','upper_nats','incumbent_upper_nats'):assert F(result[field])==F(verification[field])
  sidecar=(result.get('worker_status') or {}).get('diagnostics_sidecar')
  if sidecar:
   assert Path(sidecar['file']).name==sidecar['file'];sp=directory/sidecar['file'];assert digest(sp)==sidecar['sha256']
   import gzip
   raw=gzip.decompress(sp.read_bytes());assert hashlib.sha256(raw).hexdigest()==sidecar['uncompressed_sha256']
 except (AssertionError,KeyError,ValueError,StopIteration,OSError) as exc:errors.append(type(exc).__name__+': '+str(exc))
 return errors

def analyze(phase):
 protocol=json.loads((W/'protocol-v2/PROTOCOL.json').read_text());manifest=json.loads((W/'study'/f'{phase}-INPUTS.json').read_text());inputs=manifest['inputs'];out=W/'study/analysis'/phase;out.mkdir(parents=True,exist_ok=False)
 rows=[];details=[];bycase={};source=[]
 for inp in inputs:
  assert digest(inp['path'])==inp['sha256'];case=json.loads(Path(inp['path']).read_text());bycase[inp['id']]={}
  for arm in ARMS:
   p=W/'study/cells'/f'{inp["id"]}-{arm}'/'result.json'
   base=dict(case_id=inp['id'],phase=phase,seed=inp.get('seed'),regime=inp.get('regime'),arm=arm)
   if not p.exists():rows.append(dict(base,status='UNRUN',valid=False));continue
   result=json.loads(p.read_text());source.append({'path':str(p.relative_to(W)),'sha256':digest(p)})
   if not result['valid']:rows.append(dict(base,status=result['status'],valid=False));continue
   lower=float(F(result['lower_nats']));upper=float(F(result['upper_nats']));metrics=rates(case,result['schedule'])
   integrity=retained_receipt_errors(p.parent,result,inp,arm);operational_ok=not operational_failure(result)
   row=dict(base,status=result['status'],valid=True,operational_ok=operational_ok,integrity_ok=not integrity,integrity_errors='; '.join(integrity),SE=lower/(case['S']*math.log(2)),upper_SE=upper/(case['S']*math.log(2)),lower_nats=lower,upper_nats=upper,charged_actual=result['charged_actual'],charged_allowance=result['charged_allowance'],actual_seconds=result['elapsed'],verification_seconds=result['verification_seconds'],peak_RSS_bytes=result['peak_RSS_bytes'],errors=len(result['errors']),worker_normal=(result.get('worker_status') or {}).get('normal',False),**{k:v for k,v in metrics.items() if k!='user_SE'})
   rows.append(row);bycase[inp['id']][arm]=row;details.append(dict(base,user_SE=metrics['user_SE'],worker_status=result.get('worker_status'),receipts=result['receipts'],schedule=result['schedule']))
 keys=list(dict.fromkeys(k for row in rows for k in row))
 with (out/'all-cells.csv').open('w',newline='',encoding='utf-8') as f:
  writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader();writer.writerows(rows)
 complete=len(rows)==len(inputs)*5 and all(row.get('valid') and row.get('operational_ok') and row.get('integrity_ok') and row.get('errors')==0 for row in rows)
 summary=dict(phase=phase,inputs=len(inputs),expected_cells=len(inputs)*5,completed_valid_cells=sum(bool(row.get('valid')) for row in rows),complete=complete,scope='Same-model power-component adapters, not full source architectures',primary_evaluable=False,substantial_primary=False,broad_substantial=False)
 contrasts=[]
 for inp in inputs:
  vals=bycase[inp['id']]
  if len(vals)<5:continue
  t=vals['T']['SE'];modern=max(vals['FU_SCA']['SE'],vals['THU_IDE']['SE']);allbest=max(vals[a]['SE'] for a in ARMS if a!='T')
  contrasts.append(dict(case_id=inp['id'],seed=inp.get('seed'),regime=inp.get('regime'),T=t,modern_envelope=modern,all_envelope=allbest,absolute_modern=t-modern,relative_modern=(t-modern)/modern if modern>0 else None,absolute_all=t-allbest,relative_all=(t-allbest)/allbest if allbest>0 else None,**{f'T_minus_{a}':t-vals[a]['SE'] for a in ARMS if a!='T'}))
 if phase=='holdout' and complete and len(inputs)==44 and all(x['relative_modern'] is not None and x['relative_all'] is not None for x in contrasts):
  seeds=protocol['population']['holdout_seed_groups'];assert len(seeds)==11
  summaries={}
  for key in ('absolute_modern','relative_modern','absolute_all','relative_all','T_minus_W','T_minus_S','T_minus_FU_SCA','T_minus_THU_IDE'):
   groups=[]
   for seed in seeds:
    chosen=[x[key] for x in contrasts if x['seed']==seed];assert len(chosen)==4;groups.append(float(np.mean(chosen)))
   summaries[key]=group_summary(groups)
  summary['effects']=summaries;summary['primary_evaluable']=True
  summary['substantial_primary']=summaries['absolute_modern']['interval95'][0]>.1 and summaries['relative_modern']['interval95'][0]>.05
  summary['broad_substantial']=summary['substantial_primary'] and summaries['absolute_all']['interval95'][0]>.1 and summaries['relative_all']['interval95'][0]>.05
  summary['small_useful_secondary_all']=summaries['absolute_all']['interval95'][0]>.02
  summary['regimes']={reg['id']:{key:float(np.mean([x[key] for x in contrasts if x['regime']==reg['id']])) for key in ('absolute_modern','relative_modern','absolute_all','relative_all')} for reg in protocol['population']['regimes']}
 summary['resources']={arm:{'mean_actual':float(np.mean([r['actual_seconds'] for r in rows if r.get('valid') and r['arm']==arm])),'mean_charged':float(np.mean([r['charged_actual'] for r in rows if r.get('valid') and r['arm']==arm]))} for arm in ARMS if any(r.get('valid') and r['arm']==arm for r in rows)}
 publish(out/'SUMMARY.json',summary);publish(out/'CONTRASTS.json',contrasts);publish(out/'DETAILS.json',details);publish(out/'INPUT_MANIFEST.json',dict(results=source,protocol_sha256=digest(W/'protocol-v2/PROTOCOL.json'),analysis_sha256=digest(__file__),numpy=np.__version__))
 print(json.dumps(summary,indent=2));return summary

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['pilot','legacy','holdout']);analyze(ap.parse_args().phase)
