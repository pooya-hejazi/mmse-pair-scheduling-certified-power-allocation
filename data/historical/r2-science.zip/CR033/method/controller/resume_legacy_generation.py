from pathlib import Path
import sys,time,subprocess,json,zipfile,hashlib
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];R=W.parents[1]
sys.path.insert(0,str(HERE))
from io_utils import Ledger,publish
ledger=Ledger(W/'study/RESOURCE_LEDGER.jsonl');ident='generation-legacy-corrected-path-retry';ledger.reserve(ident,5,bucket='contingency',reason='Pre-experiment archive member disambiguation; original/corrected paths share basename, no legacy input/outcome written before failure')
start=time.monotonic();result=subprocess.run(['C:/ProgramData/anaconda3/python.exe','-B',str(HERE/'generate_inputs.py'),'legacy'],capture_output=True,text=True,timeout=5);ledger.finish(ident,time.monotonic()-start,returncode=result.returncode)
publish(W/'study/legacy-GENERATION_RETRY_LOG.json',{'stdout':result.stdout,'stderr':result.stderr,'returncode':result.returncode});print(result.stdout,result.stderr);assert result.returncode==0
archive=R/'output/TCOM-Submission-2026-11-02-R1/Supplementary_Materials.zip';guard={}
with zipfile.ZipFile(archive) as z:
 for row in json.loads((W/'study/legacy-INPUTS.json').read_text())['inputs']:
  matches=[n for n in z.namelist() if n.startswith('reproduction/studies/corrected/') and n.endswith('/result.json') and row['id'] in n and ('-full/' in n or '/full/' in n)]
  assert len(matches)==1,(row['id'],matches)
  result=json.loads(z.read(matches[0]));guard[row['id']]=dict(input_sha256=row['sha256'],upper_nats=result['upper_nats'],old_result_member=matches[0],old_result_sha256=hashlib.sha256(z.read(matches[0])).hexdigest())
publish(W/'study/LEGACY_UPPER_GUARD.json',guard)
