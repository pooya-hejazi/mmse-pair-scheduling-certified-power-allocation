"""Charged child. Numerical candidates are never publication receipts."""
import time
ENTERED=time.monotonic()
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import sys,json,argparse,traceback
HERE=Path(__file__).resolve().parent;METHOD=HERE.parent
sys.path[:0]=[str(HERE),str(METHOD/'core'),str(METHOD/'modern'),str(METHOD/'core/vendor')]
from io_utils import publish,publish_diagnostics

def run(a):
 out=Path(a.output);case=json.loads(Path(a.case).read_text());serial=0
 def candidate(assignment,powers,diagnostics):
  nonlocal serial
  if time.monotonic()>=a.search_deadline:return False
  c=problem.checked_candidate(assignment,powers)
  pub=publish(out/f'candidate-{serial:06d}.json',{'schedule':c['schedule'],'producer_lower_nats':str(c['lo']),'producer_upper_nats':str(c['hi']),'diagnostics':diagnostics,'producer_at':time.monotonic()})
  serial+=1;return pub['completed_at']<a.search_deadline
 if a.method=='COMMON_GRID':
  import grid_core
  grid_core.NATIVE_CAP=1.25
  def progress(payload):
   nonlocal serial
   if time.monotonic()>=a.search_deadline:return
   publish(out/f'candidate-{serial:06d}.json',payload);serial+=1
  grid_core.PROGRESS=progress
  remaining=a.search_deadline-time.monotonic()
  result=grid_core.solve(case,'grid',seconds=max(0,remaining)) if remaining>0 else {'status':'NO_TIME_AFTER_IMPORT'}
  if 'schedule' in result:progress(result)
  return {'status':result.get('status'),'diagnostics':{k:v for k,v in result.items() if k!='schedule'}}
 from problem import Problem
 import search
 problem=Problem(case)
 anchor=json.loads(Path(a.anchor).read_text())['schedule']
 refiners={}
 if a.method=='FU_SCA':
  from fu_sca import refine_power
  refiners[a.method]=refine_power
 elif a.method=='THU_IDE':
  from thu_ide import refine_power
  refiners[a.method]=refine_power
 result=search.run(a.method,problem,anchor,a.search_deadline,a.seed,candidate,refiners)
 c=result.get('candidate')
 if c is not None and time.monotonic()<a.search_deadline:candidate(c['assignment'],c['numeric'],result.get('diagnostics',{}))
 return {'status':result.get('status'),'diagnostics':result.get('diagnostics',{})}

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--output',required=True);ap.add_argument('--method',required=True);ap.add_argument('--anchor');ap.add_argument('--search-deadline',type=float,required=True);ap.add_argument('--seed',type=int,default=0);a=ap.parse_args()
 try:
  result=run(a)
  normal=result.get('status')!='error' and not result.get('diagnostics',{}).get('errors')
  result.update(normal=normal,entered=ENTERED,ended=time.monotonic())
 except Exception as e:result={'normal':False,'status':'WORKER_ERROR','error':repr(e),'traceback':traceback.format_exc(),'entered':ENTERED,'ended':time.monotonic()}
 if 'diagnostics' in result:
  diagnostic=result['diagnostics'];sidecar=publish_diagnostics(Path(a.output)/'worker-diagnostics.json.gz',diagnostic)
  result['diagnostics']={k:v for k,v in diagnostic.items() if k!='phase_records'}
  result['diagnostics_sidecar']=sidecar
 publish(Path(a.output)/'worker-status.json',result)
