"""Prospectively fixed controlled channels; holdout requires the pilot gate."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import sys,json,hashlib,argparse,time,zipfile
import numpy as np
W=Path(__file__).resolve().parents[2];R=W.parents[1]
sys.path.insert(0,str(Path(__file__).parent))
from io_utils import publish,digest,object_digest

def convert(h,name,metadata,pmin='1/20',pmax='1/5',budget=None):
 h=np.asarray(h,dtype=np.complex128);k,m,s=h.shape
 if not np.isfinite(h).all():raise ValueError('nonfinite channels')
 vectors={(i,t):[(F(float(z.real)),F(float(z.imag))) for z in h[i,:,t]] for i in range(k) for t in range(s)}
 gains={key:sum(x*x+y*y for x,y in val) for key,val in vectors.items()}
 pairs=[]
 for i,j in combinations(range(k),2):
  for t in range(s):
   re=sum(x*a+y*b for (x,y),(a,b) in zip(vectors[i,t],vectors[j,t]));im=sum(x*b-y*a for (x,y),(a,b) in zip(vectors[i,t],vectors[j,t]))
   g1,g2=gains[i,t],gains[j,t];rho=(re*re+im*im)/(g1*g2) if g1*g2 else F(0)
   assert 0<=rho<=1
   pairs.append(dict(users=[i,j],resource=t,gain1=str(g1),gain2=str(g2),r=str(rho)))
 metadata=dict(metadata,normalized_vector_sha256=object_digest({'re':h.real.tolist(),'im':h.imag.tolist()}),coefficient_sha256=object_digest(pairs))
 return dict(name=name,K=k,M=m,S=s,pmin=pmin,pmax=pmax,budget=budget or str(F(k,10)),pairs=pairs,channels_re=h.real.tolist(),channels_im=h.imag.tolist(),metadata=metadata)

def controlled(seed,regime,protocol):
 pop=protocol['population'];k,s,m=pop['K'],pop['S'],pop['M'];rng=np.random.Generator(np.random.PCG64(seed))
 angles=rng.uniform(-1,1,k);user=rng.uniform(-6,6,k);resource=rng.uniform(-3,3,(k,s))
 common=(rng.standard_normal((k,m))+1j*rng.standard_normal((k,m)))/np.sqrt(2*m)
 independent=(rng.standard_normal((k,m,s))+1j*rng.standard_normal((k,m,s)))/np.sqrt(2*m)
 theta=regime['angle_half_width_deg']*angles*np.pi/180
 steering=np.exp(1j*np.pi*np.arange(m)[None,:]*np.sin(theta)[:,None])/np.sqrt(m)
 vector=np.sqrt(10/11)*steering[:,:,None]+np.sqrt(1/11)*(np.sqrt(.8)*common[:,:,None]+np.sqrt(.2)*independent)
 norms=np.linalg.norm(vector,axis=1,keepdims=True)
 if np.any(norms<=0) or not np.isfinite(norms).all():raise ValueError('invalid direction; do not resample')
 gains=10**((regime['snr_db']+user[:,None]+resource)/10)/.1
 h=vector/norms*np.sqrt(gains)[:,None,:]
 metadata=dict(protocol='CR033_V2',seed=int(seed),regime=regime,latent_angle=angles.tolist(),user_offset_db=user.tolist(),resource_offset_db=resource.tolist(),numpy=np.__version__,noise_W=10**((-174+7-30)/10)*(50e6/512),interpretation=protocol['generator']['interpretation'],generator_formula_sha256=object_digest(protocol['generator']))
 return convert(h,f'{seed}-{regime["id"]}',metadata)

def orthogonal(seed):
 rng=np.random.Generator(np.random.PCG64(seed));n=rng.integers(0,21,size=(4,2));h=np.zeros((4,4,2),complex)
 for i in range(4):h[i,i,:]=(16+n[i,:])/16
 return convert(h,f'orthogonal-{seed}',{'protocol':'CR033_V2_REFERENCE','seed':seed,'n':n.tolist(),'numpy':np.__version__})

def gate(name):
 for attempt in ('A02','A01'):
  p=R/'audit/reviews'/f'{name}-{attempt}'/'DECISION.json'
  if p.exists():
   if json.loads(p.read_text(encoding='utf-8-sig')).get('verdict')=='PASS':return
   raise RuntimeError(name+' latest decision not PASS')
 raise RuntimeError(name+' PASS required')

def generate(phase):
 gate('CP-PLAN-CR033')
 if phase in ('holdout','reference-holdout'):gate('CP-PILOT-CR033')
 protocol=json.loads((W/'protocol-v2/PROTOCOL.json').read_text());out=W/'study/inputs';out.mkdir(parents=True,exist_ok=True);rows=[]
 if phase in ('pilot','holdout'):
  seeds=protocol['population'][phase+'_seed_groups'];base=0 if phase=='pilot' else 4
  for gi,seed in enumerate(seeds):
   for ri,regime in enumerate(protocol['population']['regimes']):
    case=controlled(seed,regime,protocol);p=out/(case['name']+'.json');publish(p,case)
    ordinal=base+gi*4+ri;rows.append(dict(id=case['name'],path=str(p),sha256=digest(p),ordinal=ordinal,seed=seed,regime=regime['id'],phase=phase,solver_seed=2026113500+ordinal))
 elif phase in ('reference-dev','reference-holdout'):
  seeds=protocol['exact_small_reference']['development_seeds' if phase=='reference-dev' else 'untouched_reference_seeds']
  for seed in seeds:
   case=orthogonal(seed);p=out/(case['name']+'.json');publish(p,case);rows.append(dict(id=case['name'],path=str(p),sha256=digest(p),seed=seed,phase=phase))
 elif phase=='legacy':
  archive=R/protocol['immutable_archive']['path'];assert digest(archive)==protocol['immutable_archive']['sha256']
  with zipfile.ZipFile(archive) as z:
   for idx,ident in enumerate(protocol['population']['legacy_external_check']):
    matches=[n for n in z.namelist() if n.startswith('reproduction/studies/corrected/inputs/') and n.endswith('/'+ident+'.json')];assert len(matches)==1,(ident,matches)
    data=z.read(matches[0]);p=out/(ident+'.json')
    with p.open('xb') as f:f.write(data)
    rows.append(dict(id=ident,path=str(p),sha256=digest(p),phase='legacy',ordinal=48+idx,solver_seed=2026113500+48+idx,archive_member=matches[0]))
 else:raise ValueError(phase)
 manifest=dict(phase=phase,protocol_sha256=digest(W/'protocol-v2/PROTOCOL.json'),generator_sha256=digest(__file__),numpy=np.__version__,python=sys.version,inputs=rows)
 publish(W/'study'/f'{phase}-INPUTS.json',manifest);return manifest

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['pilot','holdout','legacy','reference-dev','reference-holdout']);a=ap.parse_args();start=time.monotonic();m=generate(a.phase);print(json.dumps({'phase':a.phase,'inputs':len(m['inputs']),'seconds':time.monotonic()-start}))
