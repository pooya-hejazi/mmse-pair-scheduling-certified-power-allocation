"""Reserve fixed leases, create prospective pilot/legacy inputs; no performance."""
from pathlib import Path
from fractions import Fraction as F
import sys,time,subprocess,json,zipfile
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];R=W.parents[1]
sys.path.insert(0,str(HERE))
from io_utils import Ledger,publish,digest
ledger=Ledger(W/'study/RESOURCE_LEDGER.jsonl')
for owner,seconds in [('core',260),('modern',140),('root',80)]:ledger.reserve('correctness-'+owner,seconds,bucket='correctness',owner=owner)
python='C:/ProgramData/anaconda3/python.exe'
for phase in ('pilot','legacy'):
 ident='generation-'+phase;ledger.reserve(ident,10,bucket='generation_analysis');began=time.monotonic()
 result=subprocess.run([python,'-B',str(HERE/'generate_inputs.py'),phase],capture_output=True,text=True,timeout=10)
 ledger.finish(ident,time.monotonic()-began,returncode=result.returncode)
 publish(W/'study'/f'{phase}-GENERATION_LOG.json',{'stdout':result.stdout,'stderr':result.stderr,'returncode':result.returncode})
 print(result.stdout,result.stderr,flush=True);assert result.returncode==0
protocol=json.loads((W/'protocol-v2/PROTOCOL.json').read_text());archive=R/protocol['immutable_archive']['path'];guard={}
with zipfile.ZipFile(archive) as z:
 for row in json.loads((W/'study/legacy-INPUTS.json').read_text())['inputs']:
  matches=[n for n in z.namelist() if n.startswith('reproduction/studies/corrected/') and n.endswith('/result.json') and row['id'] in n and ('-full/' in n or '/full/' in n)]
  assert len(matches)==1,(row['id'],matches)
  result=json.loads(z.read(matches[0]));guard[row['id']]=dict(input_sha256=row['sha256'],upper_nats=result['upper_nats'],old_result_member=matches[0],old_result_sha256=__import__('hashlib').sha256(z.read(matches[0])).hexdigest())
publish(W/'study/LEGACY_UPPER_GUARD.json',guard)
