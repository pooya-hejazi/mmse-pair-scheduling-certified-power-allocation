"""Additional independent controller/generator/analysis failure fixtures."""
import time
START=time.monotonic()
from pathlib import Path
from fractions import Fraction as F
import sys,json,numpy as np
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];sys.path.insert(0,str(HERE))
from io_utils import publish,digest,universal
from run_study import launch,verify_upper
from generate_inputs import controlled,convert
from analyze_study import rates,group_summary
out=W/'study/integration-guard-fixtures';out.mkdir(exist_ok=False);checks={}
protocol=json.loads((W/'protocol-v2/PROTOCOL.json').read_text())
c1=controlled(4242,protocol['population']['regimes'][0],protocol);c2=controlled(4242,protocol['population']['regimes'][1],protocol)
checks['same_group_latent_offsets']=c1['metadata']['user_offset_db']==c2['metadata']['user_offset_db'] and c1['metadata']['resource_offset_db']==c2['metadata']['resource_offset_db']
checks['determinism']=c1==controlled(4242,protocol['population']['regimes'][0],protocol)
h=np.asarray(c1['channels_re'])+1j*np.asarray(c1['channels_im']);gain=np.sum(abs(h)**2,axis=1)
expected=10**((np.asarray(c1['metadata']['user_offset_db'])[:,None]+np.asarray(c1['metadata']['resource_offset_db']))/10)/.1
checks['prescribed_gains_and_positive_finite']=np.allclose(gain,expected,rtol=1e-12,atol=1e-12).item() if isinstance(np.allclose(gain,expected),np.bool_) else bool(np.allclose(gain,expected,rtol=1e-12,atol=1e-12))
checked_inputs=[]
for inp in json.loads((W/'study/pilot-INPUTS.json').read_text())['inputs']:
 case=json.loads(Path(inp['path']).read_text());p=min(F(case['pmax']),F(case['budget'])/case['K']);schedule=[dict(users=[2*s,2*s+1],resource=s,powers=[str(p),str(p)]) for s in range(case['S'])]
 answer=verify_upper.verify(case,{'proof':universal(case),'schedule':schedule},seconds=2);checked_inputs.append(answer['valid'])
checks['all_four_pilot_inputs_independently_valid']=all(checked_inputs)
zero=convert(np.zeros((4,4,2),complex),'zero',{});schedule=[dict(users=[2*s,2*s+1],resource=s,powers=['1/10','1/10']) for s in range(2)];r=rates(zero,schedule)
checks['all_zero_jain_null_minimum_zero']=r['Jain'] is None and r['minimum_user_SE']==0
g=group_summary([.2]*11);checks['bootstrap_keeps_groups']=abs(g['mean']-.2)<1e-14 and all(abs(x-.2)<1e-14 for x in g['interval95'])
fixture=W/'study/controller-fixtures/case.json';case=json.loads(fixture.read_text());row=dict(id='worker-error-fixture',path=str(fixture),sha256=digest(fixture),solver_seed=1)
r=launch(row,'INVALID_METHOD_FOR_FAILURE_FIXTURE',out/'worker-error',actual_seconds=3,search_seconds=2,virtual_seconds=0)
checks['worker_bug_visible_and_fallback_retained']=r['valid'] and (r.get('worker_status') or {}).get('normal') is False
checks['worker_bug_not_success']=r['worker_status']['status'] in ('WORKER_ERROR','error')
result=dict(checks=checks,passed=all(checks.values()),seconds=time.monotonic()-START,scope='correctness only; no optimization outcomes used for efficacy')
publish(out/'RESULT.json',result);print(json.dumps(result));assert result['passed']
