"""Owner records one bounded generation/analysis command; no implicit retries."""
from pathlib import Path
import sys,time,subprocess,json,argparse
HERE=Path(__file__).resolve().parent;W=HERE.parents[1];sys.path.insert(0,str(HERE))
from io_utils import Ledger,publish
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--seconds',required=True,type=float);ap.add_argument('--bucket',default='generation_analysis');ap.add_argument('command',nargs=argparse.REMAINDER);a=ap.parse_args();ledger=Ledger(W/'study/RESOURCE_LEDGER.jsonl')
 ledger.reserve(a.id,a.seconds,bucket=a.bucket,command=a.command);begin=time.monotonic()
 try:
  result=subprocess.run(a.command,capture_output=True,text=True,timeout=a.seconds,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));payload=dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
 except subprocess.TimeoutExpired as e:payload=dict(returncode=None,timeout=True,stdout=str(e.stdout),stderr=str(e.stderr))
 ledger.finish(a.id,time.monotonic()-begin,returncode=payload['returncode']);publish(W/'study/logs'/(a.id+'.json'),payload);print(json.dumps(payload,ensure_ascii=False));assert payload['returncode']==0
