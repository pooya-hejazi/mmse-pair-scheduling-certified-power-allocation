"""Deterministic controller correctness, never pilot/holdout performance."""
import time
START=time.monotonic()
from pathlib import Path
import sys,json,tempfile,shutil
import numpy as np
HERE=Path(__file__).resolve().parent;W=HERE.parents[1]
sys.path.insert(0,str(HERE))
from generate_inputs import convert
from io_utils import publish,digest,Ledger
from run_study import launch
out=W/'study/controller-fixtures';out.mkdir(exist_ok=False)
h=np.zeros((4,4,2),complex)
for i in range(4):h[i,i,:]=1+i/4
case=convert(h,'controller-deterministic',{'correctness_only':True});path=out/'case.json';publish(path,case)
row=dict(id=case['name'],path=str(path),sha256=digest(path),solver_seed=1)
checks={}
r=launch(row,'COMMON_GRID',out/'common',actual_seconds=4,search_seconds=3,virtual_seconds=0)
checks['common_checked']=r['valid'] and not r['errors'] and bool(r['receipts'])
checks['all_receipts_timely']=all(x['timely'] and x['completed_at']<=r['deadline'] for x in r['receipts'])
anchor={'schedule':r['schedule'],'case_sha256':row['sha256']}
r2=launch(row,'COMMON_GRID',out/'zero_search',anchor,actual_seconds=1,search_seconds=0,virtual_seconds=4)
checks['zero_search_retains_anchor']=r2['valid'] and r2['status']=='NO_SEARCH_TIME' and r2['schedule']==anchor['schedule']
r3=launch(row,'COMMON_GRID',out/'hard_timeout',anchor,actual_seconds=.25,search_seconds=10,virtual_seconds=4)
checks['hard_timeout_retains_verified_fallback']=r3['valid'] and r3['status']=='DEADLINE_KILL' and len(r3['receipts'])>=1
checks['hard_timeout_no_live_child']=r3['returncode'] is not None
checks['no_late_receipt_accepted']=all(x['timely'] and x['completed_at']<=r3['deadline'] for x in r3['receipts'])
# Immutable publication must reject replacement, including receipt replacement.
try:publish(out/'case.json',{'changed':True});checks['immutable_publication']=False
except FileExistsError:checks['immutable_publication']=digest(path)==row['sha256']
ledger=Ledger(out/'test-ledger.jsonl',limit=7200);ledger.reserve('x',1,bucket='correctness');ledger.finish('x',.5)
try:ledger.reserve('x',1,bucket='correctness');checks['duplicate_ledger_reservation']=False
except AssertionError:checks['duplicate_ledger_reservation']=True
try:ledger.reserve('too-large',481,bucket='correctness');checks['category_cap']=False
except AssertionError:checks['category_cap']=True
checks['all_sources_are_exact_stored_vectors']=all('channels_re' in case and 'channels_im' in case for _ in [0])
result={'checks':checks,'pass':all(checks.values()),'seconds':time.monotonic()-START,'scope':'deterministic controller fixtures; no registered performance cells'}
publish(out/'TEST_RESULT.json',result);print(json.dumps(result));assert result['pass']
