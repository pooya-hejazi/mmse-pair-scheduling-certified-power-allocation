#!/usr/bin/env python3
"""Portable saved-evidence replay. Never generates channels or runs an optimizer."""
import time
STARTED = time.monotonic()  # Includes all subsequent imports and archive work.
import argparse
from fractions import Fraction as F
import gzip
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import sys
import types
import zipfile
import zipimport

R1_SHA = '6dc52e28c6d1352029c2f6b8f23afa77a4e5440cc3239655d4bb806ca0636639'
CHECKER_SHA = '39cf718ac1c52401807771c572b8af9501e0f1b91b4318d24ffc7101bd27d8a5'
BASE = 'CR033/'
STUDY = BASE + 'study/'
ARMS = ('T', 'W', 'S', 'FU_SCA', 'THU_IDE')
CHECKER_MEMBER = BASE + 'baseline-code/verify_upper.py'


class ReplayFailure(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise ReplayFailure(message)


def safe_member(name):
    require(isinstance(name, str) and bool(name) and '\\' not in name, 'unsafe ZIP member name')
    p = PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and ':' not in name,
            'absolute/traversing ZIP path: ' + name)
    require(str(p) == name.rstrip('/'), 'noncanonical ZIP member: ' + name)
    return name


def leaf(name):
    require(isinstance(name, str) and name == PurePosixPath(name).name and
            '\\' not in name and ':' not in name and name not in ('.', '..'),
            'receipt references non-leaf filename')
    return name


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical_digest(obj):
    return digest(json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def same_fraction(a, b, label):
    require(F(a) == F(b), label + ': rational disagreement')


def finite_number(x, label):
    require(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x),
            label + ': invalid timestamp/number')
    return x


class Replay:
    def __init__(self, archive, seconds, numeric_scope):
        self.archive = archive
        self.deadline = STARTED + seconds
        self.numeric_scope = numeric_scope
        self.report = dict(status='INCOMPLETE', scope='saved data only; no optimization or channel generation',
                           numeric_scope=numeric_scope, seconds_allowance=seconds,
                           checker_source_sha256=CHECKER_SHA, expected_nested_R1_sha256=R1_SHA,
                           counts=dict(manifest_files=0, inputs=0, main_cells=0, common_cells=0,
                                       reference_cells=0, reference_arms=0, timely_receipts=0,
                                       numeric_schedules=0, numeric_cache_hits=0),
                           limitations=[
                               'Default numerical replay covers retained schedules only; all timely receipt chains are checked.',
                               'Recorded orthogonal reference status/count/gap and heuristic comparisons are checked; '
                               'the saved records lack per-assignment dual witnesses, so the six global upper bounds are not independently re-proved.',
                               'Fu/Thu are common-model power-component adapters, not reproductions of full source architectures.',
                               'A hash-consistent archive is not a journal acceptance or a proof of external scientific generalization.'
                           ])
        self.z = None
        self.hashes = {}
        self.sizes = {}
        self.cache = {}
        self.case_cache = {}
        self.rows = {}
        self.checker = None

    def check_time(self):
        if time.monotonic() >= self.deadline:
            raise TimeoutError('replay wall allowance exhausted; mandatory replay incomplete')

    def read(self, name):
        self.check_time()
        require(name in self.hashes, 'unmanifested/missing member: ' + name)
        data = self.z.read(name)
        require(digest(data) == self.hashes[name], 'member changed after integrity pass: ' + name)
        self.check_time()
        return data

    def obj(self, name):
        return json.loads(self.read(name).decode('utf-8-sig'))

    def stream_hash(self, stream):
        h = hashlib.sha256()
        total = 0
        while True:
            self.check_time()
            block = stream.read(1024 * 1024)
            if not block:
                break
            h.update(block)
            total += len(block)
        return h.hexdigest(), total

    def integrity(self):
        self.check_time()
        with self.archive.open('rb') as f:
            self.report['archive_sha256'], self.report['archive_bytes'] = self.stream_hash(f)
        self.z = zipfile.ZipFile(self.archive)
        infos = self.z.infolist()
        names = [i.filename for i in infos]
        require(len(names) == len(set(names)), 'duplicate ZIP member names')
        for name in names:
            safe_member(name)
        require('MANIFEST.json' in names, 'root MANIFEST.json missing')
        manifest = json.loads(self.z.read('MANIFEST.json').decode('utf-8-sig'))
        require(isinstance(manifest.get('files'), list), 'manifest files list missing')
        for row in manifest['files']:
            name = safe_member(row['path'])
            require(name != 'MANIFEST.json' and name not in self.hashes, 'duplicate/self manifest entry')
            require(isinstance(row['bytes'], int) and row['bytes'] >= 0, 'invalid manifest byte count')
            require(isinstance(row['sha256'], str) and len(row['sha256']) == 64, 'invalid SHA256')
            self.hashes[name] = row['sha256'].lower()
            self.sizes[name] = row['bytes']
        actual = {i.filename for i in infos if not i.is_dir()} - {'MANIFEST.json'}
        require(actual == set(self.hashes), 'manifest does not exactly cover archive file members')
        for name in sorted(self.hashes):
            with self.z.open(name) as f:
                got, size = self.stream_hash(f)
            require(got == self.hashes[name] and size == self.sizes[name], 'manifest mismatch: ' + name)
            self.report['counts']['manifest_files'] += 1
        nested = 'baseline_R1/Supplementary_Materials.zip'
        require(self.hashes.get(nested) == R1_SHA, 'immutable nested R1 archive hash mismatch')
        require(self.hashes.get(CHECKER_MEMBER) == CHECKER_SHA,
                'checker is not the unchanged independently implemented R1 source')
        # Standard-library zipimport only; no extraction or source optimizer imports.
        importer = zipimport.zipimporter(str(self.archive) + '/' + BASE + 'baseline-code')
        source = importer.get_source('verify_upper')
        require(source is not None, 'cannot import pinned independent checker source')
        # Compile the pinned .py source, never prefer an unrelated bundled .pyc.
        code = compile(source, str(self.archive) + '/' + CHECKER_MEMBER, 'exec')
        self.checker = types.ModuleType('r2_pinned_verify_upper')
        self.checker.__file__ = str(self.archive) + '/' + CHECKER_MEMBER
        exec(code, self.checker.__dict__)
        self.check_time()
        self.report['integrity'] = 'PASS'

    def inputs(self, phase, expected):
        rows = self.obj(STUDY + phase + '-INPUTS.json')['inputs']
        require(len(rows) == expected, phase + ': unexpected input count')
        require(len({r['id'] for r in rows}) == len(rows), phase + ': duplicate input IDs')
        for row in rows:
            leaf(row['id'])
            # Deliberately ignore nonportable original row['path'].
            member = STUDY + 'inputs/' + row['id'] + '.json'
            require(self.hashes.get(member) == row['sha256'], 'input manifest/member hash mismatch')
            case = self.obj(member)
            self.case_cache[row['id']] = case
            self.rows[row['id']] = row
            self.report['counts']['inputs'] += 1
        return rows

    def numeric(self, case_id, schedule):
        self.check_time()
        case = self.case_cache[case_id]
        key = (case_id, canonical_digest(schedule))
        if key in self.cache:
            self.report['counts']['numeric_cache_hits'] += 1
            return self.cache[key]
        proof = dict(schema='MMSE_PARTITION_PROOF_V1', case_sha256=canonical_digest(case),
                     universal=True, dual=None, spatial=None)
        checked = self.checker.verify(case, dict(schedule=schedule, proof=proof),
                                      seconds=max(0, self.deadline - time.monotonic()))
        self.check_time()
        require(checked.get('valid') is True, 'independent numerical checker rejected schedule')
        self.cache[key] = checked
        self.report['counts']['numeric_schedules'] += 1
        return checked

    def sidecar(self, directory, worker):
        side = worker.get('diagnostics_sidecar')
        if not side:
            return
        member = directory + '/' + leaf(side['file'])
        require(self.hashes.get(member) == side['sha256'], 'worker sidecar hash mismatch')
        with self.z.open(member) as compressed:
            with gzip.GzipFile(fileobj=compressed) as raw:
                got, size = self.stream_hash(raw)
        require(got == side['uncompressed_sha256'], 'worker diagnostic uncompressed hash mismatch')
        if 'uncompressed_bytes' in side:
            require(size == side['uncompressed_bytes'], 'worker diagnostic uncompressed size mismatch')

    def operational(self, result):
        require(result.get('valid') is True and not result.get('errors'), 'invalid/error cell')
        worker = result.get('worker_status')
        if worker is not None:
            require(worker.get('normal') is not False and worker.get('status') not in ('error', 'WORKER_ERROR'),
                    'unexpected worker failure cannot be hidden by feasible fallback')
            require(not worker.get('diagnostics', {}).get('errors'), 'worker diagnostics contain errors')
        if result.get('status') == 'RETURNED':
            require(result.get('returncode') == 0 and worker is not None and worker.get('normal') is True,
                    'RETURNED cell lacks a normal worker completion')
        else:
            require(result.get('status') in ('DEADLINE_KILL', 'NO_SEARCH_TIME'),
                    'unsupported non-return termination')
        # Legitimate wall-time kills keep their independently checked fallback.
        return worker

    def cell(self, directory, row, arm, expected_allowance):
        result = self.obj(directory + '/result.json')
        attempt = self.obj(directory + '/attempt.json')
        worker = self.operational(result)
        require(result['case_id'] == row['id'] and result['method'] == arm and attempt['method'] == arm,
                'cell identity mismatch')
        require(attempt['case_id'] == row['id'] and
                result['case_sha256'] == attempt['case_sha256'] == row['sha256'], 'cell input binding mismatch')
        for field in ('started_at', 'deadline', 'search_deadline', 'charged_allowance', 'virtual_seconds'):
            finite_number(result[field], field)
            require(result[field] == attempt[field], 'attempt/result clock or charge mismatch')
        require(result['charged_allowance'] == expected_allowance, 'wrong cell allowance')
        require(result['started_at'] <= result['search_deadline'] <= result['deadline'], 'invalid deadline order')
        require(math.isclose(result['deadline'] - result['started_at'] + result['virtual_seconds'],
                             expected_allowance, rel_tol=0, abs_tol=1e-7), 'deadline/charged allowance mismatch')
        if worker:
            status_member = directory + '/worker-status.json'
            require(self.obj(status_member) == worker, 'result worker summary differs from immutable status')
            self.sidecar(directory, worker)
        descriptors = result.get('receipts', [])
        require(descriptors, 'no retained receipt chain')
        require(len({d['file'] for d in descriptors}) == len(descriptors), 'duplicate receipt descriptors')
        best = None
        retained = None
        previous_completed = result['started_at']
        for descriptor in descriptors:
            self.check_time()
            name = leaf(descriptor['file'])
            member = directory + '/' + name
            require(self.hashes.get(member) == descriptor['sha256'], 'receipt descriptor hash mismatch')
            completed = finite_number(descriptor['completed_at'], 'receipt completed_at')
            require(completed >= previous_completed, 'receipt publication order regressed')
            previous_completed = completed
            require(isinstance(descriptor['timely'], bool) and
                    descriptor['timely'] == (completed <= result['deadline']), 'receipt timeliness flag mismatch')
            if not descriptor['timely']:
                continue
            receipt = self.obj(member)
            require(receipt['case_sha256'] == row['sha256'], 'receipt input hash mismatch')
            require(receipt['attempt_sha256'] == self.hashes[directory + '/attempt.json'], 'receipt attempt hash mismatch')
            validated = finite_number(receipt['validated_at'], 'receipt validated_at')
            require(result['started_at'] <= validated <= completed <= result['deadline'], 'receipt timestamp chain invalid')
            candidate_member = directory + '/' + leaf(receipt['candidate_file'])
            require(self.hashes.get(candidate_member) == receipt['candidate_sha256'], 'receipt candidate hash mismatch')
            candidate = self.obj(candidate_member)
            if 'producer_at' in candidate:
                produced = finite_number(candidate['producer_at'], 'candidate producer_at')
                require(result['started_at'] <= produced <= validated, 'candidate production/validation clock chain invalid')
            verification = receipt['verification']
            require(verification.get('valid') is True, 'receipt has no valid verifier result')
            lower, upper, incumbent_upper = (F(verification[k]) for k in ('lower_nats', 'upper_nats', 'incumbent_upper_nats'))
            require(lower <= incumbent_upper <= upper, 'receipt bound ordering invalid')
            self.report['counts']['timely_receipts'] += 1
            if self.numeric_scope == 'all-timely':
                checked = self.numeric(row['id'], candidate['schedule'])
                for field in ('lower_nats', 'upper_nats', 'incumbent_upper_nats'):
                    same_fraction(checked[field], verification[field], 'timely receipt ' + field)
            item = dict(name=name, schedule=candidate['schedule'], verification=verification)
            if best is None or lower > F(best['verification']['lower_nats']):
                best = item
            if name == result['best_receipt']:
                retained = item
        require(best is not None and retained is not None, 'retained receipt is not timely')
        require(best['name'] == result['best_receipt'], 'retained receipt is not first greatest timely lower bound')
        require(retained['schedule'] == result['schedule'], 'retained schedule differs from candidate')
        checked = self.numeric(row['id'], result['schedule'])
        for field in ('lower_nats', 'upper_nats', 'incumbent_upper_nats'):
            same_fraction(result[field], retained['verification'][field], 'retained result ' + field)
            same_fraction(checked[field], result[field], 'independent retained ' + field)
        return result

    def source_freeze(self, marker_name):
        member = STUDY + marker_name
        require(member in self.hashes, 'required acceptance/source marker missing: ' + member)
        marker = self.obj(member)
        require(marker.get('verdict') == 'PASS', 'source marker not PASS')
        for row in marker['files']:
            relative = safe_member(row['path'])
            require(self.hashes.get(BASE + relative) == row['sha256'], 'accepted source hash drift: ' + relative)

    def references(self):
        for phase in ('reference-dev', 'reference-holdout'):
            rows = self.inputs(phase, 4)
            for row in rows:
                directory = STUDY + 'references/' + row['id']
                checked = self.obj(directory + '/CHECKED.json')
                reference = self.obj(directory + '/reference.json')
                case = self.case_cache[row['id']]
                require(case['K'] == 4 and case['S'] == 2 and all(F(p['r']) == 0 for p in case['pairs']),
                        'saved exact reference is not the registered orthogonal K4 subclass')
                require(finite_number(checked['elapsed'], 'reference elapsed') < 60, 'reference recorded allowance exceeded')
                require(checked['case_id'] == row['id'] and checked['reference'] == reference,
                        'reference summary binding mismatch')
                require(reference.get('status') == 'certified' and reference.get('assignments_completed') == 6,
                        'reference lacks recorded six-assignment certification')
                gap = F(reference['upper_nats']) - F(reference['lower_nats'])
                require(F(0) <= gap <= F(1, 10**6), 'reference recorded gap exceeds tolerance')
                same_fraction(reference['gap_nats'], gap, 'reference gap')
                replayed = self.numeric(row['id'], reference['schedule'])
                # Independent and producer log enclosures may use different rational endpoints.
                require(F(replayed['lower_nats']) <= F(reference['upper_nats']) and
                        F(reference['lower_nats']) <= F(replayed['incumbent_upper_nats']),
                        'reference feasible lower is inconsistent with independent rate enclosure')
                require(len(checked['arms']) == 5 and {x['arm'] for x in checked['arms']} == set(ARMS),
                        'reference five-arm comparison incomplete')
                arm_rows = {x['arm']: x for x in checked['arms']}
                for arm in ARMS:
                    result = self.cell(directory + '/' + arm, row, arm, 6)
                    require(F(result['lower_nats']) <= F(reference['upper_nats']), 'heuristic exceeds saved reference upper')
                    same_fraction(result['lower_nats'], arm_rows[arm]['lower_nats'], 'reference arm lower')
                    same_fraction(reference['upper_nats'], arm_rows[arm]['reference_upper_nats'], 'reference arm upper')
                    self.report['counts']['reference_arms'] += 1
                self.report['counts']['reference_cells'] += 1
        self.report['reference_scope'] = ('PASS recorded six-assignment coverage/gap consistency, independent retained '
                                          'feasibility/rates, and forty heuristic-to-saved-upper comparisons; '
                                          'NOT independent reconstruction of the six global upper bounds.')

    def compare_float(self, actual, saved, label):
        if isinstance(actual, list):
            require(isinstance(saved, list) and len(actual) == len(saved), label + ': shape disagreement')
            for i, (a, b) in enumerate(zip(actual, saved)):
                self.compare_float(a, b, label + '[' + str(i) + ']')
        else:
            require(math.isfinite(float(actual)) and math.isfinite(float(saved)) and
                    abs(float(actual) - float(saved)) <= 1e-12, label + ': numerical disagreement >1e-12')

    def bootstrap(self, protocol, rows, se):
        self.check_time()
        try:
            import numpy as np
        except ImportError as exc:
            raise ReplayFailure('NumPy is required for mandatory registered bootstrap replay; install requirements-replay.txt separately') from exc
        self.check_time()
        summary = self.obj(STUDY + 'analysis/holdout/SUMMARY.json')
        require(summary.get('complete') is True and summary.get('primary_evaluable') is True and
                summary.get('inputs') == 44 and summary.get('expected_cells') == 220 and
                summary.get('completed_valid_cells') == 220, 'saved holdout summary not complete/evaluable')
        seeds = protocol['population']['holdout_seed_groups']
        regimes = [r['id'] for r in protocol['population']['regimes']]
        require(len(seeds) == 11 and len(regimes) == 4, 'registered grouping changed')
        require({(r['seed'], r['regime']) for r in rows} == {(g, r) for g in seeds for r in regimes},
                'holdout population/group coverage differs from frozen protocol')
        uncertainty = protocol['primary']['uncertainty']
        require(uncertainty['seed'] == 2026110399 and uncertainty['replicates'] == 20000 and
                uncertainty['quantiles'] == [.025, .975], 'registered bootstrap specification changed')
        contrasts = []
        for row in rows:
            vals = se[row['id']]
            t = vals['T']; modern = max(vals['FU_SCA'], vals['THU_IDE'])
            allbest = max(vals[a] for a in ARMS if a != 'T')
            require(modern > 0 and allbest > 0, 'relative primary undefined; no epsilon substitution permitted')
            contrasts.append(dict(seed=row['seed'], regime=row['regime'],
                                  absolute_modern=t-modern, relative_modern=(t-modern)/modern,
                                  absolute_all=t-allbest, relative_all=(t-allbest)/allbest,
                                  **{'T_minus_' + a: t-vals[a] for a in ARMS if a != 'T'}))
        effects = {}
        keys = ('absolute_modern', 'relative_modern', 'absolute_all', 'relative_all',
                'T_minus_W', 'T_minus_S', 'T_minus_FU_SCA', 'T_minus_THU_IDE')
        for key in keys:
            self.check_time()
            values = np.asarray([float(np.mean([x[key] for x in contrasts if x['seed'] == seed]))
                                 for seed in seeds], float)
            rng = np.random.Generator(np.random.PCG64(2026110399))
            indices = rng.integers(0, len(values), size=(20000, len(values)))
            means = values[indices].mean(axis=1)
            recomputed = dict(mean=float(values.mean()), interval95=np.quantile(means, [.025, .975]).tolist(),
                              group_effects=values.tolist(),
                              leave_one_group_out=[float(np.delete(values, i).mean()) for i in range(len(values))])
            saved = summary['effects'][key]
            require(saved['bootstrap_seed'] == 2026110399 and saved['replicates'] == 20000,
                    'saved effect bootstrap metadata mismatch')
            for field, value in recomputed.items():
                self.compare_float(value, saved[field], key + '.' + field)
            effects[key] = recomputed
        absolute = protocol['primary']['absolute_substantial_threshold_bit_per_s_Hz']
        relative = protocol['primary']['relative_substantial_threshold']
        require(absolute == .1 and relative == .05, 'registered substantial thresholds changed')
        primary = effects['absolute_modern']['interval95'][0] > absolute and effects['relative_modern']['interval95'][0] > relative
        broad = primary and effects['absolute_all']['interval95'][0] > absolute and effects['relative_all']['interval95'][0] > relative
        small = effects['absolute_all']['interval95'][0] > .02
        for key, value in [('substantial_primary', primary), ('broad_substantial', broad), ('small_useful_secondary_all', small)]:
            require(summary.get(key) is value, 'saved outcome flag disagrees: ' + key)
        self.report['bootstrap'] = dict(status='PASS', numpy_version=np.__version__, seed=2026110399,
                                       replicates=20000, groups=11, cases=44, effects=effects,
                                       substantial_primary=primary, broad_substantial=broad,
                                       small_useful_secondary_all=small,
                                       comparison_tolerance=1e-12)
        self.check_time()

    def run(self):
        self.integrity()
        protocol = self.obj(BASE + 'protocol-v2/PROTOCOL.json')
        require(protocol['schema'] == 'CR033_PROSPECTIVE_PROTOCOL_V2', 'wrong prospective protocol')
        require(protocol['timing']['main_cells'] == 260 and protocol['timing']['new_main_inputs'] == 52,
                'frozen main population changed')
        self.source_freeze('APPROVED_METHOD.json')
        self.source_freeze('APPROVED_HOLDOUT.json')
        populations = {phase: self.inputs(phase, n) for phase, n in [('pilot', 4), ('legacy', 4), ('holdout', 44)]}
        flat = [r for rows in populations.values() for r in rows]
        require(len({r['id'] for r in flat}) == 52, 'main input IDs overlap across phases')
        all_se = {}
        for row in flat:
            directory = STUDY + 'common/' + row['id']
            common = self.cell(directory, row, 'COMMON_GRID', 4)
            self.report['counts']['common_cells'] += 1
            vals = {}
            for arm in ARMS:
                directory = STUDY + 'cells/' + row['id'] + '-' + arm
                anchor = self.obj(directory + '/anchor.json')
                require(anchor['schedule'] == common['schedule'] and anchor['case_sha256'] == row['sha256'] and
                        anchor['common_result_sha256'] == self.hashes[STUDY + 'common/' + row['id'] + '/result.json'] and
                        anchor['common_receipt'] == common['best_receipt'], 'common-start binding mismatch')
                result = self.cell(directory, row, arm, 20)
                case = self.case_cache[row['id']]
                lower = float(F(result['lower_nats']))
                require(lower > 0, 'main retained lower bound must be positive for registered analysis')
                vals[arm] = lower / (case['S'] * math.log(2))
                self.report['counts']['main_cells'] += 1
            all_se[row['id']] = vals
        # Legacy ceiling is a separate saved-protocol integrity guard, not a matched Full arm.
        guard = self.obj(STUDY + 'LEGACY_UPPER_GUARD.json')
        for row in populations['legacy']:
            require(guard[row['id']]['input_sha256'] == row['sha256'], 'legacy upper input hash mismatch')
            for arm in ARMS:
                result = self.obj(STUDY + 'cells/' + row['id'] + '-' + arm + '/result.json')
                require(F(result['lower_nats']) <= F(guard[row['id']]['upper_nats']), 'new legacy lower exceeds old checked upper')
        self.references()
        self.bootstrap(protocol, populations['holdout'], all_se)
        require(self.report['counts']['main_cells'] == 260 and self.report['counts']['reference_cells'] == 8,
                'mandatory evidence coverage incomplete')
        self.report['status'] = 'PASS'
        self.report['statement'] = ('All mandatory saved-evidence integrity, retained numerical and registered-bootstrap checks passed. '
                                    'This says nothing favorable about efficacy unless the reproduced outcome flags are true.')
        self.check_time()
        return self.report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path, help='Must not already exist')
    parser.add_argument('--seconds', type=float, default=30.0, help='Total replay allowance including imports; default30')
    parser.add_argument('--numeric-scope', choices=('retained', 'all-timely'), default='retained',
                        help='Default: independently recheck retained schedules; always check all timely receipt integrity')
    args = parser.parse_args()
    require(math.isfinite(args.seconds) and args.seconds > 0, '--seconds must be positive finite')
    archive = args.archive.resolve()
    require(archive.is_file(), 'archive not found')
    args.output_dir.mkdir(parents=True, exist_ok=False)
    replay = Replay(archive, args.seconds, args.numeric_scope)
    code = 1
    try:
        replay.run()
        code = 0
    except Exception as exc:
        replay.report['status'] = 'FAIL' if not isinstance(exc, TimeoutError) else 'INCOMPLETE_TIMEOUT'
        replay.report['error'] = dict(type=type(exc).__name__, message=str(exc))
        replay.report['statement'] = 'Mandatory replay did not complete successfully; no reproduction PASS is asserted.'
    finally:
        if replay.z is not None:
            replay.z.close()
        replay.report['elapsed_seconds'] = time.monotonic() - STARTED
        replay.report['clock_scope'] = 'First executable script clock onward, including imports/archive/NumPy; interpreter process launch itself is not measurable here.'
        with (args.output_dir / 'VERIFICATION.json').open('x', encoding='utf-8') as f:
            json.dump(replay.report, f, indent=2, allow_nan=False)
            f.write('\n')
        boot = replay.report.get('bootstrap', {})
        text = '\n'.join([
            '# R2 saved-evidence replay', '',
            'Status: **' + replay.report['status'] + '**.', '',
            replay.report.get('statement', ''), '',
            'Numerical scope: ' + args.numeric_scope + '. All timely receipt chains are checked.',
            'Main cells checked: ' + str(replay.report['counts']['main_cells']) + '/260; orthogonal reference records: ' +
            str(replay.report['counts']['reference_cells']) + '/8.',
            'Substantial modern-envelope primary: ' + str(boot.get('substantial_primary', 'not reproduced')) + '.',
            'Broad all-four-baseline substantial criterion: ' + str(boot.get('broad_substantial', 'not reproduced')) + '.', '',
            'No optimizer, channel generator or performance simulation was run. Fu/Thu labels denote adapted power components.',
            'Reference record replay checks saved six-assignment count/gap and retained rates; it does not reconstruct absent dual witnesses for all six global upper bounds.',
            'Elapsed seconds: ' + format(replay.report['elapsed_seconds'], '.6f') + '.',
            'See VERIFICATION.json for hashes, counts, reproduced effects, errors and exact scope.', ''
        ])
        with (args.output_dir / 'VERIFICATION.md').open('x', encoding='utf-8') as f:
            f.write(text)
    print(replay.report['status'] + ': ' + str(args.output_dir / 'VERIFICATION.json'))
    return code


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        sys.exit(2)
