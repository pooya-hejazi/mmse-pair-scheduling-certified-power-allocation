# Finite-box / integral-schedule bound study

**Result: the prospective certification target passed. Broad sum-rate superiority was not demonstrated.** All 32 unchanged corrected physical cases were evaluated once (24 K8, 8 K16). All new and matched-baseline bounds passed separate archived-input replay; all integral DPs completed. There were no new errors, timeouts, cap overruns, exclusions, or replacement cases.

## Measured certification improvement

Both producers received 10 s, with a separately reported 15 s independent-checking allowance. The comparator is the unmodified frozen generic rectangular **scalar-price repair** (`grid_repair`), using archived grid dual proposals. Both methods start from the same archived grid schedule. Imports, archive loading, fallback setup and I/O are outside these callable timings; no grid solve was rerun.

| Population | New / generic certificates at gap ≤0.01 nat | Median gap, generic → new (nat) | Median paired reduction in **U−L_grid** |
|---|---:|---:|---:|
| O1, 16 cases | 16 / 0 | 0.708622 → 9.42×10⁻¹¹ | 99.999996% |
| ASU, 16 cases | 11 / 0 | 0.703995 → 0.003225 | 66.37% |
| All 32 | **27 / 0** | 0.708622 → 9.35×10⁻¹⁰ | **97.82%** |

Every new upper was strictly smaller than its matched generic upper. The fixed-anchor endpoint isolates upper improvement from feasible-rate improvement. The frozen target required at least 16 certificates and at least 50% median fixed-anchor gap reduction, with all records verified.

Five cases remain uncertified at 0.01 nat: `asu-main-01` (0.0101824), and `asu-scale-00/01/02/03` (1.431925, 0.543941, 1.045500, 0.885982 nat). These are valid incomplete optimality certificates, not omitted cases or incomplete DPs.

Median producer/checker times were **1.429/0.597 s** for the new method and **1.237/0.463 s** for the generic method. New maxima were 7.388/1.588 s. Thus there is no blanket runtime-speedup claim. O1 median final-receipt computation was 0.210 s; ASU was 2.222 s. These are final producer-plus-checker times, not instrumented earliest-certificate publication times. The whole campaign took 135.59 s; separate replay took 40.75 s.

## Achieved rate and attainable headroom

- Versus the common grid, the all-case median achieved gain was **0.04035%** (mean 0.3460%, maximum 1.5693%). Only **3/32** exceeded the predeclared descriptive 1% material-gain threshold: ASU main-01, scale-00 and scale-02.
- Versus independently rechecked archived Full/pricing schedules, the median was **0.03555%** (mean 0.2728%, maximum 1.1804%). Only **2/32**, ASU scale-00 and scale-02, exceeded 1%. Historical Full has a different timing scope and is not a matched-time comparator here.
- O1 achieved gains were negligible: median 5.16×10⁻⁸ nat, maximum 1.38×10⁻⁷ nat. The new bounds establish that **every archived O1 Full/pricing schedule was already within 1.382×10⁻⁷ nat of the continuous integral optimum**. Across all K8 cases, old Full's certified possible improvement is at most **0.725%**; across all 32 it is at most **4.143%**.
- All 20 recorded T/S/W/Fu-SCA/Thu-IDE rows on the four matching physical cases were checked against identical channel data and common grid anchors. The recorded SLSQP rates already match the new rates within **3.92×10⁻⁸ nat**. This provides no meaningful rate advantage over that strong refiner. Historical time allowances differ; common initialization does not equalize timing. The two archived W verification-timeout records, ASU main-00 and main-06, remain explicitly recorded alongside their valid retained incumbents.

**No statistically significant rate-superiority result was established:** no such hypothesis was tested. There are modest individual rate gains, not a substantial broad rate gain. The meaningful new result is tighter independently checked upper bounds, including certification of previously near-optimal feasible allocations.

## Data suitability: all links retained

Nominal received SNR is `0.1 × gain`, before pairing interference. Each scene has 896 user/resource links; pooled statistics weight K16 cases more heavily. Zero-gain links are retained as −∞ dB.

| Scene | SNR p10 / median / p90 (dB) | Zero links | Combined quadrant-or-box qualification | Whole-quadrant only |
|---|---:|---:|---:|---:|
| O1 | 42.30 / 47.24 / 50.42 | 0/896 | 5184/5184 = **100%** | 51/5184 = 0.984% |
| ASU | 7.12 / 16.42 / 32.20 | 24/896 | 1663/5184 = **32.08%** | 471/5184 = 9.086% |

The equally weighted mean per-case qualification fraction is 32.565% in ASU; this explains its approximate 32.6% preliminary diagnosis. Explicit all-link median-of-case-median SNRs are 47.39 dB (O1) and 16.51 dB (ASU). The pooled squared-correlation medians are 0.8884 and 0.9481: these are not orthogonal-channel fixtures.

High received SNR makes O1's actual finite power rectangles concave despite correlations far above the whole-quadrant threshold, and leaves the existing approximately uniform-power schedules almost optimal. ASU includes weak/zero channels and highly correlated pairs; its K16 residual gaps remain appreciable. The data are useful for physical-model certification, but cannot support an expectation of broadly large rate gains against already near-optimal incumbents. General nonconcave theory covers harder regimes than these O1 rectangles. The separate nonorthogonal development fixtures probe that distinction; none replaced physical cases. SNR and useful-symbol rates are not deployment-throughput measurements.

## Implementation and audit boundary

The new upper is `lambda*P + 2^-40 DP(ceil(2^40 H))`, with complete pair-box coverage and **integral labelled-resource scheduling**. Rational finite-box Hessian checks use cancellation-safe W2; all derivatives and the physical price term are exact. Numerical SLSQP/L-BFGS-B results only propose feasible powers, tangent points and prices. The checker independently reconstructs channel coefficients, bounds, coverage and a separate subset recurrence, sharing only the pinned integer-log primitive. Fifteen pre-freeze tests include symbolic Hessians, above-threshold curvature, zero/r=1, signed ceilings, K4/K8 enumeration, labelled-resource counterexamples, tampering, missing rows, archive binding, and a strict power-budget duality-gap counterexample.

This is **certified box bounding, not integration of the finite-candidate algebraic oracle**. The upper is for the integral continuous problem, not necessarily the fractional configuration LP. Dominance over repaired configuration duals holds only at matched price and pair-bound table; the observed cross-method improvement is empirical. Exact DP and further price iterations do not guarantee closure of the remaining power-budget duality gap.

## Integration paths

All paths below are under `research/manuscript-refinement-20261106/certification/`:

- `PROTOCOL.md`, `FROZEN.json`, `INPUT_MANIFEST.json`: prospective target, frozen implementation and all32 archive bindings.
- `PROOF_NOTE.md`, `producer.py`, `checker.py`, `integer_logs.py`: self-contained proof and separate implementations. Parent `PROOF_AUDIT.md` supplies the independent mathematical audit.
- `final/summary.json`, `final/results.csv`, `final/rows.json`: primary all-case results; each `final/<case>/` contains full exact witnesses, independent receipts, diagnostics and historical checks. `final/OUTPUT_MANIFEST.json` binds every saved row.
- `replay-result.json`: **32/32 PASS**, covering 64 new/baseline bound replays and 84 historical feasible-schedule checks.
- `analysis/descriptive.json`, `analysis/all-case-rates.csv`, `analysis/historical-modern-rates.csv`: SNR/correlation distributions, achieved rates, remaining-headroom bounds and historical comparisons.
- `README.md`, `ENVIRONMENT.json`, `development/`, `development-v1-single-price/`: reproduction instructions, environment and retained development evidence, including the nonclosing K16 synthetic result.

No article or prior artifact was edited. Display decimals are descriptive; certificate endpoints and decisions use the saved exact fractions.
