# Paper folder

This folder contains the manuscript only.

- `main.tex` — single merged manuscript source; no `\input{}` or `\include{}`.
- `main.pdf` — compiled 13-page manuscript.
- `references.bib`
- `IEEEtran.cls`, `IEEEtran.bst`
- `images/` — only the figures referenced by `main.tex`.

Compile from this folder with:

```text
tectonic --untrusted main.tex
```

The folder was compiled independently from a clean copy and produced the 13-page `main.pdf`.
