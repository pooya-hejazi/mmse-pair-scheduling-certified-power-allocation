# Supplementary materials folder

This folder contains the supplement, its figures, and the reproducible code.

- `supplementary.tex` — single merged supplement source; no `\input{}` or `\include{}`.
- `supplementary.pdf` — compiled 47-page supplement.
- `references.bib`
- `IEEEtran.cls`, `IEEEtran.bst`
- `images/` — only the figures referenced by `supplementary.tex`.
- `code/` — CDL generator, benchmark runners, baseline code, finite-box certificate code, saved results, protocols and figure scripts.

Compile the supplement from this folder with:

```text
tectonic --untrusted supplementary.tex
```

## Reproducing the headline CDL result

From `code/`:

```text
pip install -r requirements.txt
python research/phase1-cdl-20261109/build_cdl.py
python research/phase1-cdl-20261109/run_cdl.py
python research/phase1-cdl-20261109/analyze_cdl.py
```

The result tables are:

- `code/research/phase1-cdl-20261109/cdl_results.csv` — 53 K=16 cases.
- `code/research/phase1-cdl-20261109/cdl_k8_results.csv` — 24 K=8 cases.
- `code/research/phase1-cdl-20261109/cdl_ablation.csv` — attribution.
- `code/research/phase1-cdl-20261109/cdl_long_baseline.csv` — 30-s baseline sensitivity.

The CDL generator uses the 3GPP TR 38.901 CDL-A/B/C cluster tables under `code/research/phase1-cdl-20261109/tables/`. The generator is CPU-only and seed-reproducible.

The full archived DeepMIMO ray-tracing archive is not redistributed here. DeepMIMO is retained only as the `M=8` certificate and receive-dimension cross-check; the code and saved summaries for that cross-check are included.
